package com.example.util;

import java.io.PrintStream;
import java.util.Random;

public class RandomNumberGen
{
	

    public RandomNumberGen()
    {
    }

    public int getRandomNumber()
    {
        log("4 digit Random Numbers.");
        int START = 1001;
        int END = 9999;
        int res = 0;
        Random random = new Random();
        res = showRandomInteger(START, END, random);
        log("rndom numebr::::"+ res);
        return res;
    }

    private int showRandomInteger(int aStart, int aEnd, Random aRandom)
    {
        int res = 0;
        if(aStart > aEnd)
        {
            throw new IllegalArgumentException("Start cannot exceed End.");
        } else
        {
            long range = ((long)aEnd - (long)aStart) + 1L;
            long fraction = (long)((double)range * aRandom.nextDouble());
            int randomNumber = (int)(fraction + (long)aStart);
            res = randomNumber;
            return res;
        }
    }

    private static void log(String aMessage)
    {
        System.out.println(aMessage);
    }
}
