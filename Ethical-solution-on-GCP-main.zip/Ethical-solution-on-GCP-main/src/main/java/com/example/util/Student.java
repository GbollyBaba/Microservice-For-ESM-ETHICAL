package com.example.util;
import java.util.List;

public class Student {

    private String name;
    private int age;
    private List<String> skills;
	protected String getName() {
		return name;
	}
	protected void setName(String name) {
		this.name = name;
	}
	protected int getAge() {
		return age;
	}
	protected void setAge(int age) {
		this.age = age;
	}
	protected List<String> getSkills() {
		return skills;
	}
	protected void setSkills(List<String> skills) {
		this.skills = skills;
	}

    // getters setters
}