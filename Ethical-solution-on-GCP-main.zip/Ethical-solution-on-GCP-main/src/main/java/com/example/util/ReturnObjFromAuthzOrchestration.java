package com.example.util;

public class ReturnObjFromAuthzOrchestration {
	public ReturnObjFromAuthzOrchestration(String authorization_code, Object errorlist) {
		super();
		this.authorization_code = authorization_code;
		this.errorlist = errorlist;
	}

	private String authorization_code;
	private Object errorlist ;

	protected String getAuthorization_code() {
		return authorization_code;
	}

	protected void setAuthorization_code(String authorization_code) {
		this.authorization_code = authorization_code;
	}

	protected Object getErrorlist() {
		return errorlist;
	}

	protected void setErrorlist(Object errorlist) {
		this.errorlist = errorlist;
	}

	public ReturnObjFromAuthzOrchestration() {
		// TODO Auto-generated constructor stub
	}

}
