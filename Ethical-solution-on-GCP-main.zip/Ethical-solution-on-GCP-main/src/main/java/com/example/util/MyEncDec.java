package com.example.util;



import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;

public class MyEncDec {

    private static final String ALGORITHM = "AES";
    private static final byte[] KEY = "12341234123412341234123412341234".getBytes(StandardCharsets.UTF_8);

    public static String encrypt(String plainText) throws Exception {
        SecretKeySpec secretKey = new SecretKeySpec(KEY, ALGORITHM);
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encrypted = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(encrypted);
    }

    public static String decrypt(String encryptedText) throws Exception {
        SecretKeySpec secretKey = new SecretKeySpec(KEY, ALGORITHM);
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        byte[] decrypted = cipher.doFinal(Base64.getDecoder().decode(encryptedText));
        return new String(decrypted, StandardCharsets.UTF_8);
    }
    
    public static void main(String[] args) {

        String jwt = "eyJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiRVNNX0NPTVBBTlkiLCJlbWFpbCI6IkdCT0xBREVTSEFEQUBZQUhPTy5DT00iLCJzdWIiOiJFU01fQ09NUEFOWX5-R0JPTEFERVNIQURBQFlBSE9PLkNPTSIsImp0aSI6ImQ5NTgyZjZiLTQwYjAtNDY0OC1iNDdiLTA4MDE5MDhmYTU4ZCIsImlhdCI6MTY3NTc3Mjk5MywiZXhwIjoxNjc1NzczNTkzfQ.XYn2igaBMvLX4aV1XCLYn9S5CkyO6Bf8brI45tbhd6o";
        String enc="";
		try {
			enc = encrypt(jwt);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        String dec="";
		try {
			dec = decrypt(enc);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	System.out.println("***************************************************************");
       	System.out.println("***************************************************************");
       	System.out.println("ENCRYPTED");
    	System.out.println(enc);
    	
    	
    	System.out.println("***************************************************************");
       	System.out.println("***************************************************************");
    	System.out.println("DECRYPTED");
    	System.out.println(dec);
        
    	JWTGenerateValidateHMAC_esm jjwt = new JWTGenerateValidateHMAC_esm();
        
        Jws<Claims> token = jjwt.parseJwt(dec);
        
        if (token != null)
        {	System.out.println(token.getBody());
        }
        else
        {
        	System.out.println("Invalid TOKEN");
        }
    }
    
}