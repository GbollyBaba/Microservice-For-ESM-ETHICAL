package com.example.util;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendEmail {  
  
  public  void sendMail1(String from,String to,String sub ,String strmsg1){  
  
      Properties prop = new Properties();    
     
      prop.put("mail.smtp.host", "smtp.ionos.co.uk");
      prop.put("mail.smtp.port", "587");
      prop.put("mail.smtp.auth", "true");
     // prop.put("mail.smtp.starttls.enable", "true"); //TLS
   
      //get Session   
      Session session = Session.getDefaultInstance(prop,    
       new javax.mail.Authenticator() {    
       protected PasswordAuthentication getPasswordAuthentication() {    

    	  // return new PasswordAuthentication("horizon@ethical-soft.com","22yeovil$"); 
    	   return new PasswordAuthentication("horizon@ethical-soft.com","1630Tozamfara!"); 
    	   ///horizon@ethical-soft.com  FGDW$ukuk2022!
       }    
      });    
      //compose message    
      session.setDebug(true);
      try {  
	
	    Message msg1 = new MimeMessage(session);
	    
	    //anything@[MY_PROJECT_ID].appspotmail.com
	    //horrizon@ethicalservices.appspotmail.com
	    msg1.setFrom(new InternetAddress("horizon@ethical-soft.com", "horizon"));
	    msg1.addRecipient(Message.RecipientType.TO,
	                     new InternetAddress(to, "USER"));
	    msg1.setSubject(sub);
	   // msg1.setText(strmsg1);
	    msg1.setContent(strmsg1, "text/html");
	    Transport.send(msg1);
	  } catch (AddressException e) {
	    // ...
		  System.out.print("AddressException:::"+ e.getMessage());
		  e.printStackTrace();
	  } catch (MessagingException e) {
	    // ...
		  System.out.print("MessagingException:::"+ e.getMessage());
		  e.printStackTrace();
	  } catch (UnsupportedEncodingException e) {
	    // ...
		  System.out.print("UnsupportedEncodingException:::"+ e.getMessage());
		  e.printStackTrace();
	  }
}  
  public  void sendMail11(String from,String to,String sub,String msg){  
      //Get properties object    
      Properties prop = new Properties();    
     
      prop.put("mail.smtp.host", "smtp.gmail.com");
      prop.put("mail.smtp.port", "587");
      prop.put("mail.smtp.auth", "true");
      prop.put("mail.smtp.starttls.enable", "true"); //TLS
   // Enable STARTTLS


    /*  
      smtp.gmail.com

      Requires SSL: Yes

      Requires TLS: Yes (if available)

      Requires Authentication: Yes

      Port for SSL: 465

      Port for TLS/STARTTLS: 587
      */
      
      //get Session   
      Session session = Session.getDefaultInstance(prop,    
       new javax.mail.Authenticator() {    
       protected PasswordAuthentication getPasswordAuthentication() {    
       //return new PasswordAuthentication("gboladeshada@gmail.com","AnuIfe2014$");  
    	   //return new PasswordAuthentication("gboladeshada@gmail.com","AnuIfe2014$");  
    	   // return new PasswordAuthentication("evfplatform@gmail.com","ethicalsoft10*");  
    	   return new PasswordAuthentication("horizon@ethical-soft.com","FGDW$ukuk2022!");  
    	   ///horizon@ethical-soft.com  FGDW$ukuk2022!
       }    
      });    
      //compose message    
      try {  
    	  session.setDebug(true);
       MimeMessage message = new MimeMessage(session);    
       message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));    
       message.setSubject(sub);    
     //  message.setText(msg);    
      message.setContent(msg, "text/html");
      
       //send message  
       Transport.send(message);    
       System.out.println("message sent successfully");    
      } catch (MessagingException e) {throw new RuntimeException(e);}    
         
}  

  public  void sendMailUnification(String from,String to,String sub,String msg){  
      //Get properties object    
      Properties prop = new Properties();    
     
      prop.put("mail.smtp.host", "smtp.gmail.com");
      prop.put("mail.smtp.port", "587");
      prop.put("mail.smtp.auth", "true");
      prop.put("mail.smtp.starttls.enable", "true"); //TLS
   // Enable STARTTLS


    /*  
      smtp.gmail.com

      Requires SSL: Yes

      Requires TLS: Yes (if available)

      Requires Authentication: Yes

      Port for SSL: 465

      Port for TLS/STARTTLS: 587
      */
      
      //get Session   
      Session session = Session.getDefaultInstance(prop,    
       new javax.mail.Authenticator() {    
       protected PasswordAuthentication getPasswordAuthentication() {    
       //return new PasswordAuthentication("gboladeshada@gmail.com","AnuIfe2014$");  
    	   //return new PasswordAuthentication("gboladeshada@gmail.com","AnuIfe2014$");  
    	  // return new PasswordAuthentication("cnsunificationict@gmail.com","40THanniversary");  
    	   return new PasswordAuthentication("cnsunificationapp@gmail.com","Olatunji247#");  
    	   
       }    
      });    
      //compose message    
      try {  
    	  session.setDebug(true);
       MimeMessage message = new MimeMessage(session);    
       message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));    
       message.setSubject(sub);    
       //message.setText(msg);    
       message.setContent(msg, "text/html");
       //send message  
       Transport.send(message);    
       System.out.println("message sent successfully");    
      } catch (MessagingException e) {throw new RuntimeException(e);}    
         
}  



  
  }