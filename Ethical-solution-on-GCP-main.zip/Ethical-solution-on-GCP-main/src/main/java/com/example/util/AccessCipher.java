package com.example.util;



public class AccessCipher
{

    public AccessCipher()
    {
    }

    public static void main(String args[])
    {
        try
        {
            String xx = encrypt("918416");
            System.out.println(xx);
        }
        catch(ArrayIndexOutOfBoundsException arrayindexoutofboundsexception) { }
    }

   
    public static String encrypt(String aString)
    {
        //String sKey = generateKey();
    	String sKey = "918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416";
        String psSourceText = aString;
        String rsDestinationText = "";
        StringBuffer sb = new StringBuffer(psSourceText);
        sb = sb.reverse();
        psSourceText = sb.toString();
        int nTextLength = psSourceText.length();
        String sCurrentChar = "";
        for(; nTextLength > 0; nTextLength = psSourceText.length())
        {
            int ascii = psSourceText.charAt(0);
            psSourceText = psSourceText.substring(1);
            sCurrentChar = String.valueOf(ascii + Integer.parseInt(sKey.substring(nTextLength + 1, nTextLength + 2)));
            if(sCurrentChar.length() == 1)
            {
                sb = new StringBuffer();
                sb.append("00").append(sCurrentChar);
                sCurrentChar = sb.toString();
            } else
            if(sCurrentChar.length() == 2)
            {
                sb = new StringBuffer();
                sb.append("0").append(sCurrentChar);
                sCurrentChar = sb.toString();
            }
            sb = new StringBuffer();
            sb.append(rsDestinationText).append(sCurrentChar);
            rsDestinationText = sb.toString();
        }

        rsDestinationText = IntSkipString(rsDestinationText);
        sb = new StringBuffer(rsDestinationText);
        sb = sb.reverse();
        rsDestinationText = sb.toString();
        return rsDestinationText;
    }

    public static String decrypt(String aString)
    {
       //String sKey = generateKey();
    	String sKey = "918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416918416";
        String psSourceText = aString;
        String rsDestinationText = "";
        StringBuffer sb = new StringBuffer(psSourceText);
        sb = sb.reverse();
        psSourceText = sb.toString();
        psSourceText = IntSkipString(psSourceText);
        int nTextLength = psSourceText.length() / 3;
        String sCurrentChar = "";
        for(; nTextLength > 0; nTextLength = psSourceText.length() / 3)
        {
            sCurrentChar = psSourceText.substring(0, 3);
            psSourceText = psSourceText.substring(3);
            int ascii = Integer.parseInt(sCurrentChar);
            ascii = Integer.valueOf(sCurrentChar).intValue();
            sCurrentChar = String.valueOf((char)(ascii - Integer.parseInt(sKey.substring(nTextLength + 1, nTextLength + 2))));
            sb = new StringBuffer();
            sb.append(rsDestinationText).append(sCurrentChar);
            rsDestinationText = sb.toString();
        }

        sb = new StringBuffer(rsDestinationText);
        sb = sb.reverse();
        rsDestinationText = sb.toString();
        return rsDestinationText;
    }

    private static double round(double val, int places)
    {
        long factor = (long)Math.pow(10D, places);
        val *= factor;
        long tmp = Math.round(val);
        return (double)tmp / (double)factor;
    }

    private static String IntSkipString(String psSourceText)
    {
        int nBytes = 1;
        String rsDestinationText = "";
        String saTextChunks[] = new String[psSourceText.length()];
        String sTempChunk = "";
        String sTemp1 = "";
        if(psSourceText.length() % 2 == 0)
        {
            nBytes = 2;
        } else
        if(psSourceText.length() % 3 == 0)
        {
            nBytes = 3;
        }
        StringBuffer sb = new StringBuffer();
        int nCount;
        for(nCount = 2; psSourceText.length() != 0; nCount++)
        {
            saTextChunks[nCount] = psSourceText.substring(0, nBytes);
            psSourceText = psSourceText.substring(nBytes);
        }

        int nMax = nCount;
        nCount = 2;
        sTempChunk = "";
        int nChunkCount = 0;
        while(nCount <= nMax) 
        {
            if(nChunkCount < 2)
            {
                if(nCount % 2 == 0)
                {
                    sb = new StringBuffer();
                    if(saTextChunks[nCount] == null)
                    {
                        saTextChunks[nCount] = "";
                    }
                    sb.append(sTempChunk).append(saTextChunks[nCount]);
                    sTempChunk = sb.toString();
                } else
                {
                    sb = new StringBuffer();
                    if(saTextChunks[nCount] == null)
                    {
                        saTextChunks[nCount] = "";
                    }
                    sb.append(saTextChunks[nCount]).append(sTempChunk);
                    sTempChunk = sb.toString();
                }
                nChunkCount++;
                nCount++;
            } else
            {
                sb = new StringBuffer();
                sb.append(rsDestinationText).append(sTempChunk);
                rsDestinationText = sb.toString();
                sTempChunk = "";
                nChunkCount = 0;
            }
        }
        sb = new StringBuffer();
        sb.append(rsDestinationText).append(sTempChunk);
        rsDestinationText = sb.toString();
        return rsDestinationText;
    }
}
