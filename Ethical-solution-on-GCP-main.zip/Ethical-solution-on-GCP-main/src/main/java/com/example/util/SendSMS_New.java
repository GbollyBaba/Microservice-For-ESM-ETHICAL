package com.example.util;
import java.net.*;
import java.io.*;
 
public class SendSMS_New {
    public static void send(String ToMobileNumber,String SMSMessage) {
        String[] recipients = {ToMobileNumber};
        String xmlrecipients = "";
        String username = "gboladeshada@gmail.com";
        String apikey = "9a8fef0006116ac3f530842c831c0f4061cb1a42";
        //String sendername = "UNIFICATION";
        String sendername = "HORRIZON";
        String message = SMSMessage;
        String flash = "0";
        String theoutput = "";
        String randmsgid = Double.toString(Math.random());
        for( int i =0; i < recipients.length; i++ ){
            xmlrecipients += "<gsm><msidn>"+ recipients[i] + "</msidn><msgid>" + randmsgid + "_" + i + "</msgid>" + "</gsm>";
        }
        String xmlrequest =
                "<SMS>\n"
                + "<auth>"
                + "<username>" + username + "</username>\n"
                + "<apikey>" + apikey + "</apikey>\n"
                + "</auth>\n"
                + "<message>"
                + "<sender>" + sendername + "</sender>\n"
                + "<messagetext>" + message + "</messagetext>\n"
                + "<flash>" + flash + "</flash>\n"
                + "</message>\n"
                + "<recipients>\n"
                + xmlrecipients
                + "</recipients>\n"
                + "</SMS>";
        
        String theurl = "http://api.ebulksms.com:8080/sendsms.xml";
        SendSMS_New requester = new SendSMS_New();
        theoutput = requester.postXMLData(xmlrequest, theurl);
        if(theoutput.contains("100")){
            System.out.println("100");
        }
        else{
            System.out.println(theoutput);
        }
    }
    
    public String postXMLData(String xmldata, String urlpath){
        String result = "";
        try {
            URL myurl = new URL(urlpath);
            URLConnection urlconn = myurl.openConnection();
 
            urlconn.setRequestProperty("Content-Type", "text/xml");
            urlconn.setDoOutput(true);
            urlconn.setDoInput(true);
            urlconn.connect();
 
            //Create a writer to the url
            PrintWriter pw = new PrintWriter(urlconn.getOutputStream());
            pw.write(xmldata, 0, xmldata.length());
            pw.close();
 
            //Create a reader for the output of the connection
            BufferedReader reader = new BufferedReader(new InputStreamReader(urlconn.getInputStream()));
            String line = reader.readLine();
            while (line != null) {
                result = result + line + "\n";
                line = reader.readLine();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
 
}