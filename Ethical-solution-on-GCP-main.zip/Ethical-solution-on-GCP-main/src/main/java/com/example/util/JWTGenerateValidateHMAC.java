package com.example.util;



import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

import javax.crypto.spec.SecretKeySpec;
import javax.sql.DataSource;

import java.security.Key;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Date;
import java.util.UUID;
import com.example.util.*;

public class JWTGenerateValidateHMAC {

    public static void main(String[] args) {

        String jwt = createJwtSignedHMAC("ISSUER","GBOLADESHADA@GMAIL.COM","ISSUER"+"-"+"GBOLADESHADA@GMAIL.COM");
        
        int numRecConsistentWithSubjClaims=0;

        Jws<Claims> token = parseJwt(jwt);
        
        if (token != null)
        {	System.out.println(token.getBody());
        }
        else
        {
        	System.out.println("Invalid TOKEN");
        }
    }
    public static String ValidateTokenToReturnClaims (String strClaimsValue,int intACTOR_ID, Connection myconn) throws SQLException {

        
        Jws<Claims> token = parseJwt(strClaimsValue);
        System.out.println("*****************CLAIMS*******************");
        System.out.println(token.toString());
        System.out.println("******************************************");
        java.sql.CallableStatement cs = null;
        int numRecConsistentWithSubjClaims=0;
        String FRAUDERROR = "N";
        if (token != null)
        {	System.out.println(token.getBody());
        String TYPEOFACTOR = 	token.getBody().getSubject().split("~~")[0];
        String EMAILADDRESS = 	token.getBody().getSubject().split("~~")[1];
        System.out.println("EMAILADDRESS::::"+ token.getBody().getSubject().split("~~")[1]);
        System.out.println("TYPEOFACTOR::::"+ token.getBody().getSubject().split("~~")[0]);
        
        System.out.println("******************************************");
       
        
        try{
      	 
        	String StoredProcedure = "{ call SP_SECURITY_VALIDATE(?,?,?,?) }";
        	cs = myconn.prepareCall(StoredProcedure);
        	cs.setString(1, TYPEOFACTOR.trim());
        	cs.setString(2, EMAILADDRESS.trim());
        	cs.setInt(3, intACTOR_ID);
        	cs.registerOutParameter(4,Types.INTEGER);
        	cs.execute();

        	numRecConsistentWithSubjClaims=cs.getInt(4);
        	//cs.close();
        	//myconn.close();
        	}catch (Exception eee)
        	{
        	//cs.close();
        	//myconn.close();
        	eee.printStackTrace();
        	}
        
        
        
        if (numRecConsistentWithSubjClaims==1)
        {
        	System.out.println("VALID CONSISTENT CLAIMS DETAILS");
        	FRAUDERROR="N";
        }
        else
        {
         	System.out.println("VALID INCONSISTENT CLAIMS DETAILS... POSSIBLE MAN IN THE MIDDLE ATTACK");	
         	FRAUDERROR="Y";
         	
        }
        
        	
        }
        else
        {
        	System.out.println("Invalid TOKEN");
        	FRAUDERROR="X";
        
        }
        return FRAUDERROR;
    }
    
    public String ValidateToken (String sval) {

      
    	 MyEncDec myencdec = new MyEncDec();
         //replace the hashed token
         try {
        	 sval = myencdec.decrypt(sval);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
    	
    	
        Jws<Claims> token = parseJwt(sval);
        System.out.println("*****************CLAIMS*******************");
        //System.out.println(token.toString());
        System.out.println("******************************************");
        String res ="N";
        if (token != null)
        {	System.out.println(token.getBody());
        	System.out.println("VALID TOKEN");
        	res ="Y";
        }
        else
        {
        	System.out.println("Invalid TOKEN");
        	res ="N";
        }
        
        myencdec = null;
     
        
        return res;
    }

    public static Jws<Claims> parseJwt(String jwtString) {
    	
    	try {

     String secret = "femigboladestartedethicalsolutionintheyear2017";
    	//	String secret = "1234123412341234";

        Key hmacKey = new SecretKeySpec(Base64.getDecoder().decode(secret), SignatureAlgorithm.HS512.getJcaName());

        Jws<Claims> jwt = Jwts.parserBuilder()
                .setSigningKey(hmacKey)
                .build()
                .parseClaimsJws(jwtString);
        
        
        
        
        Instant now = Instant.now();
        long tokenexpiresat = Integer.parseInt(jwt.toString().split(",")[5].split("=")[1]);
       
       
        
        return jwt;
        }catch(io.jsonwebtoken.ExpiredJwtException  e1)
    	{
        	return null;
        	
    	}catch(io.jsonwebtoken.JwtException  e2)
    	{
    		
    		return null;
	    }
    	
    }


    public static String createJwtSignedHMAC(String strACTOR, String strEMAIL, String strSubject) {

       String secret = "femigboladestartedethicalsolutionintheyear2017";
    	//String secret = "1234123412341234";

        Key hmacKey = new SecretKeySpec(Base64.getDecoder().decode(secret), SignatureAlgorithm.HS512.getJcaName());
        //10  minutes duration in seconds
        int intDuration =600;
        
        Instant now = Instant.now();
        String jwtToken = Jwts.builder()
                .claim("name", strACTOR)
                .claim("email", strEMAIL)
                .setSubject(strSubject)
                .setId(UUID.randomUUID().toString())
                .setIssuedAt(Date.from(now))
                //.au
                .setExpiration(Date.from(now.plus(intDuration, ChronoUnit.SECONDS)))
                .signWith(hmacKey)
                .compact();
        
        
        MyEncDec myencdec = new MyEncDec();
        
        try {
			jwtToken = myencdec.encrypt(jwtToken);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        

        return jwtToken;
    }

}
