package com.example.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Arrays;
import java.util.Map;
import com.example.util.Student;

public class ObjectToMapExample {

    public static void main(String[] args) {

        ObjectMapper oMapper = new ObjectMapper();

        Student obj = new Student();
        obj.setName("Gbolade");
        obj.setAge(34);
        obj.setSkills(Arrays.asList("java","node"));

        // object -> Map
        Map<String, Object> map = oMapper.convertValue(obj, Map.class);
        System.out.println(map);

    }
    
    
    

}
