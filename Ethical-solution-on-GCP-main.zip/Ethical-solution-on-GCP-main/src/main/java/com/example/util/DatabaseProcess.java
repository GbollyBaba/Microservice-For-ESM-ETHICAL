package com.example.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;
import java.util.logging.Logger;

public class DatabaseProcess {
	
	
	
	// Define logger (Standard java.util.Logger)
		static Logger logger = Logger.getLogger(DatabaseProcess.class.getName());

	public Connection getSQLConnection()
    {
        Connection conn = null;
        Properties props = new Properties();
   
        

		String dbUrl = "jdbc:mysql://34.134.218.91/mydb1";
        //String dbUrl = "jdbc:mysql://sixth-storm-312515:us-central1:mydb1";
			String dbClass = "com.mysql.jdbc.Driver";
			String query = "Select count(*) FROM users";
			String userName = "mydb1", password = "password";
			try {

			Class.forName("com.mysql.jdbc.Driver");
			 conn = DriverManager.getConnection (dbUrl, userName, password);
        }
        catch(Exception ex)
        {
            System.out.println((new StringBuilder()).append("ERROR in Driver:").append(ex.getMessage()).toString());
        }
			finally
			{
				
			}
        return conn;
    }
	
}
