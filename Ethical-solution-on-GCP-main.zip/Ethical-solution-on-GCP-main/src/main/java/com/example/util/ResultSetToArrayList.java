package com.example.util;

import java.sql.*;
import java.util.ArrayList;

public class ResultSetToArrayList
{

    public ArrayList columnHeaders;
    public ArrayList tableData;
    public ArrayList rowData;
    public int RowCount;

    public ResultSetToArrayList()
    {
        RowCount = 0;
        
    }

    public ArrayList ResultSetToArrayList(ResultSet rset)
        throws SQLException
    {
        ResultSetMetaData rsResultSet = rset.getMetaData();
        int count = rsResultSet.getColumnCount();
        columnHeaders = new ArrayList();
        tableData = new ArrayList();
        while(rset.next()) 
        {
            rowData = new ArrayList();
            for(int i = 1; i <= count; i++)
            {
                if(rset.getObject(i) == null)
                {
                    rowData.add(" ");
                } else
                {
                    rowData.add(rset.getObject(i).toString());
                }
            }

            tableData.add(rowData);
            rowData = null;
            RowCount = RowCount + 1;
        }
        return tableData;
    }

    public ArrayList ColumnNames(ResultSet rset)
        throws SQLException
    {
        ResultSetMetaData rsResultSet = rset.getMetaData();
        int count = rsResultSet.getColumnCount();
        columnHeaders = new ArrayList(count);
        tableData = new ArrayList();
        for(int i = 1; i <= count; i++)
        {
            columnHeaders.add(rsResultSet.getColumnName(i));
        }

        return columnHeaders;
    }

    public int getColumnCount()
    {
        return columnHeaders.size();
    }

    public int getRowCount()
    {
        return tableData.size();
    }
}
