
package com.example.appengine;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.sql.Date;
import java.util.logging.Logger;
/*
 * 
  account name - oa_adelaja@hotmail.com

	  password - ethicalsoft10*
  
 * 
 */
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import org.apache.commons.lang3.StringEscapeUtils;

import com.api.json.JSONObject;
import com.example.util.*;
import com.example.util.JWTGenerateValidateHMAC;
import com.mysql.cj.jdbc.CallableStatement;
@SuppressWarnings("deprecation")

@WebServlet(
	    name = "ESM_PAY_RENT",
	    urlPatterns = {"/ESM_PAY_RENT"}
	)

public class ESM_PAY_RENT extends HttpServlet {

/**
 *
 * 
  mvn clean package appengine:deploy
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(ESM_PAY_RENT.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");

	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  String ESM_TENANT_ID= request.getParameter("ESM_TENANT_ID");
	  String ESM_PAYMENTS_TYPE_ID =request.getParameter("ESM_PAYMENTS_TYPE_ID");
	  String ESM_PAYMENTS_TYPE_CODE=  request.getParameter("ESM_PAYMENTS_TYPE_CODE");
	  String BEGIN_DATE=  request.getParameter("BEGIN_DATE");
	  String END_DATE=  request.getParameter("END_DATE");
	  String AMOUNT=  request.getParameter("AMOUNT");
	  String PAYMENT_REFERENCE=  request.getParameter("PAYMENT_REFERENCE");
	  String STATUS=  request.getParameter("STATUS");
	  String USER_ID=  request.getParameter("USER_ID");
	  String ACTOR_WHO_PAID=  request.getParameter("ACTOR_WHO_PAID");
	 
	
	  
	  
	  String NKEY=	request.getParameter("NKEY").trim()  ;
	  String CHANNEL=	request.getParameter("CHANNEL")  ;
	  
	  
	  	
////////////////////////////////////////SECURITY CHECK///////////////////////////////////////////////////////////////////////////////
JSONObject resultsVAlidate = new JSONObject();
String [] nkeyValues  = NKEY.split(" ");
if (nkeyValues.length == 5)
{
//EMAIL TYPEOFACTOR HQTECH IPADDRESS NKEY

String EMAIL = nkeyValues[0];
String TYPEOFACTOR = nkeyValues[1];
String MACHINE_NAME_VALUE = nkeyValues[2];
String MACHINE_IPADDRESS_VALUE = nkeyValues[3];
String NKEY_VALUE = nkeyValues[4];
JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
String res = gg.ValidateToken(NKEY_VALUE);
System.out.println("**********************SECURITY CHECK WITH OUATH2 & WEB TOKEN******************************* ");
System.out.println(" EMAIL :"+EMAIL);
System.out.println(" TYPEOFACTOR :"+TYPEOFACTOR);
System.out.println(" MACHINE_NAME_VALUE :"+MACHINE_NAME_VALUE);
System.out.println(" MACHINE_IPADDRESS_VALUE :"+MACHINE_IPADDRESS_VALUE);
System.out.println(" NKEY_VALUE :"+NKEY_VALUE);
System.out.println("************************************************************************************* ");


System.out.println(" ValidateToken :"+res);

if (!res.equalsIgnoreCase("Y"))
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}
}else
{
resultsVAlidate.put("errorcode", "-3000");
resultsVAlidate.put("errordescription",  "Incomplete paramets passed...");
response.getWriter().println(resultsVAlidate);
return;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	  String ROWSUPDATED="-1";
System.out.println("****************************************************************************");
System.out.println(" ESM_TENANT_ID:"+ESM_TENANT_ID);
System.out.println(" ESM_PAYMENTS_TYPE_ID :"+ESM_PAYMENTS_TYPE_ID);
System.out.println(" ESM_PAYMENTS_TYPE_CODE:"+ESM_PAYMENTS_TYPE_CODE);
System.out.println(" BEGIN_DATE :"+BEGIN_DATE);
System.out.println(" END_DATE:"+END_DATE);
System.out.println(" AMOUNT :"+AMOUNT);
System.out.println(" PAYMENT_REFERENCE:"+PAYMENT_REFERENCE);
System.out.println(" STATUS :"+STATUS);
System.out.println(" USER_ID:"+USER_ID);
System.out.println(" ACTOR_WHO_PAID :"+ACTOR_WHO_PAID);
System.out.println("****************************************************************************");
	  Statement stmt=null;
	  java.sql.CallableStatement cs = null;
	  JSONObject results = new JSONObject();
	  int numROWUPDATED =-1;
	  
	   
	  ArrayList kk =null;
	  String Token;
	 
	  if (pool!= null)
	  {
	  try (Connection con = pool.getConnection()) 
	  {
		   
		   System.out.println("<<<<<<<< CREATE CONNECTION  SUCCESSFULLY>>>>>>>>>>>>>");	
	  stmt = null;	 
	  
	
		  try{
  String StoredProcedure = "{ call ESM_SP_PAY_RENT(?,?,?,?,?,?,?,?,?,?,?) }";
	 
 cs = con.prepareCall(StoredProcedure);
 

//Parse the string into a date
 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

 java.sql.Date BeginDate = new java.sql.Date(dateFormat.parse(BEGIN_DATE).getTime());
 java.sql.Date EndDate = new java.sql.Date(dateFormat.parse(END_DATE).getTime());

	
	cs.setInt(1, Integer.parseInt(ESM_TENANT_ID));
	cs.setInt(2, Integer.parseInt(ESM_PAYMENTS_TYPE_ID.trim()));
	cs.setString(3, ESM_PAYMENTS_TYPE_CODE);
	cs.setDate(4,  BeginDate);
	cs.setDate(5,  EndDate);
	cs.setDouble(6, Double.parseDouble(AMOUNT));
	cs.setString(7, PAYMENT_REFERENCE);
	cs.setString(8, STATUS);
	cs.setInt(9, Integer.parseInt(USER_ID));
	cs.setString(10, ACTOR_WHO_PAID);
	cs.registerOutParameter(11, Integer.parseInt(ROWSUPDATED));
	
	cs.execute();

	numROWUPDATED=cs.getInt(11);

	          if (numROWUPDATED==1)
	          {
	        	 
	        	  
    		  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "0");
		      dbresult.put("errordescription",  " TENANT SUCCESSFULLY PAID THE RENT!");
		      results.put("ERROR", dbresult);
		      results.put("ROWSINSERTED", String.valueOf(numROWUPDATED));
		      results.put("ESM_TENANT_ID", ESM_TENANT_ID);
		      results.put("ESM_PAYMENTS_TYPE_ID", ESM_PAYMENTS_TYPE_ID);
		      results.put("ESM_PAYMENTS_TYPE_CODE", ESM_PAYMENTS_TYPE_CODE);
		      results.put("BEGIN_DATE", BEGIN_DATE);
		      results.put("END_DATE", END_DATE);
		      results.put("AMOUNT", AMOUNT);
		      results.put("PAYMENT_REFERENCE", PAYMENT_REFERENCE);
		      results.put("STATUS", STATUS);
		      results.put("USER_ID", USER_ID);
		      results.put("ACTOR_WHO_PAID", ACTOR_WHO_PAID);
		  
		      
		     
	          }
	          if (numROWUPDATED != 1)
	          {
    		  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "1");
		      dbresult.put("errordescription",  " APARTMENT COULD NOT BE ATTACHED  TO TENANT PROFILE! ");
		      results.put("ERROR", dbresult);
		      results.put("ROWSINSERTED", String.valueOf(numROWUPDATED));
		      results.put("ESM_TENANT_ID", ESM_TENANT_ID);
		      results.put("ESM_PAYMENTS_TYPE_ID", ESM_PAYMENTS_TYPE_ID);
		      results.put("ESM_PAYMENTS_TYPE_CODE", ESM_PAYMENTS_TYPE_CODE);
		      results.put("BEGIN_DATE", BEGIN_DATE);
		      results.put("END_DATE", END_DATE);
		      results.put("AMOUNT", AMOUNT);
		      results.put("PAYMENT_REFERENCE", PAYMENT_REFERENCE);
		      results.put("STATUS", STATUS);
		      results.put("USER_ID", USER_ID);
		      results.put("ACTOR_WHO_PAID", ACTOR_WHO_PAID);
	          }
		      
		      cs.close();
			  con.close();
	
		  } 
		  
		  catch(java.sql.SQLIntegrityConstraintViolationException sqlerror)
		  {
			  
			  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "-2");
		      dbresult.put("errordescription",  sqlerror.getMessage());
		      results.put("ERROR", dbresult);
		      results.put("ROWSINSERTED", String.valueOf(numROWUPDATED));
		      results.put("ESM_TENANT_ID", ESM_TENANT_ID);
		      results.put("ESM_PAYMENTS_TYPE_ID", ESM_PAYMENTS_TYPE_ID);
		      results.put("ESM_PAYMENTS_TYPE_CODE", ESM_PAYMENTS_TYPE_CODE);
		      results.put("BEGIN_DATE", BEGIN_DATE);
		      results.put("END_DATE", END_DATE);
		      results.put("AMOUNT", AMOUNT);
		      results.put("PAYMENT_REFERENCE", PAYMENT_REFERENCE);
		      results.put("STATUS", STATUS);
		      results.put("USER_ID", USER_ID);
		      results.put("ACTOR_WHO_PAID", ACTOR_WHO_PAID);
			  cs.close();
			  con.close();
			  sqlerror.printStackTrace();  
			  
		  }
		  catch (Exception eee)
		  	{
			  
			  
			  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "-1");
		      dbresult.put("errordescription",  eee.getMessage());
		      results.put("ERROR", dbresult);
		      results.put("ROWSINSERTED", String.valueOf(numROWUPDATED));
		      results.put("ESM_TENANT_ID", ESM_TENANT_ID);
		      results.put("ESM_PAYMENTS_TYPE_ID", ESM_PAYMENTS_TYPE_ID);
		      results.put("ESM_PAYMENTS_TYPE_CODE", ESM_PAYMENTS_TYPE_CODE);
		      results.put("BEGIN_DATE", BEGIN_DATE);
		      results.put("END_DATE", END_DATE);
		      results.put("AMOUNT", AMOUNT);
		      results.put("PAYMENT_REFERENCE", PAYMENT_REFERENCE);
		      results.put("STATUS", STATUS);
		      results.put("USER_ID", USER_ID);
		      results.put("ACTOR_WHO_PAID", ACTOR_WHO_PAID);
		    
		
		    		  cs.close();
					  con.close();
			  eee.printStackTrace();
			
		  }
		  
		  
		  finally
		  {
		  
		
		}
	  
	

	  } catch (Exception ee)
{
		  JSONObject dbresult = new JSONObject();
	      dbresult.put("errorcode", "-2");
	      dbresult.put("errordescription",  ee.getMessage());
	      results.put("ERROR", dbresult);
	      results.put("ROWSINSERTED", String.valueOf(numROWUPDATED));
	      results.put("ESM_TENANT_ID", ESM_TENANT_ID);
	      results.put("ESM_PAYMENTS_TYPE_ID", ESM_PAYMENTS_TYPE_ID);
	      results.put("ESM_PAYMENTS_TYPE_CODE", ESM_PAYMENTS_TYPE_CODE);
	      results.put("BEGIN_DATE", BEGIN_DATE);
	      results.put("END_DATE", END_DATE);
	      results.put("AMOUNT", AMOUNT);
	      results.put("PAYMENT_REFERENCE", PAYMENT_REFERENCE);
	      results.put("STATUS", STATUS);
	      results.put("USER_ID", USER_ID);
	      results.put("ACTOR_WHO_PAID", ACTOR_WHO_PAID);
	  ee.printStackTrace();
}
	  
	  
}

response.getWriter().println(results);
}

  




	  




}




