

package com.example.appengine;


import java.io.BufferedReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;
import com.example.appengine.ESM_Get_Country;
import com.example.util.JWTGenerateValidateHMAC;


@WebServlet(name = "ESM_Get_ApartmentTypes", value = "/ESM_Get_ApartmentTypes")
public class ESM_Get_ApartmentTypes extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Define logger (Standard java.util.Logger)
	static Logger logger = Logger.getLogger(ESM_Get_Country.class.getName());


  @Override
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  String NKEY = request.getParameter("NKEY").trim(); 
	  String CHANNEL = request.getParameter("CHANNEL"); 

	  

	  
      
	  	
////////////////////////////////////////SECURITY CHECK///////////////////////////////////////////////////////////////////////////////
/*
	  JSONObject resultsVAlidate = new JSONObject();
String [] nkeyValues  = NKEY.split(" ");
if (nkeyValues.length == 5)
{
//EMAIL TYPEOFACTOR HQTECH IPADDRESS NKEY

String EMAIL = nkeyValues[0];
String TYPEOFACTOR = nkeyValues[1];
String MACHINE_NAME_VALUE = nkeyValues[2];
String MACHINE_IPADDRESS_VALUE = nkeyValues[3];
String NKEY_VALUE = nkeyValues[4];
JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
String res = gg.ValidateToken(NKEY_VALUE);
System.out.println("**********************SECURITY CHECK WITH OUATH2 & WEB TOKEN******************************* ");
System.out.println(" EMAIL :"+EMAIL);
System.out.println(" TYPEOFACTOR :"+TYPEOFACTOR);
System.out.println(" MACHINE_NAME_VALUE :"+MACHINE_NAME_VALUE);
System.out.println(" MACHINE_IPADDRESS_VALUE :"+MACHINE_IPADDRESS_VALUE);
System.out.println(" NKEY_VALUE :"+NKEY_VALUE);
System.out.println("************************************************************************************* ");


System.out.println(" ValidateToken :"+res);

if (!res.equalsIgnoreCase("Y"))
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}
}else
{
resultsVAlidate.put("errorcode", "-3000");
resultsVAlidate.put("errordescription",  "Incomplete paramets passed...");
response.getWriter().println(resultsVAlidate);
return;
}
*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


      JSONArray results = null;
      String  SQL_SELECT = " SELECT ESM_APARTMENT_ID,APARTMENT_CODE,APARTMENT_NAME,APARTMENT_DESCRIPTION"
      		+ ",STATUS FROM ESM_APARTMENT  WHERE STATUS ='A' ";
      System.out.println(SQL_SELECT);

      PreparedStatement preparedStatement =null;
  		try {
			  try (Connection conn = pool.getConnection()) {
			   System.out.println("<<<<<<<< CREATE CONNECTION  SUCCESSFULLY>>>>>>>>>>>>>");
			   System.out.println("<<<<<<<< ABOUT TO GET THE RECORDS >>>>>>>>>>>>>");
			    preparedStatement = conn.prepareStatement(SQL_SELECT) ;
			    ResultSet data = preparedStatement.executeQuery();
			   System.out.println("<<<<<<<< GOT THE RECORDS  SUCCESSFULLY>>>>>>>>>>>>>");
		          results = new JSONArray();
		          JSONObject item;
		          for(; data.next(); results.add(item))
		          {
		              item = new JSONObject();
		              item.put("ESM_APARTMENT_ID", String.valueOf(data.getInt("ESM_APARTMENT_ID")));
		              item.put("APARTMENT_CODE", data.getString("APARTMENT_CODE"));
		              item.put("APARTMENT_NAME", data.getString("APARTMENT_NAME"));
		              item.put("APARTMENT_DESCRIPTION", data.getString("APARTMENT_DESCRIPTION"));
		              
		          }
		          
		          preparedStatement.close();
		          conn.close();
		          
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
    
    	 
          
         
         
          
        
          

        
      }
      catch(Exception e)
      {
          results = new JSONArray();
          JSONObject item = new JSONObject();
          item.put("APARTMENT_TYPES","");
          results.add(item);
          e.printStackTrace();
      }
      JSONObject resultsObj = new JSONObject(); 
      resultsObj.put("APARTMENT_TYPES", results);
      response.getWriter().println(resultsObj);
  }


  
}
