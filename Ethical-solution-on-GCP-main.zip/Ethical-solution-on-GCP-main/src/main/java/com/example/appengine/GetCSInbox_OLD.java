
package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;


@WebServlet(name = "GetCSInbox_OLD", value = "/getCSInbox_OLD")
public class GetCSInbox_OLD extends HttpServlet {


/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
static Logger logger = Logger.getLogger(GetCSInbox_OLD.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	 response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");

	     String EVWID =request.getParameter("EVWID");
	     String NKEY=request.getParameter("NKEY").trim() ;
	     

			   String  sql = " ";
	        Connection con =null;
	        
	        JSONArray results = null;
	        try
	        {
	        	con = pool.getConnection();
		        System.out.println(sql);
	            
		        sql = sql + " SELECT J.*  FROM     ";
		        sql = sql + " (SELECT a.TESTIMONY_ID,    ";
		        sql = sql + " 'TO:'  FROM_OR_TO,    ";
		        sql = sql + " a.EVWID,    ";
		        sql = sql + " (SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where  a.EVWID=c.EVW_ID ) FULLNAME ,    ";
		        sql = sql + " a.REQ_MSG RES_MSG,      "; 
		        sql = sql + " a.REQUEST_DATE RESPONSE_DATE,      "; 
		        sql = sql + " a.REQUEST_TIME   RESPONSE_TIME, "; 
		        sql = sql + " a.EVWID    '_'    a.RESPONSE_EVWID  REQRES "; 
		        sql = sql + " FROM TBL_TESTIMONY  a    ";
		        sql = sql + " where a.RESPONSE_EVWID='"+EVWID+"'     ";
		        sql = sql + " and a.REQ_TYPE='M'     ";
		        sql = sql + " union    ";
		        sql = sql + " SELECT a.TESTIMONY_ID,    ";
		        sql = sql + " 'FR:',    ";
		        sql = sql + " a.RESPONSE_EVWID ,    ";
		        sql = sql + " (SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where   c.EVW_ID=a.RESPONSE_EVWID)  ,    ";
		        sql = sql + " a.RES_MSG,      "; 
		        sql = sql + " a.RESPONSE_DATE,      "; 
		        sql = sql + " a.RESPONSE_TIME  , ";    
		        sql = sql + " a.EVWID    '_'    a.RESPONSE_EVWID  REQRES "; 
		        sql = sql + " FROM TBL_TESTIMONY a      ";
		        sql = sql + " where a.RESPONSE_EVWID='"+EVWID+"'      ";
		        sql = sql + " and a.REQ_TYPE='M'     ";
		        
		        sql = sql + " UNION    ";
		        
		        sql = sql + " SELECT a.TESTIMONY_ID,     ";  
		        sql = sql + " 'FR:'    ,    ";
		        sql = sql + " a.EVWID,      "; 
		        sql = sql + " (SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where  a.EVWID=c.EVW_ID )  ,    ";   
		        sql = sql + " a.REQ_MSG RES_MSG,      "; 
		        sql = sql + " a.REQUEST_DATE RESPONSE_DATE,      "; 
		        sql = sql + " a.REQUEST_TIME   RESPONSE_TIME, "; 
		        sql = sql + " a.EVWID    '_'    a.RESPONSE_EVWID  REQRES "; 
		        sql = sql + " FROM TBL_TESTIMONY  a    ";
		        sql = sql + " where a.EVWID='"+EVWID+"'     ";   
		        sql = sql + " and a.REQ_TYPE='M'     ";   
		        sql = sql + " union       ";
		        sql = sql + " SELECT a.TESTIMONY_ID,      "; 
		        sql = sql + " 'TO:',      "; 
		        sql = sql + " a.RESPONSE_EVWID ,      "; 
		        sql = sql + " (SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where   c.EVW_ID=a.RESPONSE_EVWID)  ,      "; 
		        sql = sql + " a.RES_MSG,      "; 
		        sql = sql + " a.RESPONSE_DATE,      "; 
		        sql = sql + " a.RESPONSE_TIME ,  "; 
		        sql = sql + " a.EVWID    '_'    a.RESPONSE_EVWID  REQRES "; 
		        sql = sql + " FROM TBL_TESTIMONY  a    ";
		        sql = sql + " where a.EVWID='"+EVWID+"'     ";    
		        sql = sql + " and a.REQ_TYPE='M'      ";  
		        sql = sql + " order by  1 DESC,6 ASC, 7 ASC   ";
		       
		        sql = sql + " ) J        ";
		        sql = sql + " LIMIT  30   ";


	            
	            
	            
	            
	            
	            
	            PreparedStatement getAllUsers = con.prepareStatement(sql);
	            ResultSet data = getAllUsers.executeQuery();
	            results = new JSONArray();
	            JSONObject item;
	            int k=1;
	            for(; data.next(); )
	            {
	                
	            	item = new JSONObject();
	                item.put("MESSAGE_ID", data.getString("TESTIMONY_ID"));
	                item.put("FROM_OR_TO", data.getString("FROM_OR_TO"));
	                item.put("EVWID", data.getString("EVWID"));
	                item.put("FULLNAME", data.getString("FULLNAME"));
	                String msg =data.getString("RES_MSG");
	                String reqdate =data.getString("RESPONSE_DATE");
	                String reqtime =data.getString("RESPONSE_TIME");
	               if (msg ==null) msg="";
	                if (reqdate ==null) reqdate="";
	                if (reqtime ==null) reqtime="";
	item.put("MSG", msg);
	item.put("REQUEST_DATE",reqdate);
	item.put("REQUEST_TIME",reqtime);

	JSONObject resObj = new JSONObject(); 
	resObj.put("MESSAGE_"+data.getString("TESTIMONY_ID") + "_" +data.getString("FROM_OR_TO") , item);

		results.add(resObj);
	      }

	            getAllUsers.close();
	            con.close();
	        }
	        catch(SQLException e)
	        {
	            results = new JSONArray();
	            JSONObject item = new JSONObject();
	             item.put("MESSAGE_ID", "");
	                item.put("FROM_OR_TO", "");
	             item.put("EVWID", "");
	             item.put("FULLNAME", "");
	item.put("MSG", "");
	item.put("REQUEST_DATE", e.getMessage());
	item.put("REQUEST_TIME",sql);


	JSONObject resObj = new JSONObject(); 
	resObj.put("MESSAGE_FRM_TO_ERROR"  , item);

		results.add(resObj);
	            e.printStackTrace();
	        }
	        JSONObject resultsObj = new JSONObject(); 
	        resultsObj.put("INBOX_LAST_30_MESSAGES", results);
	        System.out.println(""); 
	        System.out.println(resultsObj);


	        response.getWriter().println(resultsObj);
	        }
}
		