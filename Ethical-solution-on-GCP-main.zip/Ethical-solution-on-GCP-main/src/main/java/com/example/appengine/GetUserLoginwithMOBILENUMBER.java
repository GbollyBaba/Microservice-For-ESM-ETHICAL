package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;


import com.api.json.JSONArray;
import com.api.json.JSONObject;

import com.example.util.*;


@WebServlet(name = "GetUserLoginwithMOBILENUMBER", value = "/getUserLoginwithMOBILENUMBER")
public class GetUserLoginwithMOBILENUMBER extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Define logger (Standard java.util.Logger)
	static Logger logger = Logger.getLogger(GetUserLoginwithMOBILENUMBER.class.getName());


  @SuppressWarnings("rawtypes")
@Override
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");


	  JSONObject result =null;
	    JSONArray results = null;
	    
	  
	  
	    PreparedStatement getAllUsers =null;
	    Connection con=null;
	      Statement stmt=null;
	      ResultSet data=null;
	
	  	String MOBILENUMBER =request.getParameter("MOBILENUMBER")  ; 
	  	String xPASSWORD =request.getParameter("xPASSWORD")  ;
	  	String APPID = request.getParameter("APPID");
	  	String NKEY = request.getParameter("NKEY").trim();
  		
   
 
      String loginSQL="";

		
	  try (Connection conn = pool.getConnection()) {
      stmt = conn.createStatement();
      loginSQL = "   SELECT Curdate() as MyDate, curtime() as MyTime,a.EVW_ID ,a.DATE_CREATE" +
"D ,a.TIME_CREATED , a.FIRSTNAME, a.MIDDLENAME , a.SURNAME , a.BIRTHDATE, a.STREET1 , a.STREET2 ,"
+ " a.LGA , a.STATE, a.MARITAL_STATUS , a.MOBILENUMBER , a.MACADDRESS , a.EMAILADDRESS , a.PASSWORD ,"
+ " a.CONFIRMPASSWORD , a.TOKEN , a.APP_ID  , a.LOGINCOUNT , a.STATUS,a.CUSTOMER_CLASSIFICATION  "
+ "FROM  TBL_USERS a WHERE  "
;
      loginSQL = loginSQL + "  a.APP_ID= '"+APPID.trim()+ "' AND trim(a.MOBILENUMBER) ='"+MOBILENUMBER.trim() + "'";
      System.out.println(loginSQL);
    
      
      result = new JSONObject();
      data = stmt.executeQuery(loginSQL);
      ResultSetToArrayList rrResultSetToArrayList = new ResultSetToArrayList();
      ArrayList kk = (ArrayList)rrResultSetToArrayList.ResultSetToArrayList(data);
      
     // ArrayList arrColumnNames = (ArrayList) rrResultSetToArrayList.ColumnNames(data);
      if(kk.size() >= 1)
      {
       System.out.println("1111111111111111111");
      ArrayList rowAl = (ArrayList)kk.get(0);
      result.put("LoginDate", rowAl.get(0).toString());
      result.put("LoginTime", rowAl.get(1).toString());
      result.put("LASTNAME", rowAl.get(7).toString());
      result.put("FIRSTNAME", rowAl.get(5).toString());
      result.put("COMMUTER_ID", rowAl.get(2).toString());
      result.put("MIDDLENAME", rowAl.get(6).toString());
      result.put("SURNAME", rowAl.get(7).toString());
      result.put("BIRTHDATE", rowAl.get(8).toString());
      result.put("STREET1", rowAl.get(9).toString());
      result.put("STREET2", rowAl.get(10).toString());
      result.put("LGA", rowAl.get(11).toString());
      result.put("STATE", rowAl.get(12).toString());
      result.put("MARITAL_STATUS", rowAl.get(13).toString());
      result.put("MOBILENUMBER", rowAl.get(14).toString());
      result.put("MACADDRESS", rowAl.get(15).toString());
      result.put("EMAILADDRESS", rowAl.get(16).toString());
      //result.put("PASSWORD", rowAl.get(17).toString());
      //result.put("CONFIRMPASSWORD", rowAl.get(18).toString());
      result.put("TOKEN", rowAl.get(19).toString());
      result.put("APP_ID", rowAl.get(20).toString());
      result.put("LOGINCOUNT", rowAl.get(21).toString());
      result.put("STATUS", rowAl.get(22).toString());
      result.put("CUSTOMER_CLASSIFICATION", rowAl.get(23).toString());
      System.out.println("LOGINGCOUNT VALUE++++++++===========" + rowAl.get(21).toString().trim());
      if (Integer.parseInt(rowAl.get(21).toString().trim())<10)
      {
    	     System.out.println("2222222222222222222222");
    	  String vpass= rowAl.get(17).toString().trim();
    	  System.out.println("PASSWORD VALUE++++++++===========" + vpass);
    	  if (vpass.equalsIgnoreCase(xPASSWORD.trim()))
    	  {
    		  System.out.println("333333333333333333333333");
      result.put("errorcode", "0");
      
      result.put("errordescription", "Successfully Logon");
      boolean bb = stmt.execute((new StringBuilder()).append("UPDATE TBL_USERS set LOGINCOUNT = 0  where  MOBILENUMBER='").append(MOBILENUMBER.trim()).append("'  ").toString());
    	  }else
    	  {
    	      result.put("LoginDate", "");
    	      result.put("LoginTime", "");
    	      result.put("LASTNAME", "");
    	      result.put("FIRSTNAME", "");
    	      result.put("EVW_ID", "");
    	      result.put("MIDDLENAME", "");
    	      result.put("SURNAME", "");
    	      result.put("BIRTHDATE", "");
    	      result.put("STREET1", "");
    	      result.put("STREET2", "");
    	      result.put("LGA", "");
    	      result.put("STATE", "");
    	      result.put("MARITAL_STATUS", "");
    	      result.put("MOBILENUMBER", "");
    	      result.put("MACADDRESS", "");
    	      result.put("EMAILADDRESS", "");
    	      result.put("PASSWORD", "");
    	      result.put("CONFIRMPASSWORD", "");
    	      result.put("TOKEN", "");
    	      result.put("APP_ID", "");
    	      result.put("LOGINCOUNT", "");
    	      result.put("STATUS", "");
    	      result.put("CUSTOMER_CLASSIFICATION", "");
    	      result.put("errorcode", "-1");
    	      result.put("errordescription", " login failed WRONG PASSWORD!!!!");
    	      boolean bb = stmt.execute((new StringBuilder()).append("UPDATE TBL_USERS set LOGINCOUNT = LOGINCOUNT +1   where  MOBILENUMBER='").append(MOBILENUMBER.trim()).append("'  ").toString());
    	    	  
    	  }
      }else
      {
    	   result.put("LoginDate", "");
 	      result.put("LoginTime", "");
 	      result.put("LASTNAME", "");
 	      result.put("FIRSTNAME", "");
 	      result.put("EVW_ID", "");
 	      result.put("MIDDLENAME", "");
 	      result.put("SURNAME", "");
 	      result.put("BIRTHDATE", "");
 	      result.put("STREET1", "");
 	      result.put("STREET2", "");
 	      result.put("LGA", "");
 	      result.put("STATE", "");
 	      result.put("MARITAL_STATUS", "");
 	      result.put("MOBILENUMBER", "");
 	      result.put("MACADDRESS", "");
 	      result.put("EMAILADDRESS", "");
 	      result.put("PASSWORD", "");
 	      result.put("CONFIRMPASSWORD", "");
 	      result.put("TOKEN", "");
 	      result.put("APP_ID", "");
 	      result.put("LOGINCOUNT", "");
 	      result.put("STATUS", "");
 	      result.put("CUSTOMER_CLASSIFICATION", "");
    	  result.put("errorcode", "-4");
          result.put("errordescription", "10 unsuccessful login count. Account is blocked!!!! Contact the administrator!!!!"); 
          boolean bb = stmt.execute((new StringBuilder()).append("UPDATE TBL_USERS set LOGINCOUNT = LOGINCOUNT +1  where  MOBILENUMBER='").append(MOBILENUMBER.trim()).append("'  ").toString());
          
      }
      
          // set the logincount to zero after successful logon

    
      data.close();
      stmt.close();
      conn.close();
      //return response;
      }else{
      result.put("LoginDate", "");
      result.put("LoginTime", "");
      result.put("LASTNAME", "");
      result.put("FIRSTNAME", "");
      result.put("EVW_ID", "");
      result.put("MIDDLENAME", "");
      result.put("SURNAME", "");
      result.put("BIRTHDATE", "");
      result.put("STREET1", "");
      result.put("STREET2", "");
      result.put("LGA", "");
      result.put("STATE", "");
      result.put("MARITAL_STATUS", "");
      result.put("MOBILENUMBER", "");
      result.put("MACADDRESS", "");
      result.put("EMAILADDRESS", "");
      result.put("PASSWORD", "");
      result.put("CONFIRMPASSWORD", "");
      result.put("TOKEN", "");
      result.put("APP_ID", "");
      result.put("LOGINCOUNT", "");
      result.put("STATUS", "");
      result.put("CUSTOMER_CLASSIFICATION", "");
      result.put("errorcode", "-1");
      result.put("errordescription", "Login Failed");
      boolean bb = stmt.execute((new StringBuilder()).append("UPDATE TBL_USERS set LOGINCOUNT = LOGINCOUNT +1  where  trim(MOBILENUMBER)='").append(MOBILENUMBER.trim()).append("'  ").toString());
 
      data.close();
      stmt.close();
      conn   .close();
      //return response;
      }
      }catch(Exception exception)
     {System.out.println("error in method :::getUserwithMOBILENUMBER:::" + exception.getMessage());
      try {
		if (data!= null) data.close();
		if (stmt!= null) stmt.close();
		if (con!= null)  con.close();
	   
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
  }



      response.getWriter().println(result);
	    }
}