
package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;


import com.api.json.JSONArray;
import com.api.json.JSONObject;

import com.example.util.*;


@WebServlet(name = "EthSol_DELETE_TABLE_DATA", value = "/EthSol_DELETE_TABLE_DATA")
public class EthSol_DELETE_TABLE_DATA extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Define logger (Standard java.util.Logger)
	static Logger logger = Logger.getLogger(EthSol_DELETE_TABLE_DATA.class.getName());
	


  @SuppressWarnings("rawtypes")
@Override
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");


	  JSONObject result =null;
	    JSONArray results = null;
	    
	  
	  
	    PreparedStatement getAllUsers =null;
	    Connection con=null;
	      Statement stmt=null;
	      ResultSet data=null;
	
	
	    String TYPE_OF_ACTOR =request.getParameter("TYPE_OF_ACTOR");
	  	String NKEY = request.getParameter("NKEY").trim();
  	     String loginSQL="";
  	   ArrayList kk =null;
       
       ArrayList arrColumnNames = null;
	  try (Connection conn = pool.getConnection()) {
      stmt = conn.createStatement();
      
     
          loginSQL = " TRUNCATE  TABLE "+TYPE_OF_ACTOR+"  ";

    
 
	 

      
      
      System.out.println(loginSQL);
    
   
     
      boolean bb = stmt.execute(loginSQL);
      System.out.println("SUCCESSFULLY truncate the table  "+TYPE_OF_ACTOR+"  ");
   
		if (stmt!= null) stmt.close();
		if (conn!= null)  conn.close();
      //return response;
           }catch(Exception exception)
     {
        	   exception.printStackTrace();
    System.out.println("Table  "+TYPE_OF_ACTOR+"   error in method :::EthSol_DELETE_TABLE_DATA:::" + exception.getMessage());
      try {
  
  		if (stmt!= null) stmt.close();
  	
	   
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
  }
	


      response.getWriter().println(results);
	    }
}