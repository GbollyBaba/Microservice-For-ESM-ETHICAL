
package com.example.appengine;


//https://towardsdatascience.com/6-lesser-known-sql-techniques-to-save-you-100-hours-a-month-10ceed47d3fe
//https://cprosenjit.medium.com/10-time-series-forecasting-methods-we-should-know-291037d2e285

//https://www.youtube.com/watch?v=UlyTIrwepQ8

//gbolade@sallysoftinternational.com
//fe7z(QPQ3eY.c4g

//GCP password  ethicalsoft10*
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;




import com.example.util.*;
import com.example.util.JWTGenerateValidateHMAC;
import com.mysql.cj.jdbc.CallableStatement;


@WebServlet(name = "ESM_ListByESMCOY", value = "/ESM_ListByESMCOY")
public class ESM_ListByESMCOY extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Define logger (Standard java.util.Logger)
	static Logger logger = Logger.getLogger(ESM_ListByESMCOY.class.getName());
	
	
	
	
	
	


  @SuppressWarnings("rawtypes")
@Override
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	  
				String remoteAddr = "";
				
				if (request != null) {
				    remoteAddr = request.getHeader("X-FORWARDED-FOR");
				
				}
				System.out.println("remoteAddr:::::::"+ remoteAddr);
				
				
				String hostname = request.getRemoteHost(); // hostname
				System.out.println("hostname"+hostname);
				
				String computerName = null;
				String remoteAddress = request.getRemoteAddr();
				System.out.println("remoteAddress: " + remoteAddress);
				try {
				    InetAddress inetAddress = InetAddress.getByName(remoteAddress);
				    System.out.println("inetAddress: " + inetAddress);
				computerName = inetAddress.getHostName();
				
				System.out.println("computerName: " + computerName);
				
				
				if (computerName.equalsIgnoreCase("localhost")) {
				        computerName = java.net.InetAddress.getLocalHost().getCanonicalHostName();
				    } 
				} catch (UnknownHostException e) {
				
				    }
				
				System.out.println("computerName: " + computerName);

	/////////////////////////////////////////////////////////////////////////////////////////////////////////	  


	  JSONObject result =null;
	    JSONArray results = null;
	    
	  
	  
	    PreparedStatement getAllUsers =null;
	    Connection con=null;
	      Statement stmt=null;
	      java.sql.CallableStatement cs= null;
	      ResultSet data=null;
	
	    String ESM_COMPANY_ID =request.getParameter("ESM_COMPANY_ID");
	    
	    String TYPE_OF_DATA =request.getParameter("TYPE_OF_DATA");

	  	String NKEY = request.getParameter("NKEY").trim();
	  	String CHANNEL = request.getParameter("CHANNEL");
	  	
	  	System.out.println("**********************SEARCH VALUE****************************** ");
	  	System.out.println(" ESM_COMPANY_ID :"+ESM_COMPANY_ID);
	  	System.out.println(" TYPE_OF_DATA :"+TYPE_OF_DATA);
	  	System.out.println(" NKEY :"+NKEY);
	  	System.out.println(" CHANNEL :"+CHANNEL);

	  	System.out.println("*****************************************************************");
	  	
	  	
	  	
	  	
	  	
////////////////////////////////////////SECURITY CHECK///////////////////////////////////////////////////////////////////////////////
JSONObject resultsVAlidate = new JSONObject();
String [] nkeyValues  = NKEY.split(" ");
if (nkeyValues.length == 5)
{
//EMAIL TYPEOFACTOR HQTECH IPADDRESS NKEY

String EMAIL = nkeyValues[0];
String TYPEOFACTOR = nkeyValues[1];
String MACHINE_NAME_VALUE = nkeyValues[2];
String MACHINE_IPADDRESS_VALUE = nkeyValues[3];
String NKEY_VALUE = nkeyValues[4];
JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
String res = gg.ValidateToken(NKEY_VALUE);
System.out.println("**********************SECURITY CHECK WITH OUATH2 & WEB TOKEN******************************* ");
System.out.println(" EMAIL :"+EMAIL);
System.out.println(" TYPEOFACTOR :"+TYPEOFACTOR);
System.out.println(" MACHINE_NAME_VALUE :"+MACHINE_NAME_VALUE);
System.out.println(" MACHINE_IPADDRESS_VALUE :"+MACHINE_IPADDRESS_VALUE);
System.out.println(" NKEY_VALUE :"+NKEY_VALUE);
System.out.println("************************************************************************************* ");


System.out.println(" ValidateToken :"+res);

if (!res.equalsIgnoreCase("Y"))
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}
}else
{
resultsVAlidate.put("errorcode", "-3000");
resultsVAlidate.put("errordescription",  "Incomplete paramets passed...");
response.getWriter().println(resultsVAlidate);
return;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


		String loginSQL="";
		String StoredProcedure = "";
  	   ArrayList kk =null;
       
       ArrayList arrColumnNames = null;
	  try (Connection conn = pool.getConnection()) {
      stmt = conn.createStatement();

      System.out.println(" ESM_COMPANY_ID :"+ESM_COMPANY_ID);
      TYPE_OF_DATA =TYPE_OF_DATA.trim().toUpperCase();
      
      switch(TYPE_OF_DATA) {
      case "APARTMENTS_TAKEN":
    	  StoredProcedure = "{ call ESM_SP_TAKEN_APARTMENTS_BY_COY(?) }";
        break;
      case "APARTMENTS_VACANT":
    	  StoredProcedure = "{ call ESM_SP_VACANT_APARTMENTS_BY_COY(?) }";
        break;
      
      
      case "PAYMENTS_TYPE_BY_COY":
    	  StoredProcedure = "{ call ESM_SP_PAYMENTS_TYPE_BY_COY(?) }";
        break;
        
      case "TENANT_VACANT_SEARCH_BY_COY_ID":
    	  StoredProcedure = "{ call ESM_SP_TENANT_VACANT_SEARCH_BY_COY_ID(?) }";
        break;
        
      case "TENANT_OCCUPIED_SEARCH_BY_COY_ID":
    	  StoredProcedure = "{ call ESM_SP_TENANT_OCCUPIED_SEARCH_BY_COY_ID(?) }";
        break;
      case "ESM_SP_HOMEOWNER_SEARCH_BY_COY_ID":
    	  StoredProcedure = "{ call ESM_SP_HOMEOWNER_SEARCH_BY_COY_ID(?) }";
        break;
      
      
      
      default:
        // code block
    }
      


      cs = conn.prepareCall(StoredProcedure);
      cs.setInt(1, Integer.parseInt(ESM_COMPANY_ID));
      data = cs.executeQuery();
      
    
    
      
     
      results = new JSONArray();

      ResultSetToArrayList rrResultSetToArrayList = new ResultSetToArrayList();
       kk = (ArrayList) rrResultSetToArrayList.ResultSetToArrayList(data);
       int sizeoftable =kk.size();
      
       arrColumnNames = (ArrayList) rrResultSetToArrayList.ColumnNames(data);
       int sizeofcolumnslist =arrColumnNames.size();
       if (sizeoftable>0)
       {
       for (int k=0 ; k <sizeoftable ; k++)
       {
      
    	   result = new JSONObject();
 // System.out.println(kk.get(k).toString());
      ArrayList rowAl = (ArrayList) kk.get(k);
      //populate the record into the json objects
      for (int int_Column =0;int_Column<sizeofcolumnslist; int_Column++  )
      {
    
    	  String strColumnName = arrColumnNames.get(int_Column).toString().toUpperCase();
    	  result.put(strColumnName, rowAl.get(int_Column).toString());
      }
      //System.out.println(result.toString());
      results.add(result);

      }
       }
      data.close();
      stmt.close();
      conn.close();
      //return response;
           }catch(Exception exception)
     {

    System.out.println("   error in method :::ESM_SP_TAKEN_APARTMENTS_BY_COY:::" + exception.getMessage());
      try {
    	  
    	  exception.printStackTrace();
		if (data!= null) data.close();
		if (stmt!= null) stmt.close();
	
	   
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
  }
	


      response.getWriter().println(results);
	    }
}