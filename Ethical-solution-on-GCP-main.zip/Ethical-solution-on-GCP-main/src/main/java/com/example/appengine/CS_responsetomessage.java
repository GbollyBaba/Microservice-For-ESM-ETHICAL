

package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONObject;


@WebServlet(name = "CS_responsetomessage", value = "/CS_responsetomessage")
public class CS_responsetomessage extends HttpServlet {

/**
 * 
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(CS_responsetomessage.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  

 Connection con=null;
  Statement stmt=null;
  String MESSAGE_ID=request.getParameter("MESSAGE_ID") ;
		  String RES_MSG=request.getParameter("RES_MSG")   	;
  String NKEY=request.getParameter("NKEY").trim()   ;
  
  String updateSQL="";
  JSONObject result =null;
 
  try { 
	  con = pool.getConnection();
  stmt = con.createStatement();

updateSQL = (new StringBuilder()).append(updateSQL).append(" UPDATE TBL_TESTIMONY   SET    RESPONSE_DATE =CURDATE(),RESPONSE_TIME =CURTIME()          ").toString();
updateSQL = (new StringBuilder()).append(updateSQL).append("   , RES_MSG = '").append(RES_MSG).append("' ").toString();
updateSQL = (new StringBuilder()).append(updateSQL).append("   WHERE  TESTIMONY_ID  = '").append(MESSAGE_ID).append("' ").toString();



  Boolean bbb = Boolean.valueOf(false);
  System.out.println("********************************************************************************" +
"***"
);
  System.out.println("SQL:::"+ updateSQL );
  System.out.println("***********************************************************************************");

					  try{
					  stmt = con.createStatement();
					   bbb = Boolean.valueOf(stmt.execute(updateSQL ));
					  System.out.println("SUCCESSFULLULLY RESPONDED TO  MESSAGE ID>>>>>>>>>>>>*****" + MESSAGE_ID);
					 
					   result = new JSONObject();
					  result.put("errorcode", "0");
					  result.put("errordescription", "Successful RESPONDED TO MESSAGE ID>>>>>>>>>>>>" + MESSAGE_ID);
					  stmt.close();
					  con.close();
					
					  
					  stmt.close();
					  con.close();
					
					  }
					  catch (Exception eee)
					  {
					
					  eee.printStackTrace();
					  System.out.println("**********************************************************************");
					  System.out.println(updateSQL);
					  System.out.println("**********************************************************************");
					  
					
					   result = new JSONObject();
					  result.put("errorcode", "-1");
					  result.put("errordescription", (new StringBuilder()).append("NOT CREATED OF  RESPONSE TO MESSAGE ID>>>>>>>>>>>  "+ MESSAGE_ID).append(eee.getLocalizedMessage()).toString());
					
					  stmt.close();
					  con.close();
					
					  }finally
					  {
					  stmt.close();
					  con.close();
					
					}
					 
}  catch (Exception eee)
  {
  }
  response.getWriter().println(result);
  }

}

