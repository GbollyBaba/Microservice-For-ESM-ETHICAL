

package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONObject;


@WebServlet(name = "CS_testimonyprayer", value = "/CS_testimonyprayer")
public class CS_testimonyprayer extends HttpServlet {

/**
 * 
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(CS_testimonyprayer.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  

 Connection con=null;
  Statement stmt=null;
  
  String EVWID=request.getParameter("EVWID") ;
  String REQ_TYPE = request.getParameter("REQ_TYPE") ;
  String REQ_MSG = request.getParameter("REQ_MSG") ;
  String NKEY = request.getParameter("NKEY").trim()   ;   

String insertSQL="";
String insertVALUES="";
JSONObject result =null;
try { 
	  con = pool.getConnection();
stmt = con.createStatement();

insertSQL=insertSQL + "     INSERT INTO TBL_TESTIMONY(  ";
insertSQL=insertSQL + " REQUEST_DATE    ";
insertSQL=insertSQL + " ,REQUEST_TIME    ";
insertSQL=insertSQL + " ,EVWID   ";
insertSQL=insertSQL + " ,REQ_TYPE   ";
insertSQL=insertSQL + " ,REQ_MSG   ";


insertSQL=insertSQL + " )  ";

insertVALUES =insertVALUES +" VALUES (  CURDATE(), CURTIME()  ";

insertVALUES =insertVALUES +" ,'"+EVWID+"'   ";
insertVALUES =insertVALUES +" ,'"+REQ_TYPE+"'   ";
insertVALUES =insertVALUES +" ,'"+REQ_MSG+"'   ";
insertVALUES =insertVALUES  + " )  ";


Boolean bbb = Boolean.valueOf(false);
System.out.println("********************************************************************************" +
"***"
);
System.out.println("SQL:::"+ insertSQL + insertVALUES);
System.out.println("***********************************************************************************");

try{
stmt = con.createStatement();
bbb = Boolean.valueOf(stmt.execute(insertSQL + insertVALUES));
System.out.println("SUCCESSFULLULLY INSERYTED TESTIMONY REQUEST LOG*****");

 result = new JSONObject();
result.put("errorcode", "0");
result.put("errordescription", "Successful CREATION OF  SERVICE TESTIMONY LOG ");
stmt.close();
con.close();


stmt.close();
con.close();

}
catch (Exception eee)
{

eee.printStackTrace();
System.out.println("**********************************************************************");
System.out.println(insertSQL + insertVALUES);
System.out.println("**********************************************************************");


 result = new JSONObject();
result.put("errorcode", "-1");
result.put("errordescription", (new StringBuilder()).append("NOT CREATED OF  SERVICE TESTIMONY LOG  ").append(eee.getLocalizedMessage()).toString());

con.close();

}finally
{
stmt.close();
con.close();

}
}catch (Exception eee1)
{
	 result = new JSONObject();
	 result.put("errorcode", "-1");
	 result.put("errordescription", (new StringBuilder()).append("COULD NOT CONNECT TO DATABASE  ").append(eee1.getLocalizedMessage()).toString());
	 eee1.printStackTrace();
}

System.out.println(""); 
System.out.println(result);


response.getWriter().println(result);
}

}

