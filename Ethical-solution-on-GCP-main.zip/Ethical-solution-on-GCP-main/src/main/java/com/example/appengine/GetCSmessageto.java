

package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;


@WebServlet(name = "GetCSmessageto", value = "/getCSmessageto")
public class GetCSmessageto extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Define logger (Standard java.util.Logger)
	static Logger logger = Logger.getLogger(GetCSmessagefrom.class.getName());


  @Override
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");


	  JSONObject result =null;
	    JSONArray results = null;
	    
	    String EVWID = request.getParameter("EVWID");
	    String NKEY = request.getParameter("NKEY").trim();
	    Connection con = null;
	    PreparedStatement getAllUsers =null;
	   

	
	  	  try
	        {
	  	  	  con = pool.getConnection();
	        
	         String  sql = " SELECT TESTIMONY_ID,EVWID,REQ_TYPE,REQ_MSG,RES_MSG,REQUEST_DATE,REQUEST_TIME,RESPONSE_DATE,RESPONSE_TIME,RESPONSE_EVWID FROM TBL_TESTIMONY  where RESPONSE_EVWID='"+EVWID+"'  and REQ_TYPE='M' order by REQUEST_DATE ASC,REQUEST_TIME ASC";
		        System.out.println(sql);
	             getAllUsers = con.prepareStatement(sql);
	            ResultSet data = getAllUsers.executeQuery();
	            results = new JSONArray();
	            JSONObject item;
	            for(; data.next(); results.add(item))
	            {
	                item = new JSONObject();
	                item.put("MESSAGE_ID", data.getString("TESTIMONY_ID"));
	                item.put("EVWID", data.getString("EVWID"));
	                item.put("REQ_TYPE", data.getString("REQ_TYPE"));
	item.put("REQ_MSG", data.getString("REQ_MSG"));
	item.put("RES_MSG", data.getString("RES_MSG"));
	item.put("REQUEST_DATE", data.getString("REQUEST_DATE"));
	item.put("REQUEST_TIME", data.getString("REQUEST_TIME"));
	item.put("RESPONSE_DATE", data.getString("RESPONSE_DATE"));
	item.put("RESPONSE_TIME", data.getString("RESPONSE_TIME"));
	item.put("RESPONSE_EVWID", data.getString("RESPONSE_EVWID"));
	          }

	            getAllUsers.close();
	            con.close();
	        }
	        catch(SQLException e)
	        {
	            results = new JSONArray();
	            JSONObject item = new JSONObject();
	             item.put("EVWID", "");
	                item.put("REQ_TYPE", "");
	                item.put("MESSAGE_ID", "");
	item.put("REQ_MSG", "");
	item.put("RES_MSG", "");
	item.put("REQUEST_DATE", "");
	item.put("REQUEST_TIME", "");
	item.put("RESPONSE_DATE", "");
	item.put("RESPONSE_TIME", "");
	item.put("RESPONSE_EVWID", "");
	            results.add(item);
	            e.printStackTrace();
	        }
	        JSONObject resultsObj = new JSONObject(); 
	        resultsObj.put("MESSAGE_TO_ME", results);
	        System.out.println(resultsObj);


	        response.getWriter().println(resultsObj);
	     
	    } 
}
