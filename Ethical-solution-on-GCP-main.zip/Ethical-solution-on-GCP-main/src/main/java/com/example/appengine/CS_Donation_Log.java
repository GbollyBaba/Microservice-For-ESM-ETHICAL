
package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;
import com.example.util.*;

import org.apache.commons.lang3.*;

@WebServlet(name = "CS_Donation_Log", value = "/CS_Donation_Log")
public class CS_Donation_Log extends HttpServlet {

/**
 * 
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(CS_Donation_Log.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  

 Connection con=null;
  Statement stmt=null;
  String EVWID =request.getParameter("EVWID");
  String DONATION_ID=request.getParameter("DONATION_ID") ;
  String AMOUNT =request.getParameter("AMOUNT") ;
  String RESPONSE_CODE=request.getParameter("RESPONSE_CODE") ;
  String NKEY=request.getParameter("NKEY").trim() ;  
  
  JSONObject result =null;
  
  String resp_code = RESPONSE_CODE + "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX";
  resp_code = resp_code.substring(0,30);
  String insertSQL="";
  String insertVALUES="";
  try { 
	  con = pool.getConnection();
  
  stmt = con.createStatement();

insertSQL=insertSQL + "     INSERT INTO TBL_DONATION_LOG ";
insertSQL=insertSQL + "     ( ";
insertSQL=insertSQL + "     TRAN_DATE  , ";
insertSQL=insertSQL + "     TRAN_TIME  , ";
insertSQL=insertSQL + "     EVW_ID , ";
insertSQL=insertSQL + "     DONATION_ID , ";
insertSQL=insertSQL + "     AMOUNT , ";
insertSQL=insertSQL + "     RESPONSE_CODE  ";
insertSQL=insertSQL + "     ) ";

insertVALUES =insertVALUES +" VALUES (  CURDATE(), CURTIME() ";

insertVALUES =insertVALUES +" ,'"+EVWID+"'   ";
insertVALUES =insertVALUES +" ,'"+DONATION_ID+"'   ";
insertVALUES =insertVALUES +" ,'"+AMOUNT+"'   ";
insertVALUES =insertVALUES +" ,'"+resp_code+"'   ";
insertVALUES =insertVALUES  + " )  ";



  Boolean bbb = Boolean.valueOf(false);
  System.out.println("********************************************************************************" +
"***"
);
  System.out.println("SQL:::"+ insertSQL + insertVALUES);
  System.out.println("***********************************************************************************");

  stmt = con.createStatement();
   bbb = Boolean.valueOf(stmt.execute(insertSQL + insertVALUES));
  System.out.println("SUCCESSFULLULLY INSERYTED DONATION   LOG*****");
 
   result = new JSONObject();
  result.put("errorcode", "0");
  result.put("errordescription", "Successful CREATED DONATION   LOG ");
  stmt.close();
  con.close();

  
  stmt.close();
  con.close();

  }
  catch (Exception eee)
  {

  eee.printStackTrace();
  System.out.println("**********************************************************************");
  System.out.println(insertSQL + insertVALUES);
  System.out.println("**********************************************************************");
  

   result = new JSONObject();
  result.put("errorcode", "-1");
  result.put("errordescription", (new StringBuilder()).append("NOT CREATED OF   DONATION   LOG ").append(eee.getLocalizedMessage()).toString());

  try {
	  con.close();
	stmt.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


  }finally
  {
  try {
	stmt.close();
	  con.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


}
  System.out.println(""); 
  System.out.println(result);


  response.getWriter().println(result);
}



}