

package com.example.appengine;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.logging.Logger;
/*
 * 
  account name - oa_adelaja@hotmail.com

	  password - ethicalsoft10*
  
 * 
 */
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringEscapeUtils;

import com.api.json.JSONObject;
import com.example.util.*;
import com.mysql.cj.jdbc.CallableStatement;
@SuppressWarnings("deprecation")

@WebServlet(
	    name = "EthSol_ACKNOWLEDGE_INVOICE_LPO_ORDER",
	    urlPatterns = {"/EthSol_ACKNOWLEDGE_INVOICE_LPO_ORDER"}
	)

public class EthSol_ACKNOWLEDGE_INVOICE_LPO_ORDER extends HttpServlet {

/**
 *
 * 
  mvn clean package appengine:deploy
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(EthSol_ACKNOWLEDGE_INVOICE_LPO_ORDER.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");

	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  
	  
	  /*
	   * 
	   * 
	   CREATE PROCEDURE  SP_CONFIRM_LPO_ORDER(
IN vLPO_ISSUER_ID int  ,
IN vLPO_NUMBER char(50),
IN vISSUER_CONFIRMATION char(1),
IN vISSUER_CONFIRMATION_REMARKS  char(80),
OUT vROWSUPDATED int 
 )
	   * 
	   * 
	   */

	  String LPO_ISSUER_ID= request.getParameter("LPO_ISSUER_ID");
	  String LPO_NUMBER =request.getParameter("LPO_NUMBER");
	  String ISSUER_ACKNOWLEDGE_INVOICE=  request.getParameter("ISSUER_ACKNOWLEDGE_INVOICE");
	  String ISSUER_ACKNOWLEDGE_REMARKS =request.getParameter("ISSUER_ACKNOWLEDGE_REMARKS");
	  
	  String NKEY=	request.getParameter("NKEY").trim()  ;
	  String CHANNEL=	request.getParameter("CHANNEL")  ;
	  
	  	
////////////////////////////////////////SECURITY CHECK///////////////////////////////////////////////////////////////////////////////
JSONObject resultsVAlidate = new JSONObject();
String [] nkeyValues  = NKEY.split(" ");
if (nkeyValues.length == 5)
{
//EMAIL TYPEOFACTOR HQTECH IPADDRESS NKEY

String EMAIL = nkeyValues[0];
String TYPEOFACTOR = nkeyValues[1];
String MACHINE_NAME_VALUE = nkeyValues[2];
String MACHINE_IPADDRESS_VALUE = nkeyValues[3];
String NKEY_VALUE = nkeyValues[4];
JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
String res = gg.ValidateToken(NKEY_VALUE);
System.out.println("**********************SECURITY CHECK WITH OUATH2 & WEB TOKEN******************************* ");
System.out.println(" EMAIL :"+EMAIL);
System.out.println(" TYPEOFACTOR :"+TYPEOFACTOR);
System.out.println(" MACHINE_NAME_VALUE :"+MACHINE_NAME_VALUE);
System.out.println(" MACHINE_IPADDRESS_VALUE :"+MACHINE_IPADDRESS_VALUE);
System.out.println(" NKEY_VALUE :"+NKEY_VALUE);
System.out.println("************************************************************************************* ");


System.out.println(" ValidateToken :"+res);

if (!res.equalsIgnoreCase("Y"))
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}
}else
{
resultsVAlidate.put("errorcode", "-3000");
resultsVAlidate.put("errordescription",  "Incomplete paramets passed...");
response.getWriter().println(resultsVAlidate);
return;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	  
	  String ROWSUPDATED="-1";
	 
	 
System.out.println("****************************************************************************");
System.out.println(" LPO_ISSUER_ID:"+LPO_ISSUER_ID);
System.out.println(" LPO_NUMBER :"+LPO_NUMBER);
System.out.println(" ISSUER_AKNOWLEDGE_INVOICE:"+ISSUER_ACKNOWLEDGE_INVOICE);
System.out.println(" ISSUER_AKNOWLEDGE_REMARKS :"+ISSUER_ACKNOWLEDGE_REMARKS);
System.out.println("****************************************************************************");
	  Statement stmt=null;
	  java.sql.CallableStatement cs = null;
	  JSONObject results = new JSONObject();
	  int confirmedLPOs=-1;
	  
	   
	  ArrayList kk =null;
	  String Token;
	 
	  if (pool!= null)
	  {
	  try (Connection con = pool.getConnection()) 
	  {
		   
		   System.out.println("<<<<<<<< CREATE CONNECTION  SUCCESSFULLY>>>>>>>>>>>>>");	
	  stmt = null;	 
	  
	
		  try{
System.out.println( "{ call SP_ISSUER_ACKNOWLEDGE_INVOICE(?,?,?,?,?) }");
  String StoredProcedure = "{ call SP_ISSUER_ACKNOWLEDGE_INVOICE(?,?,?,?,?) }";
	 
 cs = con.prepareCall(StoredProcedure);
 
 
 
	    
	cs.setInt(1, Integer.parseInt(LPO_ISSUER_ID));
	cs.setString(2, LPO_NUMBER.trim());
	cs.setString(3, ISSUER_ACKNOWLEDGE_INVOICE.trim());
	cs.setString(4, ISSUER_ACKNOWLEDGE_REMARKS.trim().replaceAll("'", " "));
	cs.registerOutParameter(5, Integer.parseInt(ROWSUPDATED));
	  
	cs.execute();

	          confirmedLPOs=cs.getInt(5);
	          
	          if (confirmedLPOs==1)
	          {
    		  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "0");
		      dbresult.put("errordescription",  " LPO NUMBER ["+LPO_NUMBER+"] INVOICE SUCESSFULLY ACKNOWLEDGED");
		      results.put("ERROR", dbresult);
		      results.put("ROWSUPDATED", String.valueOf(confirmedLPOs));
		      results.put("LPO_NUMBER", LPO_NUMBER);
	          }
	          if (confirmedLPOs != 1)
	          {
    		  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "1");
		      dbresult.put("errordescription",  " LPO NUMBER ["+LPO_NUMBER+"] NOT INVOICE SUCESSFULLY ACKNOWLEDGED ");
		      results.put("ERROR", dbresult);
		      results.put("ROWSUPDATED", String.valueOf(confirmedLPOs));
		      results.put("LPO_NUMBER", LPO_NUMBER);
	          }
		      
		      cs.close();
			  con.close();
	
		  } 
		  
		  catch(java.sql.SQLIntegrityConstraintViolationException sqlerror)
		  {
			  
			  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "-2");
		      dbresult.put("errordescription",  sqlerror.getMessage());
		      results.put("ERROR", dbresult);
		      results.put("ROWSUPDATED", String.valueOf(confirmedLPOs));
		      results.put("LPO_NUMBER", LPO_NUMBER);
			  cs.close();
			  con.close();
			  sqlerror.printStackTrace();  
			  
		  }
		  catch (Exception eee)
		  	{
			  
			  
			  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "-1");
		      dbresult.put("errordescription",  eee.getMessage());
		      results.put("ERROR", dbresult);
		      results.put("ROWSUPDATED", String.valueOf(confirmedLPOs));
		    
		
		    		  cs.close();
					  con.close();
			  eee.printStackTrace();
			
		  }
		  
		  
		  finally
		  {
		  
		
		}
	  
	

	  } catch (Exception ee)
{
		  JSONObject dbresult = new JSONObject();
	      dbresult.put("errorcode", "-2");
	      dbresult.put("errordescription",  ee.getMessage());
	      results.put("ERROR", dbresult);
	      results.put("ROWSUPDATED", String.valueOf(confirmedLPOs));

	  ee.printStackTrace();
}
	  
	  
}

response.getWriter().println(results);
}

  




	  




}




