

package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;
import com.example.util.*;

import org.apache.commons.lang3.*;


@WebServlet(name = "CS_messaging", value = "/CS_messaging")
public class CS_messaging extends HttpServlet {

/**
 * 
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(CS_messaging.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  String EVWID = request.getParameter("EVWID"); 
	  String REQ_TYPE = request.getParameter("REQ_TYPE"); 
	  String REQ_MSG = request.getParameter("REQ_MSG"); 
	  String TO_EVWID = request.getParameter("RESPONSE_EVWID"); 
	
	  String NKEY = request.getParameter("NKEY").trim(); 
	
	  JSONObject result =null;
	  Connection con;
      Statement stmt;
      String insertSQL="";
      String insertVALUES="";
      try { 
    	  con = pool.getConnection();
      stmt = con.createStatement();
     
insertSQL=insertSQL + "     INSERT INTO TBL_TESTIMONY(  ";
insertSQL=insertSQL + " REQUEST_DATE    ";
insertSQL=insertSQL + " ,REQUEST_TIME    ";
insertSQL=insertSQL + " ,EVWID   ";
insertSQL=insertSQL + " ,REQ_TYPE   ";
insertSQL=insertSQL + " ,REQ_MSG  ,RESPONSE_EVWID ";


insertSQL=insertSQL + " )  ";

insertVALUES =insertVALUES +" VALUES (  CURDATE(), CURTIME()  ";

insertVALUES =insertVALUES +" ,'"+EVWID+"'   ";
insertVALUES =insertVALUES +" ,'"+REQ_TYPE+"'   ";
insertVALUES =insertVALUES +" ,'"+REQ_MSG+"'   ";
insertVALUES =insertVALUES +" ,'"+TO_EVWID+"'   ";
insertVALUES =insertVALUES  + " )  ";


      Boolean bbb = Boolean.valueOf(false);
      System.out.println("********************************************************************************" +
"***"
);
      System.out.println("SQL:::"+ insertSQL + insertVALUES);
      System.out.println("***********************************************************************************");

      try{
      stmt = con.createStatement();
       bbb = Boolean.valueOf(stmt.execute(insertSQL + insertVALUES));
      System.out.println("SUCCESSFULLULLY INSERYTED MESSAGE TO >>>>>>>>>>>>*****" + TO_EVWID);
     
       result = new JSONObject();
      result.put("errorcode", "0");
      result.put("errordescription", "Successful CREATION OF  MESSAGE TO>>>>>>>>>>>>" + TO_EVWID);
      stmt.close();
      con.close();
 
      
      stmt.close();
      con.close();
      
     
      }
      catch (Exception eee)
      {
  
      eee.printStackTrace();
      System.out.println("**********************************************************************");
      System.out.println(insertSQL + insertVALUES);
      System.out.println("**********************************************************************");
      
   
       result = new JSONObject();
      result.put("errorcode", "-1");
      result.put("errordescription", (new StringBuilder()).append("NOT CREATED OF  CREATION OF  MESSAGE TO>>>>>>>>>>>  "+ TO_EVWID).append(eee.getLocalizedMessage()).toString());

      stmt.close();
      con.close();

      }finally
      {
      stmt.close();
      con.close();
    
  }
  } catch (Exception eee)
      {
	  eee.printStackTrace();
      }
      
 
      System.out.println(result);


      response.getWriter().println(result);
      
}
}

	