
package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;


import com.api.json.JSONArray;
import com.api.json.JSONObject;

import com.example.util.*;

//EthSol_LoginWithEmail
@WebServlet(name = "EthSol_LoginWithEmail", value = "/EthSol_LoginWithEmail")
public class EthSol_LoginWithEmail extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Define logger (Standard java.util.Logger)
	static Logger logger = Logger.getLogger(EthSol_LoginWithEmail.class.getName());
	


  @SuppressWarnings("rawtypes")
@Override
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");


	  JSONObject result =null;
	    JSONArray results = null;
	    
	  
	  
	    PreparedStatement getAllUsers =null;
	    Connection con=null;
	      Statement stmt=null;
	      ResultSet data=null;
	
	  	String EMAILADDRESS =request.getParameter("EMAILADDRESS")  ; 
	  	String xPASSWORD =request.getParameter("xPASSWORD")  ;
	    String TYPE_OF_ACTOR =request.getParameter("TYPE_OF_ACTOR");
	  	String NKEY = request.getParameter("NKEY").trim();
  	     String loginSQL="";
  	   ArrayList kk =null;
       
       ArrayList arrColumnNames = null;
	  try (Connection conn = pool.getConnection()) {
      stmt = conn.createStatement();
      
      switch (TYPE_OF_ACTOR) {
      case "LPO_BORROWER":  
    	  loginSQL= "   SELECT Curdate() as CurrentDate, curtime() as CurrentTime,B.STATE,B.COUNTRY,B.LGA, A.* "
    	  		+ ", A.LPO_BORROWER_ID as ID";
          loginSQL = loginSQL + "  from "+TYPE_OF_ACTOR+" A,  COUNTRY B ";

          loginSQL = loginSQL + "  WHERE 1=1 ";
        
          loginSQL = loginSQL + "  AND A.LGA_ID = B.LGA_ID ";
          loginSQL = loginSQL + "  AND   upper(trim(A.EMAILADDRESS)) = '"+EMAILADDRESS.trim().toUpperCase()+"'   ";
		break;
      case "LPO_INVESTOR":   
    	  loginSQL= "  SELECT Curdate() as CurrentDate, curtime() as CurrentTime,B.STATE,B.COUNTRY,B.LGA, A.* "
    	  		+ ", A.LPO_INVESTOR_ID as ID";
          loginSQL = loginSQL + "  from "+TYPE_OF_ACTOR+" A,  COUNTRY B ";

          loginSQL = loginSQL + "  WHERE 1=1 ";
    
         loginSQL = loginSQL + "  AND A.LGA_ID = B.LGA_ID ";
          loginSQL = loginSQL + "  AND   upper(trim(A.EMAILADDRESS)) = '"+EMAILADDRESS.trim().toUpperCase()+"'    ";
		break;
               
      case "LPO_INVESTOR_COY":   
    	  loginSQL= "  SELECT Curdate() as CurrentDate, curtime() as CurrentTime,B.STATE,B.COUNTRY,B.LGA, A.*"
    	  		+ ", A.LPO_INVESTOR_COY_ID as ID ";
          loginSQL = loginSQL + "  from "+TYPE_OF_ACTOR+" A,  COUNTRY B ";
          loginSQL = loginSQL + "  WHERE 1=1";
       
          loginSQL = loginSQL + "  AND A.LGA_ID = B.LGA_ID ";
          loginSQL = loginSQL + "  AND   upper(trim(A.EMAILADDRESS)) = '"+EMAILADDRESS.trim().toUpperCase()+"'    ";
		break;
		
      case "LPO_SUPPLIER_COY":   
    	  loginSQL= "   SELECT Curdate() as CurrentDate, curtime() as CurrentTime,B.STATE,B.COUNTRY,B.LGA, A.* "
    	  		+ ", A.LPO_SUPPLIER_COY_ID as ID ";
          loginSQL = loginSQL + "  from "+TYPE_OF_ACTOR+" A,  COUNTRY B ";

          loginSQL = loginSQL + "  WHERE 1=1";

         loginSQL = loginSQL + "  AND A.LGA_ID = B.LGA_ID ";
          loginSQL = loginSQL + "  AND  upper(trim(A.EMAILADDRESS)) = '"+EMAILADDRESS.trim().toUpperCase()+"'    ";
		break;
		
		
      case "LPO_ISSUER":   
    	  loginSQL= "   SELECT Curdate() as CurrentDate, curtime() as CurrentTime,B.STATE,B.COUNTRY,B.LGA, A.*  "
    	  		+ ", A.LPO_ISSUER_ID as ID ";
          loginSQL = loginSQL + "  from "+TYPE_OF_ACTOR+" A,  COUNTRY B ";

          loginSQL = loginSQL + "  WHERE 1=1  ";
         
          loginSQL = loginSQL + "  AND A.LGA_ID = B.LGA_ID ";
          loginSQL = loginSQL + "  AND   trim(A.EMAILADDRESS) = '"+EMAILADDRESS.trim().toUpperCase()+"'    ";
		break;
      
    
  }
	 

      
      
      System.out.println(loginSQL);
    
      
      result = new JSONObject();
      data = stmt.executeQuery(loginSQL);
      ResultSetToArrayList rrResultSetToArrayList = new ResultSetToArrayList();
       kk = (ArrayList)rrResultSetToArrayList.ResultSetToArrayList(data);
      
       arrColumnNames = (ArrayList) rrResultSetToArrayList.ColumnNames(data);
      if(kk.size() >= 1)
      {
      ArrayList rowAl = (ArrayList)kk.get(0);
  
      //populate the record into the json objects
      for (int int_Column =0;int_Column<arrColumnNames.size(); int_Column++  )
      {
    
    	  String strColumnName = arrColumnNames.get(int_Column).toString().toUpperCase();
    	  result.put(strColumnName, rowAl.get(int_Column).toString());
      }

      System.out.println(result.get("LOGINCOUNT").toString());
      
      if (Integer.parseInt(result.get("LOGINCOUNT").toString())<10)
      {
    	 
    	     System.out.println("<<<<LoGINCOUNT IS LESS 10>>>>>>");
    	  String vpass=  result.get("PASSWORD").toString().trim();
    	  String vstatus=  result.get("STATUS").toString().trim().toUpperCase();
    	  System.out.println("PASSWORD VALUE++++++++===========" + vpass);
    	  if (vpass.equalsIgnoreCase(xPASSWORD.trim()))
    	  {
    		  
    		// switch statement 
    		  switch(vstatus)
    		  {
    		  
    		     case "A" :
    		      result.put("errorcode", "0");
    		      result.put("TYPE_OF_ACTOR", TYPE_OF_ACTOR);
       		      result.put("errordescription", "Successfully Logon by "+TYPE_OF_ACTOR+" !!!");
    		        break; 
    		     
    		     case "I"  :
    		    	//romove the  record from the result JSON object whe the authentication fails
       		      
       			  result.put("errorcode", "20");
       			result.put("TYPE_OF_ACTOR", TYPE_OF_ACTOR);
       		      result.put("errordescription", "Successfully Logon by "+TYPE_OF_ACTOR+" But You are Yet to Validate  your Profile!!!");
       	
    		        break; 
    		    
    		     default : 
    		    	//romove the  record from the result JSON object whe the authentication fails
       		      for (int int_Column =0;int_Column<arrColumnNames.size(); int_Column++  )
       		      {
       		    	  String strColumnName = arrColumnNames.get(int_Column).toString().toUpperCase();
       		    	  result.remove(strColumnName);
       		      }
       			  result.put("errorcode", "-9");
       		      result.put("errordescription", "UNKNOWN STATUS!!!");
    		  }
    		  
    		  
    		  
    		  
      System.out.println("Pasword compare successful");

    //remove the password from the payload
      result.remove("PASSWORD");
      result.remove("CONFIRMPASSWORD");
      //add to token information
      //Pick the sensitive data for  SUBJECT
      String strSubject = TYPE_OF_ACTOR.toUpperCase().trim()+"~~"+EMAILADDRESS.toUpperCase().trim();
  	JWTGenerateValidateHMAC zz = new JWTGenerateValidateHMAC();
      String jtoken  = zz.createJwtSignedHMAC(TYPE_OF_ACTOR, EMAILADDRESS,strSubject);
      result.put("NKEY", jtoken);
      
      boolean bb = stmt.execute((new StringBuilder()).append("UPDATE "+TYPE_OF_ACTOR+" set LOGINCOUNT = 0  where  EMAILADDRESS='").append(EMAILADDRESS.trim().toUpperCase()).append("'  ").toString());
    	  }else
    	  {
    		  //romove the  record from the result JSON object whe the authentication fails
    	      for (int int_Column =0;int_Column<arrColumnNames.size(); int_Column++  )
    	      {
    	    	  String strColumnName = arrColumnNames.get(int_Column).toString().toUpperCase();
    	    	  result.remove(strColumnName);
    	      }
    	
    	      result.put("errorcode", "-1");
    	      result.put("TYPE_OF_ACTOR", TYPE_OF_ACTOR);
    	      result.put("errordescription", " login failed "+TYPE_OF_ACTOR+" WRONG PASSWORD!!!!");
    	      boolean bb = stmt.execute((new StringBuilder()).append("UPDATE "+TYPE_OF_ACTOR+"  set LOGINCOUNT = LOGINCOUNT +1   where  EMAILADDRESS='").append(EMAILADDRESS.trim().toUpperCase()).append("'  ").toString());
    	    	  
    	  }
      }else
      {
    	//romove the  record from the result JSON object whe the authentication fails
	      for (int int_Column =0;int_Column<arrColumnNames.size(); int_Column++  )
	      {
	    	  String strColumnName = arrColumnNames.get(int_Column).toString().toUpperCase();
	    	  result.remove(strColumnName);
	      }
    	  result.put("errorcode", "-4");
    	  result.put("TYPE_OF_ACTOR", TYPE_OF_ACTOR);
          result.put("errordescription", "10 unsuccessful login count. Account is blocked for the ACTOR  "+TYPE_OF_ACTOR+"  !!!! Contact the administrator!!!!"); 
          boolean bb = stmt.execute((new StringBuilder()).append("UPDATE "+TYPE_OF_ACTOR+"  set LOGINCOUNT = LOGINCOUNT +1  where  EMAILADDRESS='").append(EMAILADDRESS.toUpperCase().trim()).append("'  ").toString());
          
      }
      
       

    
      data.close();
      stmt.close();
      conn.close();
      //return response;
      }else{
      
      result.put("errordescription", "Login Failed");
      boolean bb = stmt.execute((new StringBuilder()).append("UPDATE "+TYPE_OF_ACTOR+"  set LOGINCOUNT = LOGINCOUNT +1  where  trim(EMAILADDRESS)='").append(EMAILADDRESS.trim().toUpperCase()).append("'  ").toString());
 
      data.close();
      stmt.close();
      conn.close();
      //return response;
      }
      }catch(Exception exception)
     {

    System.out.println("Table  "+TYPE_OF_ACTOR+"   error in method :::EthSol_LoginWithEMAIL:::" + exception.getMessage());
      try {
		if (data!= null) data.close();
		if (stmt!= null) stmt.close();
	
	   
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
  }
	


      response.getWriter().println(result);
	    }
}