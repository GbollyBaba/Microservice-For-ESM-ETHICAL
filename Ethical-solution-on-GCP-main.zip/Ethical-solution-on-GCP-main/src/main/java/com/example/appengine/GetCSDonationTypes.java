
package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;


@WebServlet(name = "GetCSDonationTypes", value = "/getCSDonationTypes")
public class GetCSDonationTypes extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Define logger (Standard java.util.Logger)
	static Logger logger = Logger.getLogger(GetCSDonationTypes.class.getName());


  @Override
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  
	  String NKEY = request.getParameter("NKEY").trim();

	   

	  JSONObject result =null;
 

Connection con=null;
Statement stmt=null;
String updateSQL="";
JSONArray results = null;
JSONObject item=null;
String Token;
try { con = pool.getConnection();
	        
	       
	    
	         String  sql = " ";
		 sql=sql +"   SELECT DONATION_ID, DONATION_DESC FROM  TBL_DONATION_TYPES  ";
			       
		       
		        System.out.println(sql);
	            PreparedStatement getAllUsers = con.prepareStatement(sql);
	            ResultSet data = getAllUsers.executeQuery();
	            results = new JSONArray();
	           
	            for(; data.next(); results.add(item))
	            {
	                item = new JSONObject();
	                item.put("DONATION_ID", data.getString("DONATION_ID"));
	                item.put("DONATION_TYPE", data.getString("DONATION_DESC"));
	               
	          }

	            getAllUsers.close();
	            con.close();
	        }
	        catch(SQLException e)
	        {
	            results = new JSONArray();
	             item = new JSONObject();
	                item.put("DONATION_ID", "");
	                item.put("DONATION_TYPE",  "");
	              
	     
	            results.add(item);
	            e.printStackTrace();
	        }
	        JSONObject resultsObj = new JSONObject(); 
	        resultsObj.put("DONATION_TYPES", results);
	        
	        response.getWriter().println(resultsObj);
	    }
}

		