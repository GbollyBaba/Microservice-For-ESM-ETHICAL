
package com.example.appengine;


//https://towardsdatascience.com/6-lesser-known-sql-techniques-to-save-you-100-hours-a-month-10ceed47d3fe
//https://cprosenjit.medium.com/10-time-series-forecasting-methods-we-should-know-291037d2e285

//https://www.youtube.com/watch?v=UlyTIrwepQ8

//gbolade@sallysoftinternational.com
//fe7z(QPQ3eY.c4g

//GCP password  ethicalsoft10*
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;




import com.example.util.*;
import com.example.util.JWTGenerateValidateHMAC;


@WebServlet(name = "EthSol_GET_TABLE_DATA", value = "/EthSol_GET_TABLE_DATA")
public class EthSol_GET_TABLE_DATA extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Define logger (Standard java.util.Logger)
	static Logger logger = Logger.getLogger(EthSol_GET_TABLE_DATA.class.getName());
	
	
	
	
	
	


  @SuppressWarnings("rawtypes")
@Override
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	  
				String remoteAddr = "";
				
				if (request != null) {
				    remoteAddr = request.getHeader("X-FORWARDED-FOR");
				
				}
				System.out.println("remoteAddr:::::::"+ remoteAddr);
				
				
				String hostname = request.getRemoteHost(); // hostname
				System.out.println("hostname"+hostname);
				
				String computerName = null;
				String remoteAddress = request.getRemoteAddr();
				System.out.println("remoteAddress: " + remoteAddress);
				try {
				    InetAddress inetAddress = InetAddress.getByName(remoteAddress);
				    System.out.println("inetAddress: " + inetAddress);
				computerName = inetAddress.getHostName();
				
				System.out.println("computerName: " + computerName);
				
				
				if (computerName.equalsIgnoreCase("localhost")) {
				        computerName = java.net.InetAddress.getLocalHost().getCanonicalHostName();
				    } 
				} catch (UnknownHostException e) {
				
				    }
				
				System.out.println("computerName: " + computerName);

	/////////////////////////////////////////////////////////////////////////////////////////////////////////	  


	  JSONObject result =null;
	    JSONArray results = null;
	    
	  
	  
	    PreparedStatement getAllUsers =null;
	    Connection con=null;
	      Statement stmt=null;
	      ResultSet data=null;
	
	
	    String TYPE_OF_ACTOR =request.getParameter("TYPE_OF_ACTOR");
	  	String NKEY = request.getParameter("NKEY").trim();
	  	String CHANNEL = request.getParameter("CHANNEL");
	  	
	  	
	  	
	  	
////////////////////////////////////////SECURITY CHECK///////////////////////////////////////////////////////////////////////////////
JSONObject resultsVAlidate = new JSONObject();
String [] nkeyValues  = NKEY.split(" ");
if (nkeyValues.length == 5)
{
//EMAIL TYPEOFACTOR HQTECH IPADDRESS NKEY

String EMAIL = nkeyValues[0];
String TYPEOFACTOR = nkeyValues[1];
String MACHINE_NAME_VALUE = nkeyValues[2];
String MACHINE_IPADDRESS_VALUE = nkeyValues[3];
String NKEY_VALUE = nkeyValues[4];
JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
String res = gg.ValidateToken(NKEY_VALUE);
System.out.println("**********************SECURITY CHECK WITH OUATH2 & WEB TOKEN******************************* ");
System.out.println(" EMAIL :"+EMAIL);
System.out.println(" TYPEOFACTOR :"+TYPEOFACTOR);
System.out.println(" MACHINE_NAME_VALUE :"+MACHINE_NAME_VALUE);
System.out.println(" MACHINE_IPADDRESS_VALUE :"+MACHINE_IPADDRESS_VALUE);
System.out.println(" NKEY_VALUE :"+NKEY_VALUE);
System.out.println("************************************************************************************* ");


System.out.println(" ValidateToken :"+res);

if (!res.equalsIgnoreCase("Y"))
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}
}else
{
resultsVAlidate.put("errorcode", "-3000");
resultsVAlidate.put("errordescription",  "Incomplete paramets passed...");
response.getWriter().println(resultsVAlidate);
return;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


		String loginSQL="";
  	   ArrayList kk =null;
       
       ArrayList arrColumnNames = null;
	  try (Connection conn = pool.getConnection()) {
      stmt = conn.createStatement();

      TYPE_OF_ACTOR =TYPE_OF_ACTOR.toUpperCase();
      switch (TYPE_OF_ACTOR) {
      case "LPO_BORROWER":  
    	  loginSQL= "   SELECT Curdate() as CurrentDate, curtime() as CurrentTime,B.STATE,B.COUNTRY,B.LGA, A.* ";
          loginSQL = loginSQL + "  from "+TYPE_OF_ACTOR+" A,  COUNTRY B ";

          loginSQL = loginSQL + "  WHERE 1=1  ";
  
          loginSQL = loginSQL + "  AND A.LGA_ID = B.LGA_ID ";
         
		break;
      case "LPO_INVESTOR":   
    	  loginSQL= "  SELECT Curdate() as CurrentDate, curtime() as CurrentTime,B.STATE,B.COUNTRY,B.LGA, A.* ";
          loginSQL = loginSQL + "  from "+TYPE_OF_ACTOR+" A,  COUNTRY B ";

          loginSQL = loginSQL + "  WHERE 1=1";
  
          loginSQL = loginSQL + "  AND A.LGA_ID = B.LGA_ID ";
        
		break;
               
      case "LPO_INVESTOR_COY":   
    	  loginSQL= "  SELECT Curdate() as CurrentDate, curtime() as CurrentTime,B.STATE,B.COUNTRY,B.LGA, A.* ";
          loginSQL = loginSQL + "  from "+TYPE_OF_ACTOR+" A,  COUNTRY B ";
          loginSQL = loginSQL + "  WHERE 1=1  ";
   
          loginSQL = loginSQL + "  AND A.LGA_ID = B.LGA_ID ";
         

		break;
		
      case "LPO_SUPPLIER_COY":   
    	  loginSQL= "   SELECT Curdate() as CurrentDate, curtime() as CurrentTime,B.STATE,B.COUNTRY,B.LGA, A.* ";
          loginSQL = loginSQL + "  from "+TYPE_OF_ACTOR+" A,  COUNTRY B ";

          loginSQL = loginSQL + "  WHERE 1=1 ";

          loginSQL = loginSQL + "  AND A.LGA_ID = B.LGA_ID ";
         
		break;
		
		
      case "LPO_ISSUER":   
    	  loginSQL= "  SELECT Curdate() as CurrentDate, curtime() as CurrentTime,B.STATE,B.COUNTRY,B.LGA, A.* ";
          loginSQL = loginSQL + "  from "+TYPE_OF_ACTOR+" A,  COUNTRY B ";
          loginSQL = loginSQL + "  WHERE 1=1 ";

          loginSQL = loginSQL + "  AND A.LGA_ID = B.LGA_ID ";
         

		break;
		
      case "LPO_ISSUER_PAYTERMS":   
    	  loginSQL= " select  * from  LPO_ISSUER_PAYTERMS where 1=1 and status ='A' ";
    	  break;   
		
    	  
      case "LPO_ORDER":   
    	  loginSQL= " select  * from  LPO_ORDER_v2 where  1=1 order by  LPO_ISSUER_ID  ASC ";
    	  break;   
    	  
    	  
      case "LPO_ITEM_MEASUREMENT_TYPE":   
    	  loginSQL= " select  * from  LPO_ITEM_MEASUREMENT_TYPE where  1=1 order by  ITEM_MEASUREMENT_TYPE_NAME  ASC ";
    	  break;   
    	  
    	  
    	  
      case "DATA_CONFIRMED_LPO":
    	  loginSQL= "  CALL SP_LIST_CONFIRMED_LPO_ORDER_BY_ISSUER() ";
		
      
    
  }
	 

      
      
      System.out.println(loginSQL);
    
      
     
      results = new JSONArray();
   
      data = stmt.executeQuery(loginSQL);
      ResultSetToArrayList rrResultSetToArrayList = new ResultSetToArrayList();
       kk = (ArrayList) rrResultSetToArrayList.ResultSetToArrayList(data);
       int sizeoftable =kk.size();
      
       arrColumnNames = (ArrayList) rrResultSetToArrayList.ColumnNames(data);
       int sizeofcolumnslist =arrColumnNames.size();
       if (sizeoftable>0)
       {
       for (int k=0 ; k <sizeoftable ; k++)
       {
      
    	   result = new JSONObject();
 // System.out.println(kk.get(k).toString());
      ArrayList rowAl = (ArrayList) kk.get(k);
      //populate the record into the json objects
      for (int int_Column =0;int_Column<sizeofcolumnslist; int_Column++  )
      {
    
    	  String strColumnName = arrColumnNames.get(int_Column).toString().toUpperCase();
    	  result.put(strColumnName, rowAl.get(int_Column).toString());
      }
      //System.out.println(result.toString());
      results.add(result);

      }
       }
      data.close();
      stmt.close();
      conn.close();
      //return response;
           }catch(Exception exception)
     {

    System.out.println("Table  "+TYPE_OF_ACTOR+"   error in method :::EthSol_GET_TABLE_DATA:::" + exception.getMessage());
      try {
    	  
    	  exception.printStackTrace();
		if (data!= null) data.close();
		if (stmt!= null) stmt.close();
	
	   
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
  }
	


      response.getWriter().println(results);
	    }
}