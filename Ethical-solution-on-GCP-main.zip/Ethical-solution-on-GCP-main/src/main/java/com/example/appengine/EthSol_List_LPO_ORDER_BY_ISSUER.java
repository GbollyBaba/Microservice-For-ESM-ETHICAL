

package com.example.appengine;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.logging.Logger;
/*
 * 
  account name - oa_adelaja@hotmail.com

	  password - ethicalsoft10*
  
 * 
 */
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringEscapeUtils;
import com.api.json.JSONArray;

import com.api.json.JSONObject;
import com.example.util.*;
import com.mysql.cj.jdbc.CallableStatement;
@SuppressWarnings("deprecation")

@WebServlet(
	    name = "EthSol_List_LPO_ORDER_BY_ISSUER",
	    urlPatterns = {"/EthSol_List_LPO_ORDER_BY_ISSUER"}
	)

public class EthSol_List_LPO_ORDER_BY_ISSUER extends HttpServlet {

/**
 *
 * 
  mvn clean package appengine:deploy
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(EthSol_Get_LPO_ORDER.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");

	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");

	  String ISSUER_ID =request.getParameter("ISSUER_ID");
	  String CHANNEL =request.getParameter("CHANNEL");
	  String NKEY =request.getParameter("NKEY").trim();
	 
System.out.println("****************************************************************************");
System.out.println(" LPO_NUMBER :"+ISSUER_ID);
System.out.println(" CHANNEL :"+CHANNEL);
System.out.println(" NKEY :"+NKEY);
System.out.println("****************************************************************************");
	
////////////////////////////////////////SECURITY CHECK///////////////////////////////////////////////////////////////////////////////
JSONObject resultsVAlidate = new JSONObject();
String [] nkeyValues  = NKEY.split(" ");
if (nkeyValues.length == 5)
{
//EMAIL TYPEOFACTOR HQTECH IPADDRESS NKEY

String EMAIL = nkeyValues[0];
String TYPEOFACTOR = nkeyValues[1];
String MACHINE_NAME_VALUE = nkeyValues[2];
String MACHINE_IPADDRESS_VALUE = nkeyValues[3];
String NKEY_VALUE = nkeyValues[4];
JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
String res = gg.ValidateToken(NKEY_VALUE);
System.out.println("**********************SECURITY CHECK WITH OUATH2 & WEB TOKEN******************************* ");
System.out.println(" EMAIL :"+EMAIL);
System.out.println(" TYPEOFACTOR :"+TYPEOFACTOR);
System.out.println(" MACHINE_NAME_VALUE :"+MACHINE_NAME_VALUE);
System.out.println(" MACHINE_IPADDRESS_VALUE :"+MACHINE_IPADDRESS_VALUE);
System.out.println(" NKEY_VALUE :"+NKEY_VALUE);
System.out.println("************************************************************************************* ");


System.out.println(" ValidateToken :"+res);

if (!res.equalsIgnoreCase("Y"))
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}
}else
{
resultsVAlidate.put("errorcode", "-3000");
resultsVAlidate.put("errordescription",  "Incomplete paramets passed...");
response.getWriter().println(resultsVAlidate);
return;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	Statement stmt=null;
	  java.sql.CallableStatement cs = null;
	  String insertSQL="";
	  ResultSet data= null;
	     ResultSet data1 = null;
	     ResultSet data2 = null;
	     ResultSet data3 = null;
	  ArrayList kk =null;
	  String Token;
	  String insertvALUESSQL;
	  JSONArray resultsARR = new JSONArray();
	  JSONObject results = new JSONObject();
	  JSONObject resultsALL = new JSONObject();
	  JSONObject result = null;
	  
	  JSONObject result_BORROWER = new JSONObject();
	  JSONObject result_ISSUER = new JSONObject();
	  JSONObject result_LPO_ORDER = new JSONObject();
	  JSONObject result_SUPPLIER = new JSONObject();
	  
	  if (pool!= null)
	  {
	  try (Connection con = pool.getConnection()) 
	  {
		   
		   System.out.println("<<<<<<<< CREATE CONNECTION  SUCCESSFULLY>>>>>>>>>>>>>");	
	  stmt = null;	 
	  
	
		  try{
  String StoredProcedure = "{ call SP_LIST_LPO_ORDER_BY_ISSUER(?) }";
	 
 cs = con.prepareCall(StoredProcedure);
	    
	  cs.setInt(1, Integer.parseInt(ISSUER_ID));
	  
	  data = cs.executeQuery();
	  
	  ResultSetToArrayList rrResultSetToArrayList = new ResultSetToArrayList();
      kk = (ArrayList) rrResultSetToArrayList.ResultSetToArrayList(data);
      int sizeoftable =kk.size();
      ArrayList arrColumnNames = (ArrayList) rrResultSetToArrayList.ColumnNames(data);
      if (sizeoftable>0)
      {
      for (int k=0 ; k <sizeoftable ; k++)
      {
     System.out.println(kk.get(k).toString());
     System.out.println(arrColumnNames.toString());
     result = new JSONObject();
     ArrayList rowAl = (ArrayList) kk.get(k);
     for (int int_Column =0;int_Column<arrColumnNames.size(); int_Column++  )
     {
   	  String strColumnName = arrColumnNames.get(int_Column).toString().toUpperCase();
   	  result.put(strColumnName, rowAl.get(int_Column).toString());
     }
     resultsARR.add(result);
      }
      }
     
     
      kk=null;
     
   
    JSONObject dbresult = new JSONObject();
      dbresult.put("errorcode", "0");
      dbresult.put("errordescription",  "EthSol_List_LPO_ORDER_BYISSUER_ID["+ISSUER_ID+"] Successful CREATION ");
      resultsALL.put("ERROR", dbresult);
      resultsALL.put("LPOs", resultsARR);
      resultsALL.put("TotalRecords", String.valueOf( sizeoftable));
      
      
      if (data != null)  data.close();
	   

	    if (cs != null)  cs.close();
	    if (con != null)  con.close();
	
		  } 
		  
		  catch(java.sql.SQLIntegrityConstraintViolationException sqlerror)
		  {
			  
			  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "-2");
		      dbresult.put("errordescription",  sqlerror.getMessage());
		      results.put("ERROR", dbresult);
		      
		  
		      resultsALL.put("ERROR", dbresult);
		      resultsALL.put("LPO", null);
		      resultsALL.put("TotalRecords", "0");
		    

			    if (cs != null)  cs.close();
			    if (con != null)  con.close();
			  sqlerror.printStackTrace();  
			  
		  }
		  catch (Exception eee)
		  	{
			  
			  
			  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "-1");
		      dbresult.put("errordescription",  eee.getMessage());
		      results.put("ERROR", dbresult);
		      
		      resultsALL.put("ERROR", dbresult);
		      resultsALL.put("LPO", null);
		      resultsALL.put("TotalRecords", "0");
		    
		    if (data != null)  
		    {
		    	data.close(); 
		    	data=null;
		    }
		    if (cs != null)  
		    {cs.close();
		    cs=null;}
		    
		    if (con != null)  
		    {con.close(); 
	
		    }
		  
			  eee.printStackTrace();
			
		  }
		  
		  
		  finally
		  {
		  
		
		}
	  
	

	  } catch (Exception ee)
{
		  JSONObject dbresult = new JSONObject();
	      dbresult.put("errorcode", "-2");
	      dbresult.put("errordescription",  ee.getMessage());
	      results.put("ERROR", dbresult);
	      
	      resultsALL.put("ERROR", dbresult);
	      resultsALL.put("LPO", null);
	      resultsALL.put("TotalRecords", "0");
	  ee.printStackTrace();
}
	  
	  
}

response.getWriter().println(resultsALL);
}

  




	  




}




