
package com.example.appengine;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Logger;
/*
 * 
  account name - oa_adelaja@hotmail.com

	  password - ethicalsoft10*
  
 * 
 */
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringEscapeUtils;

import com.api.json.JSONObject;
import com.example.util.*;
@SuppressWarnings("deprecation")

@WebServlet(
	    name = "EthSol_Investor_Coy",
	    urlPatterns = {"/EthSol_Investor_Coy"}
	)

public class EthSol_Investor_Coy extends HttpServlet {

/**
 * 
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(EthSol_Investor_Coy.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	 String FIRSTNAME =StringEscapeUtils.escapeEcmaScript( request.getParameter("FIRSTNAME"));
	  String SURNAME=StringEscapeUtils.escapeEcmaScript( request.getParameter("SURNAME")) ;
	  String MIDDLENAME =StringEscapeUtils.escapeEcmaScript( request.getParameter("MIDDLENAME")) ;
	  String BIRTHDATE=request.getParameter("BIRTHDATE") ;
	  String STREET1=request.getParameter("STREET1") ;  
	  String STREET2=request.getParameter("STREET2")  ;
	  String LGA_ID=request.getParameter("LGA_ID") ;
	  String STATE_ID=request.getParameter("STATE_ID") ;
	  String COUNTRY_ID=request.getParameter("COUNTRY_ID") ;
	  
	  String COY_NAME =request.getParameter("COY_NAME") ;
	  String COY_REG_NO =request.getParameter("COY_REG_NO") ;
	  String COY_MOBILENUMBER =request.getParameter("COY_MOBILENUMBER") ;
	  String COY_EMAILADRESS =request.getParameter("COY_EMAILADRESS") ;
	  String COY_WEBSITE =request.getParameter("COY_WEBSITE") ;
	  
	  String MARITAL_STATUS=request.getParameter("MARITAL_STATUS");
	  String MOBILENUMBER=request.getParameter("MOBILENUMBER") ;
	  String MACADDRESS=	request.getParameter("MACADDRESS")  ;
	  String EMAILADDRESS=request.getParameter("EMAILADDRESS") ;
	  String PASSWORD=	request.getParameter("PASSWORD")  ;
	  String CONFIRMPASSWORD=request.getParameter("CONFIRMPASSWORD") ;
	  String CUSTOMER_CLASSIFICATION=	request.getParameter("CUSTOMER_CLASSIFICATION")  ;
	  String TOKEN=	request.getParameter("TOKEN")  ;
	  String LOGINCOUNT=	request.getParameter("LOGINCOUNT")  ;
	  String STATUS=	request.getParameter("STATUS")  ;
	  String NKEY=	request.getParameter("NKEY").trim()  ;
	  String CHANNEL=	request.getParameter("CHANNEL")  ;
	  
	  
	  
/*	  	
////////////////////////////////////////SECURITY CHECK///////////////////////////////////////////////////////////////////////////////
JSONObject resultsVAlidate = new JSONObject();
String [] nkeyValues  = NKEY.split(" ");
if (nkeyValues.length == 5)
{
//EMAIL TYPEOFACTOR HQTECH IPADDRESS NKEY

String EMAIL = nkeyValues[0];
String TYPEOFACTOR = nkeyValues[1];
String MACHINE_NAME_VALUE = nkeyValues[2];
String MACHINE_IPADDRESS_VALUE = nkeyValues[3];
String NKEY_VALUE = nkeyValues[4];
JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
String res = gg.ValidateToken(NKEY_VALUE);
System.out.println("**********************SECURITY CHECK WITH OUATH2 & WEB TOKEN******************************* ");
System.out.println(" EMAIL :"+EMAIL);
System.out.println(" TYPEOFACTOR :"+TYPEOFACTOR);
System.out.println(" MACHINE_NAME_VALUE :"+MACHINE_NAME_VALUE);
System.out.println(" MACHINE_IPADDRESS_VALUE :"+MACHINE_IPADDRESS_VALUE);
System.out.println(" NKEY_VALUE :"+NKEY_VALUE);
System.out.println("************************************************************************************* ");


System.out.println(" ValidateToken :"+res);

if (!res.equalsIgnoreCase("Y"))
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}
}else
{
resultsVAlidate.put("errorcode", "-3000");
resultsVAlidate.put("errordescription",  "Incomplete paramets passed...");
response.getWriter().println(resultsVAlidate);
return;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/

JSONObject result =null;
System.out.println("****************************************************************************");
System.out.println(" FIRSTNAME  :" +FIRSTNAME );
System.out.println(" SURNAME :" +SURNAME) ;
System.out.println(" MIDDLENAME  :" +MIDDLENAME) ;
System.out.println(" BIRTHDATE  :" +BIRTHDATE) ;
System.out.println(" STREET1  :" +STREET1) ;  
System.out.println(" STREET2  :" +STREET2) ;  
System.out.println(" LGA_ID  :" +LGA_ID) ;  
System.out.println(" STATE_ID  :" +STATE_ID) ;  
System.out.println(" COUNTRY_ID  :" +COUNTRY_ID) ;  

System.out.println(" COY_NAME :" +COY_NAME );
System.out.println(" COY_REG_NO :" +COY_REG_NO );
System.out.println(" COY_MOBILENUMBER :" +COY_MOBILENUMBER );
System.out.println(" COY_EMAILADRESS :" +COY_EMAILADRESS );
System.out.println(" COY_WEBSITE :" +COY_WEBSITE );


System.out.println(" MARITAL_STATUS  :" +MARITAL_STATUS );
System.out.println(" MOBILENUMBER  :" +MOBILENUMBER) ;  
System.out.println(" MACADDRESS:"+MACADDRESS)  ;
System.out.println(" EMAILADDRESS  :" +EMAILADDRESS) ;  
System.out.println(" PASSWORD:"+PASSWORD)  ;
System.out.println(" CONFIRMPASSWORD  :" +CONFIRMPASSWORD) ;  
System.out.println(" CUSTOMER_CLASSIFICATION:"+CUSTOMER_CLASSIFICATION)  ;
System.out.println(" TOKEN  :" +TOKEN) ;  
System.out.println(" LOGINCOUNT:"+LOGINCOUNT)  ;
System.out.println(" STATUS  :" +STATUS) ;  
System.out.println(" CHANNEL  :" +CHANNEL) ;  
System.out.println("****************************************************************************");
	  Statement stmt=null;
	  ResultSet data=null;
	  String insertSQL="";
	  String Token;
	  String insertvALUESSQL;
	  
	  if (pool!= null)
	  {
	  try (Connection con = pool.getConnection()) 
	  {
		   
		   System.out.println("<<<<<<<< CREATE CONNECTION  SUCCESSFULLY>>>>>>>>>>>>>");	
	  stmt = null;	 
	  EMAILADDRESS = EMAILADDRESS.toLowerCase().trim();
	  RandomNumberGen rGen = new RandomNumberGen();
	  TOKEN = String.valueOf(rGen.getRandomNumber());
	  System.out.println("token generated:::"+ TOKEN);
		  insertvALUESSQL = " VALUES (  CURDATE(), CURTIME(), ";
		  insertSQL =  insertSQL + "INSERT INTO LPO_INVESTOR_COY (DATE_CREATED  ,TIME_CREATED,FIRSTNAME ,MIDDLENAME,SURNAME,BIRTHDATE,STREET1,STREET2 ";
		  insertSQL =  insertSQL + "  	,LGA_ID,STATE_ID ,COUNTRY_ID,COY_NAME,COY_REG_NO,COY_MOBILENUMBER,COY_EMAILADRESS,COY_WEBSITE,MARITAL_STATUS ,MOBILENUMBER,MACADDRESS,EMAILADDRESS, ";
		insertSQL =  insertSQL + "  	PASSWORD,CONFIRMPASSWORD,CUSTOMER_CLASSIFICATION,TOKEN ";
		insertSQL =  insertSQL + " ,LOGINCOUNT,STATUS) ";
		  
		
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(FIRSTNAME.toUpperCase()).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(MIDDLENAME.toUpperCase()).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(SURNAME.toUpperCase()).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(BIRTHDATE).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(STREET1).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(STREET2).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(LGA_ID).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(STATE_ID).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(COUNTRY_ID).append("',").toString();
		  
		  
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(COY_NAME.toUpperCase()).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(COY_REG_NO.toUpperCase()).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(COY_MOBILENUMBER).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(COY_EMAILADRESS.toUpperCase()).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(COY_WEBSITE).append("',").toString();
		  
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(MARITAL_STATUS.toUpperCase()).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(MOBILENUMBER).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(MACADDRESS).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(EMAILADDRESS.toUpperCase()).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(PASSWORD).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(CONFIRMPASSWORD).append("', ").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(CUSTOMER_CLASSIFICATION).append("', ").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(TOKEN).append("', ").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(LOGINCOUNT).append("', ").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(STATUS.toUpperCase()).append("' ").toString();
		  
		  insertvALUESSQL =insertvALUESSQL +    "   ) ";
		  
		
		  Boolean bbb = Boolean.valueOf(false);
		  System.out.println("********************************************************************************" +
				  	"***"
				  	);
		  System.out.println((new StringBuilder()).append(insertSQL).append(insertvALUESSQL).toString());
		
	
		  try{
			  stmt = con.createStatement();
			   bbb = Boolean.valueOf(stmt.execute(insertSQL+insertvALUESSQL));
			  System.out.println("INVESTOR SUCCESSFULLY  INSERTED*****");
			  
			  
			  
			  
			  ///get the ID of the user
			  String getID_SQL= "   SELECT A.LPO_INVESTOR_COY_ID ";
			  getID_SQL = getID_SQL + "  from LPO_INVESTOR_COY A";
			  getID_SQL = getID_SQL + "  WHERE ";
			  getID_SQL = getID_SQL + "  trim(A.EMAILADDRESS) = '"+EMAILADDRESS.trim().toUpperCase()+"'    ";
			   data = stmt.executeQuery(getID_SQL);
		      ResultSetToArrayList rrResultSetToArrayList = new ResultSetToArrayList();
		      ArrayList  kk = (ArrayList )rrResultSetToArrayList.ResultSetToArrayList(data);
		      String LPO_INVESTOR_COY_ID  = "";
		      if(kk.size() >= 1)
		      {

		    	  ArrayList rowAl = (ArrayList) kk.get(0);
		      LPO_INVESTOR_COY_ID=rowAl.get(0).toString();
		    
		      rowAl=null;
		      }
		      kk=null;
			  
			  
			  
			  
			  
			  
			  // SEND SMS AND EMAIL TO THE TOKEN
			  
			  
			  //String From="anything@886432383143.appspotmail.com";
			  String From="gboladeshada@gmail.com";
			  String To=EMAILADDRESS;
			SendEmail  email = new SendEmail();
			 
			  String strMessage =" PLEASE ENTER THE TOKEN NUMBER :  "+ TOKEN+" TO VALIDATE YOUR PROFILE.";
			  
			  email.sendMail1(From, To, ""+SURNAME+", Verify your Profile",strMessage);
			  
			
			  //SendSMS ss = new SendSMS();
			  //String ToMobileNo = MOBILENUMBER;
			  //String FromMobileNo = "+2348120796782";
			  //String strMessage = (new StringBuilder()).append(" PLEASE ENTER THE TOKEN NUMBER :  ").append(TOKEN).append(" TO VALIDATE YOUR PROFILE.").toString();
			  //String mesgID ="";
			  //	mesgID=	ss.send(ToMobileNo, FromMobileNo, strMessage);
			   result = new JSONObject();
			  result.put("errorcode", "0");
			  result.put("ID", LPO_INVESTOR_COY_ID);
			  //result.put(LPO_INVESTOR_COY_ID, LPO_INVESTOR_COY_ID);
			  result.put("errordescription",  "[EthSol_Investor COMPANY]  Successful CREATION ");
			  stmt.close();
			  con.close();
		  } catch (Exception eee)
		  	{
			  eee.printStackTrace();
			  System.out.println("**********************************************************************");
			  System.out.println((new StringBuilder()).append(insertSQL).append(insertvALUESSQL).toString());
			  System.out.println("**********************************************************************");
			   result = new JSONObject();
			  result.put("errorcode", "-1");
			  result.put("errordescription", eee.getMessage() + "    " + insertSQL + insertvALUESSQL);
			  stmt.close();
			  con.close();
		  }finally
		  {
		  stmt.close();
		  con.close();
		
		}
	  
	

	  } catch (Exception ee)
{
	   result = new JSONObject();
	  result.put("errorcode", "-9");
	  result.put("errordescription", ee.getMessage() + "    " + "COULD NOT ESTABLISH CONNECTION");	
	  ee.printStackTrace();
}
	  
	  
}

System.out.println(result); 

response.getWriter().println(result);
}

  




	  




}




