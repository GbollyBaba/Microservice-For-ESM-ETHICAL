
package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;
import com.example.util.*;

import org.apache.commons.lang3.*;


@WebServlet(name = "LogGPSforusers", value = "/logGPSforusers")
public class LogGPSforusers extends HttpServlet {

/**
 * 
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(CS_Donation_Log.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	 

 Connection con=null;
  Statement stmt=null;
  String EVWID =request.getParameter("EVWID");
  String LATITUDE=request.getParameter("LATITUDE") ;
  String LONGITUDE =request.getParameter("LONGITUDE") ;
  String NKEY=request.getParameter("NKEY").trim() ;  
  
  JSONObject result =null;

  String insertSQL="";
  String Token="";
  String insertvALUESSQL="";

  try { 
	  con = pool.getConnection();
	  
	  
	  stmt = null;
      insertSQL = "";
      
      insertvALUESSQL = " VALUES (   ";
      insertSQL = "INSERT INTO TBL_TRACKGPS (CURR_DATE, CURR_TIME, EVW_ID "
      		+ ",LATITUDE ,LONGITUDE "
      		
      		+ "  ) ";

insertvALUESSQL= "VALUES (  CURRENT DATE, CURRENT TIME,  ";
      insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(EVWID).append("',").toString();
      insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(LATITUDE).append("',").toString();
      insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(LONGITUDE).append("' ").toString();
      insertvALUESSQL= insertvALUESSQL+ " ) ";
      Boolean bbb = Boolean.valueOf(false);
      System.out.println("********************************************************************************" +
"***"
);
      System.out.println((new StringBuilder()).append(insertSQL).append(insertvALUESSQL).toString());
      System.out.println("***********************************************************************************");

      stmt = con.createStatement();
       bbb = Boolean.valueOf(stmt.execute((new StringBuilder()).append(insertSQL).append(insertvALUESSQL).toString()));
      System.out.println("SUCCESSFULLULLY INSERYTED GPS FOR USER(ACTOR)****");
      
   
      result.put("errorcode", "0");
      result.put("errordescription", "Successful LOGGED THE GPS ");
      stmt.close();
      con.close();
 
  
      }
      catch (Exception eee)
      {
  
      eee.printStackTrace();
      System.out.println("**********************************************************************");
      System.out.println((new StringBuilder()).append(insertSQL).append(insertvALUESSQL).toString());
      System.out.println("**********************************************************************");
      
   
       result = new JSONObject();
      result.put("errorcode", "-1");
      result.put("errordescription", (new StringBuilder()).append("NOT CREATED ").append(eee.getLocalizedMessage()).toString());
   
      try {

    		if (stmt!= null) stmt.close();
    		if (con!= null)  con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
   
   
      }finally
      {
    	  try {
    			stmt.close();
    			   con.close();
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    
  }
      
      
      System.out.println(""); 
      System.out.println(result);


      response.getWriter().println(result);
    }



    }
  