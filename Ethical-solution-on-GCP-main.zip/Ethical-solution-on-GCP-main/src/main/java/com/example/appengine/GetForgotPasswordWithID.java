package com.example.appengine;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONObject;
import com.example.util.ResultSetToArrayList;
import com.example.util.SendEmail;
import com.example.util.SendSMS_New;

@WebServlet(name = "GetForgotPasswordWithID", value = "/getForgotPasswordWithID")
public class GetForgotPasswordWithID extends HttpServlet {

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(GetForgotPasswordWithID.class.getName());

@SuppressWarnings("rawtypes")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  

  Statement stmt=null;
  ResultSet data=null;
  String MOBILENUMBER = request.getParameter("MOBILENUMBER");
  String APPID = request.getParameter("APPID");
  String NKEY = request.getParameter("NKEY").trim();
  System.out.println(MOBILENUMBER);
  System.out.println(APPID);
  System.out.println(NKEY);
  

  String loginSQL="   ";
  JSONObject result = null;

	
  try (Connection con = pool.getConnection()) {
  stmt = con.createStatement();
  loginSQL = "   SELECT CURDATE() as MyDate, CURTIME() as MyTime,a.EVW_ID ,a.DATE_CREATE" +
"D ,a.TIME_CREATED , a.FIRSTNAME, a.MIDDLENAME , a.SURNAME , a.BIRTHDATE, a.STREET1 , a.STREET2 , a.LGA , a.STATE,"
+ " a.MARITAL_STATUS , a.MOBILENUMBER , a.MACADDRESS , a.EMAILADDRESS , a.PASSWORD , a.CONFIRMPASSWORD , a.TOKEN ,"
+ " a.APP_ID  , a.LOGINCOUNT , a.STATUS, a.CUSTOMER_CLASSIFICATION  FROM  TBL_USERS a WHERE  "
;
  loginSQL = loginSQL +"  trim(a.APP_ID)= '"+APPID+"' AND Trim(a.MOBILENUMBER) ='"+MOBILENUMBER.trim()+"'  ";
  System.out.println(loginSQL);

  
  result = new JSONObject();
  data = stmt.executeQuery(loginSQL);
  ResultSetToArrayList rrResultSetToArrayList = new ResultSetToArrayList();
  ArrayList kk = rrResultSetToArrayList.ResultSetToArrayList(data);
  if(kk.size() >= 1)
  {
   
  ArrayList rowAl = (ArrayList)kk.get(0);
  System.out.println("<<<<<<<<<PICKED THE PASSWORD>>>>>>>>>>>>>>>>>>");      

// Send the PASSWORD TO THE EMAIL ADDRES ATTACHED To THE PROFILE




String recipient_email=rowAl.get(16).toString();
String strLASTNAME = rowAl.get(7).toString();
String strFIRSTNAME=rowAl.get(5).toString();

String FULLNAME  = strLASTNAME +",  " + strFIRSTNAME;
String strPASSWORD = rowAl.get(17).toString();

//     String msg = "Dear "+FULLNAME +"," +
//      "\n\n PASSWORD "+ strPASSWORD  + "\n\n   Regards";

String msg = "Dear "+strFIRSTNAME +"," +
"\n\n PASSWORD "+ strPASSWORD  + "\n\n   Regards";

String emailmsg=" <html>   "
+ "   <body>  "
+ "    <br> <br>  "
+ "   <p>Dear  <b> "+strFIRSTNAME +"</b>,  </p>  "

+ "    <br>  "
+ "   <p>Your Forgotten  PASSWORD is:  <b> "+ strPASSWORD  + "</b>  "
+ "   <p>Use the PASSWORD to log on to the ISOKAN APP and change your Password afterward. </p>  "
+ "   <br>  "
+ "   <br>  "

+ "   <p>Yours Faithfully, </p>  "
+ "   <p>Cherubim and Seraphim Unification Campus Fellowship </p>  "
+ "   <p>ICT Team </p>  "
+ "   </body>  "
+ "   </html>  ";


try{

//SendMail ss = new SendMail();
String strsubject = "PASSWORD RESET for "+ FULLNAME;
//com.mashape.unirest.http.JsonNode JJJ=ss.sendSimpleMessage(recipient_email, strsubject, msg);
SendSMS_New	sss= new SendSMS_New();
SendSMS_New.send(MOBILENUMBER, msg);

System.out.println("SMS messge sent:::::::" + msg); 
System.out.println("SMS messge to address:::::::" + MOBILENUMBER); 
 
System.out.println("<<<<<<<<<PREPARED THE mesage and marSHALL  SMS   >>>>>>>>>>>>>>>>>>"); 



//SendEmail_NEW	sssEMAIL= new SendEmail_NEW();
//SendEmail_NEW	sssEMAIL= new SendEmail_NEW();
SendEmail  sssEMAIL  = new SendEmail();
String from="cnsunificationict@gmail.com";
//40THanniversary
//String from="anything@sixth-storm-312515.appspotmail.com";
//sssEMAIL.sendSimpleMail(from, recipient_email, emailmsg, strsubject);
sssEMAIL.sendMailUnification(from, recipient_email, strsubject, emailmsg);

System.out.println("EMAIL messge sent:::::::" + msg); 
System.out.println("EMAIL messge to address:::::::" + MOBILENUMBER); 
 
System.out.println("<<<<<<<<<PREPARED THE mesage and marSHALL  EMAIL   >>>>>>>>>>>>>>>>>>"); 

		
//////////////////////////////////////////////////////////////////////////////////



System.out.println("Done");

result.put("errorcode", "0");
//result.put("errordescription", "Successfully PASSWORD sent to the PROFILE +" + FULLNAME + " email "+msg);
result.put("errordescription", "Successfully sent PASSWORD to the PROFILE of " + FULLNAME + ", to your emailaddress: " +recipient_email + "   and  mobilenumber: "+MOBILENUMBER  );



} catch (Exception e) {
//throw new RuntimeException(e);
result.put("errorcode", "-1");
result.put("errordescription", "PASSWARD WAS NOT  sent" + e.getMessage());

}





  data.close();
  stmt.close();
  con.close();
  //return response;
  }else{
  	  

  data.close();
  stmt.close();
  con.close();
  //return response;
  }
  }catch(Exception exception)
 {
	  exception.printStackTrace();
	  System.out.println("error in method ::: getForgotPasswordWithID:::" + exception.getMessage());
  
 

}
  System.out.println(""); 
  System.out.println(result);


  response.getWriter().println(result);
}
}

	  