

package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;
import com.example.util.ResultSetToArrayList;


@WebServlet(name = "GetCSInbox", value = "/getCSInbox")
public class GetCSInbox extends HttpServlet {


/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
static Logger logger = Logger.getLogger(GetCSInbox.class.getName());


@SuppressWarnings({ "deprecation", "rawtypes" })
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	 response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");

	     String EVWID =request.getParameter("EVWID");
	     String NKEY=request.getParameter("NKEY").trim() ;
	   
	     String  sql = " ";
		   String  MAINsql = " ";
      Connection con = null;
      ArrayList aa =null;
      ArrayList ALLMsgs =null;

		
      try { con = pool.getConnection();
  	  
  	  
    
MAINsql = MAINsql + " SELECT J.REQRES, J.FR_FULLNAME, J.TO_FULLNAME FROM  ";
MAINsql = MAINsql + "  ( SELECT ";
MAINsql = MAINsql + " a.EVWID    '_'    a.RESPONSE_EVWID  REQRES";
MAINsql = MAINsql + " ,(SELECT B.SURNAME  ', '   B.FIRSTNAME FROM TBL_USERS B  WHERE  a.EVWID = B.EVW_ID) FR_FULLNAME   ";
MAINsql = MAINsql + "  ,(SELECT B.SURNAME  ', '   B.FIRSTNAME  FROM TBL_USERS B  WHERE  a.RESPONSE_EVWID = B.EVW_ID) TO_FULLNAME   ";
MAINsql = MAINsql + "  FROM TBL_TESTIMONY  a     ";
MAINsql = MAINsql + "   where a.EVWID='"+EVWID+"'     ";
MAINsql = MAINsql + "  and a.REQ_TYPE = 'M'     ";
MAINsql = MAINsql + "     UNION    ";
MAINsql = MAINsql + "                 SELECT    ";
MAINsql = MAINsql + "  a.EVWID    '_'    a.RESPONSE_EVWID  REQRES    ";
MAINsql = MAINsql + "  ,(SELECT B.SURNAME  ', '   B.FIRSTNAME FROM TBL_USERS B  WHERE  a.EVWID = B.EVW_ID) FR_FULLNAME   ";
MAINsql = MAINsql + "  ,(SELECT B.SURNAME  ', '   B.FIRSTNAME FROM TBL_USERS B  WHERE  a.RESPONSE_EVWID = B.EVW_ID) TO_FULLNAME   ";
MAINsql = MAINsql + "   FROM TBL_TESTIMONY  a      ";       
MAINsql = MAINsql + " where a.RESPONSE_EVWID='"+EVWID+"'     ";
MAINsql = MAINsql + "   and a.REQ_TYPE = 'M'      ";  
MAINsql = MAINsql + "           ) J        ";   






System.out.println("SQL:::"+ MAINsql );
PreparedStatement MSGs = con.prepareStatement(MAINsql);
ResultSet rsMsgs = MSGs.executeQuery();
ResultSetToArrayList rsal = new ResultSetToArrayList();
aa= rsal.ResultSetToArrayList(rsMsgs);

     
    }  catch(Exception e11)
    {
  	  
    }
      
      
      JSONObject results = null;
      
      JSONArray results_00 = null;

      JSONArray subresults = null;
      try
      {
    
	        System.out.println(sql);
          
	        sql = sql + " SELECT J.*  FROM     ";
	        sql = sql + " (SELECT a.TESTIMONY_ID,    ";
	        sql = sql + " 'TO:'  FROM_OR_TO,    ";
	        sql = sql + " a.EVWID,    ";
	        sql = sql + " (SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where  a.EVWID=c.EVW_ID ) FULLNAME ,    ";
	        sql = sql + " a.REQ_MSG RES_MSG,      "; 
	        sql = sql + " a.REQUEST_DATE RESPONSE_DATE,      "; 
	        sql = sql + " a.REQUEST_TIME   RESPONSE_TIME, "; 
	        sql = sql + " a.EVWID    '_'    a.RESPONSE_EVWID  REQRES ,"; 
	        sql = sql + "(SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where  a.EVWID=c.EVW_ID )    ";
	        sql = sql + "   '--'          ";
	        sql = sql + " (SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where  a.RESPONSE_EVWID=c.EVW_ID ) COMMUTE_MSG	   ";         

	        sql = sql + " FROM TBL_TESTIMONY  a    ";
	        sql = sql + " where a.RESPONSE_EVWID='"+EVWID+"'     ";
	        sql = sql + " and a.REQ_TYPE='M'     ";
	        sql = sql + " union    ";
	        sql = sql + " SELECT a.TESTIMONY_ID,    ";
	        sql = sql + " 'FR:',    ";
	        sql = sql + " a.RESPONSE_EVWID ,    ";
	        sql = sql + " (SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where   c.EVW_ID=a.RESPONSE_EVWID)  ,    ";
	        sql = sql + " a.RES_MSG,      "; 
	        sql = sql + " a.RESPONSE_DATE,      "; 
	        sql = sql + " a.RESPONSE_TIME  , ";    
	        sql = sql + " a.EVWID    '_'    a.RESPONSE_EVWID  REQRES , ";
	        sql = sql + "(SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where  a.EVWID=c.EVW_ID )    ";
	        sql = sql + "   '--'          ";
	        sql = sql + " (SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where  a.RESPONSE_EVWID=c.EVW_ID ) COMMUTE_MSG	   ";    
	        sql = sql + " FROM TBL_TESTIMONY a      ";
	        sql = sql + " where a.RESPONSE_EVWID='"+EVWID+"'      ";
	        sql = sql + " and a.REQ_TYPE='M'     ";
	        
	        sql = sql + " UNION    ";
	        
	        sql = sql + " SELECT a.TESTIMONY_ID,     ";  
	        sql = sql + " 'FR:'    ,    ";
	        sql = sql + " a.EVWID,      "; 
	        sql = sql + " (SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where  a.EVWID=c.EVW_ID )  ,    ";   
	        sql = sql + " a.REQ_MSG RES_MSG,      "; 
	        sql = sql + " a.REQUEST_DATE RESPONSE_DATE,      "; 
	        sql = sql + " a.REQUEST_TIME   RESPONSE_TIME, "; 
	        sql = sql + " a.EVWID    '_'    a.RESPONSE_EVWID  REQRES , "; 
	        sql = sql + "(SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where  a.EVWID=c.EVW_ID )    ";
	        sql = sql + "   '--'          ";
	        sql = sql + " (SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where  a.RESPONSE_EVWID=c.EVW_ID ) COMMUTE_MSG	   ";    
	        sql = sql + " FROM TBL_TESTIMONY  a    ";
	        sql = sql + " where a.EVWID='"+EVWID+"'     ";   
	        sql = sql + " and a.REQ_TYPE='M'     ";   
	        sql = sql + " union       ";
	        sql = sql + " SELECT a.TESTIMONY_ID,      "; 
	        sql = sql + " 'TO:',      "; 
	        sql = sql + " a.RESPONSE_EVWID ,      "; 
	        sql = sql + " (SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where   c.EVW_ID=a.RESPONSE_EVWID)  ,      "; 
	        sql = sql + " a.RES_MSG,      "; 
	        sql = sql + " a.RESPONSE_DATE,      "; 
	        sql = sql + " a.RESPONSE_TIME ,  "; 
	        sql = sql + " a.EVWID    '_'    a.RESPONSE_EVWID  REQRES  , "; 
	        sql = sql + "(SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where  a.EVWID=c.EVW_ID )    ";
	        sql = sql + "   '--'          ";
	        sql = sql + " (SELECT c.SURNAME   ', '    c.FIRSTNAME from  TBL_USERS c where  a.RESPONSE_EVWID=c.EVW_ID ) COMMUTE_MSG	   ";    
	        sql = sql + " FROM TBL_TESTIMONY  a    ";
	        sql = sql + " where a.EVWID='"+EVWID+"'     ";    
	        sql = sql + " and a.REQ_TYPE='M'      ";  

	       sql = sql + " order by   8 asc , 1 desc   ";
	        sql = sql + " ) J        ";
	        sql = sql + " LIMIT  100    ";


          
          
          
          
          
          
          PreparedStatement getAllUsers = con.prepareStatement(sql);
          ResultSet data = getAllUsers.executeQuery();
          
          ResultSetToArrayList rsal1 = new ResultSetToArrayList();
          ALLMsgs= rsal1.ResultSetToArrayList(data);
          
          results = new JSONObject();
          subresults = new JSONArray();
          results_00 =   new JSONArray();
          JSONObject item;
          int k=ALLMsgs.size();
          int kk=aa.size();
          ArrayList aarow = null;
          ArrayList ALLMsgsrow = null;
          for(int jj=0;jj<kk; jj++)
          {
          	aarow = (ArrayList) aa.get(jj);
          	JSONObject resObj = new JSONObject(); 
          	
          for(int j=0;j<k; j++)
          {
          	ALLMsgsrow = (ArrayList) ALLMsgs.get(j);
              if (ALLMsgsrow.get(7).toString().trim().equalsIgnoreCase(aarow.get(0).toString().trim()))
              {
          	item = new JSONObject();
          	
              item.put("MESSAGE_ID", ALLMsgsrow.get(0).toString());
              item.put("FROM_OR_TO",  ALLMsgsrow.get(1).toString());
              item.put("EVWID",  ALLMsgsrow.get(2).toString());
              item.put("FULLNAME", ALLMsgsrow.get(3).toString());
              String msg =ALLMsgsrow.get(4).toString();
              String reqdate =ALLMsgsrow.get(5).toString();
              String reqtime =ALLMsgsrow.get(6).toString();
             if (msg ==null) msg="";
              if (reqdate ==null) reqdate="";
              if (reqtime ==null) reqtime="";
item.put("MSG", msg);
item.put("REQUEST_DATE",reqdate);
item.put("REQUEST_TIME",reqtime);



subresults.add(item);


              }

              
    }
          
          resObj.put(aarow.get(1).toString().trim().toUpperCase() + " : " + aarow.get(2).toString().trim().toUpperCase(), subresults );
          //clear the json array of messages and pick a new batch
          subresults = new JSONArray();
          // add to result json object
          results.put(aarow.get(0).toString(),resObj);
          
          results_00.add(resObj);
          //results.put("CHAT_HISTORY",resObj);
          
          }

          getAllUsers.close();
          con.close();
      }
      catch(SQLException e)
      {
          results = new JSONObject();
          JSONObject item = new JSONObject();
           item.put("MESSAGE_ID", "");
              item.put("FROM_OR_TO", "");
           item.put("EVWID", "");
           item.put("FULLNAME", MAINsql);
item.put("MSG", "");
item.put("REQUEST_DATE", e.getMessage());
item.put("REQUEST_TIME",sql);


JSONObject resObj = new JSONObject(); 
resObj.put("MESSAGE_FRM_TO_ERROR"  , item);


//results_00.add(resObj);
          e.printStackTrace();
      }
      JSONObject resultsObj = new JSONObject(); 
      resultsObj.put("INBOX_LAST_30_MESSAGES", results);
      
    
      System.out.println(""); 
      System.out.println(resultsObj);


      response.getWriter().println(resultsObj);
      }
}
	
	     