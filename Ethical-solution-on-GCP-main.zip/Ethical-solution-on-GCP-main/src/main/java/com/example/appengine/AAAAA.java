package com.example.appengine;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

public class AAAAA {

    public static void main(String[] args) throws IOException {
        String url = "http://example.com/api/myresource";
        URL obj = new URL(url);
        
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        
        

        // set the request method
        con.setRequestMethod("POST");

        // set the request headers
        con.setRequestProperty("Content-Type", "application/json");

        // set the request body
        String requestBody = "{\"name\":\"John\", \"age\":30}";
        con.setDoOutput(true);
        con.getOutputStream().write(requestBody.getBytes());

        // read the response
        int responseCode = con.getResponseCode();
        InputStream inputStream = con.getInputStream();
        BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder response = new StringBuilder();
        String inputLine;
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }

        // print the response headers
        Map<String, List<String>> headers = con.getHeaderFields();
        for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
            String key = entry.getKey();
            List<String> values = entry.getValue();
            if (key == null) {
                System.out.println(values.get(0));
            } else {
                System.out.println(key + ": " + values);
            }
        }

        // print the response
        System.out.println("Response Code : " + responseCode);
        System.out.println("Response : " + response.toString());

        // close the resources
        in.close();
        inputStream.close();
    }
}
