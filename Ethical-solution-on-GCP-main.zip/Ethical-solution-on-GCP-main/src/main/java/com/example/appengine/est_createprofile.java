

package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringEscapeUtils;

import com.api.json.JSONObject;
import com.example.util.*;


@WebServlet(name = "est_createprofile", value = "/est_createprofile")
public class est_createprofile extends HttpServlet {

/**
 * 
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(GetChapters.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  
	  String FIRSTNAME =StringEscapeUtils.escapeEcmaScript( request.getParameter("FIRSTNAME"));
	  String SURNAME=StringEscapeUtils.escapeEcmaScript( request.getParameter("SURNAME")) ;
	  String CHAPTER =StringEscapeUtils.escapeEcmaScript( request.getParameter("CHAPTER")) ;
	  String MOBILENUMBER=request.getParameter("MOBILENUMBER") ;
	  String MACADDRESS=request.getParameter("MACADDRESS") ;  
	  String EMAILADDRESS=request.getParameter("EMAILADDRESS")  ;
	  String PASSWORD=request.getParameter("PASSWORD") ;
	  String CONFIRMPASSWORD=request.getParameter("CONFIRMPASSWORD") ;
	  String GRADUATION_YEAR=request.getParameter("GRADUATION_YEAR") ; 
	  String STATUS=request.getParameter("STATUS");
	  String APPID=request.getParameter("APPID") ;
	  String NKEY=	request.getParameter("NKEY").trim()  ;
	  JSONObject result =null;
  
{

System.out.println("****************************************************************************");
System.out.println(" FIRSTNAME  :" +FIRSTNAME );
System.out.println(" SURNAME :" +SURNAME) ;
System.out.println(" CHAPTER  :" +CHAPTER) ;
System.out.println(" MOBILENUMBER  :" +MOBILENUMBER) ;
System.out.println(" MACADDRESS  :" +MACADDRESS) ;  
System.out.println(" EMAILADDRESS  :" +EMAILADDRESS) ;  
System.out.println(" PASSWORD  :" +PASSWORD) ;  
System.out.println(" CONFIRMPASSWORD  :" +CONFIRMPASSWORD) ;  
System.out.println(" GRADUATION_YEAR  :" +GRADUATION_YEAR) ;  
System.out.println(" STATUS  :" +STATUS );
System.out.println(" APPID  :" +APPID) ;  
System.out.println(" NKEY:"+NKEY)  ;

System.out.println("****************************************************************************");


	  Statement stmt=null;
	  String insertSQL="";
	  String Token;
	  String insertvALUESSQL;
	  try (Connection con = pool.getConnection()) 
	  {
		   
		   System.out.println("<<<<<<<< CREATE CONNECTION  SUCCESSFULLY>>>>>>>>>>>>>");
	
	  stmt = null;
	 
	  EMAILADDRESS = EMAILADDRESS.toLowerCase().trim();
	  RandomNumberGen rGen = new RandomNumberGen();
	  Token = String.valueOf(rGen.getRandomNumber());
	  System.out.println("token generated:::"+ Token);

 
  
	  String 	BIRTHDATE = "1900-01-01" ;
	  String	 STREET1 ="NA";
	  String	 STREET2 ="NA";
	  String		LGA="NA";
	  String 		STATE="NA" ;
	  String  MARITAL_STATUS="S";
	  
 
	  if(CHAPTER.trim().substring(0, 3).equalsIgnoreCase("***"))
	  {
	  	    result = new JSONObject();
	       result.put("errorcode", "-2");
	       result.put("errordescription", "Select a valid Chapter from the List");
	     
	  }else
	  {
	  
	  
	  
		  insertvALUESSQL = " VALUES (  CURDATE(), CURTIME(), ";
		  insertSQL =  insertSQL + "INSERT INTO TBL_USERS (DATE_CREATED,TIME_CREATED,FIRSTNAME,MIDDLENAME,SURNAME ,BIRTHDATE ,STREET1 ,STREET2 ," ;
		  insertSQL =  insertSQL + " LGA ,STATE ,MARITAL_STATUS ,MOBILENUMBER  ,MACADDRESS   ,EMAILADDRESS ,PASSWORD" +
		" ,CONFIRMPASSWORD,token,APP_ID, logincount, STATUS, CUSTOMER_CLASSIFICATION ) ";
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(FIRSTNAME).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(CHAPTER).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(SURNAME).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(BIRTHDATE).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(STREET1).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(STREET2).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(LGA).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(STATE).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(MARITAL_STATUS).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(MOBILENUMBER).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(MACADDRESS).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(EMAILADDRESS).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(PASSWORD).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(CONFIRMPASSWORD).append("', ").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(Token).append("', ").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(APPID).append("', ").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'0' ,").toString();
		  
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'"+STATUS+"', ").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'"+GRADUATION_YEAR+"' ) ").toString();
		
		  Boolean bbb = Boolean.valueOf(false);
		  System.out.println("********************************************************************************" +
				  	"***"
				  	);
		  System.out.println((new StringBuilder()).append(insertSQL).append(insertvALUESSQL).toString());
		
	
		  try{
			  stmt = con.createStatement();
			   bbb = Boolean.valueOf(stmt.execute(insertSQL+insertvALUESSQL));
			  System.out.println("SUCCESSFULLULLY INSERYTED*****");
			
			  //SendSMS ss = new SendSMS();
			  //String ToMobileNo = MOBILENUMBER;
			  //String FromMobileNo = "+2348120796782";
			  //String strMessage = (new StringBuilder()).append(" PLEASE ENTER THE TOKEN NUMBER :  ").append(Token).append(" TO VALIDATE YOUR PROFILE.").toString();
			  //String mesgID ="";
			  //	mesgID=	ss.send(ToMobileNo, FromMobileNo, strMessage);
			   result = new JSONObject();
			  result.put("errorcode", "0");
			  result.put("errordescription", "Successful CREATION ");
			  stmt.close();
			  con.close();
		  } catch (Exception eee)
		  	{
			  eee.printStackTrace();
			  System.out.println("**********************************************************************");
			  System.out.println((new StringBuilder()).append(insertSQL).append(insertvALUESSQL).toString());
			  System.out.println("**********************************************************************");
			   result = new JSONObject();
			  result.put("errorcode", "-1");
			  result.put("errordescription", eee.getMessage() + "    " + insertSQL + insertvALUESSQL);
			  stmt.close();
			  con.close();
		  }finally
		  {
		  stmt.close();
		  con.close();
		
		}
	  
	 } // else

	  } catch (Exception ee)
{
	   result = new JSONObject();
	  result.put("errorcode", "-9");
	  result.put("errordescription", ee.getMessage() + "    " + "COULD NOT ESTABLISH CONNECTION");	
}
	  System.out.println(""); 
System.out.println(result);
System.out.println(result); 

response.getWriter().println(result);
}

  




	  




}



}
