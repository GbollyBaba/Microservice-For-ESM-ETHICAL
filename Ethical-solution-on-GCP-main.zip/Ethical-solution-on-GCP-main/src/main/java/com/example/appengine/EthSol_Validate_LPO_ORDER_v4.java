

package com.example.appengine;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.Statement;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.logging.Logger;
import java.util.stream.BaseStream;
import java.util.stream.IntStream;

/*
 * 
  account name - oa_adelaja@hotmail.com

	  password - ethicalsoft10*
  
 * 
 */
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringEscapeUtils;
import org.json.JSONArray;

import org.json.JSONObject;
import com.example.util.*;
import com.mysql.cj.jdbc.CallableStatement;


//// the token to be used
//        ~^^^
@SuppressWarnings("deprecation")

@WebServlet(
	    name = "EthSol_Validate_LPO_ORDER_v4",
	    urlPatterns = {"/EthSol_Validate_LPO_ORDER_v4"}
	)

public class EthSol_Validate_LPO_ORDER_v4 extends HttpServlet {

/**
 *
 * 
  mvn clean package appengine:deploy
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(EthSol_Create_LPO_ORDER_v4.class.getName());

Connection con = null;
java.sql.CallableStatement cs = null;	 

@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  
	  
	  
	  JSONObject dbresult = null;
	  
	  Double TOTAL_LPO_ITEMs=0.00;

	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");


	  String LPO_ISSUER_ID= request.getParameter("LPO_ISSUER_ID");
	  String VAL_OF_PO =request.getParameter("VAL_OF_PO");
	  String BORROWER_COST=  request.getParameter("BORROWER_COST");
	  String DATE_INV_NEEDED =request.getParameter("DATE_INV_NEEDED");
	  String MATERIAL_SOURCE_COUNTRY_ID =request.getParameter("MATERIAL_SOURCE_COUNTRY_ID");
	  String ISSUER_PAY_ONTIME =request.getParameter("ISSUER_PAY_ONTIME");

	  String LPO_NUMBER =request.getParameter("LPO_NUMBER").trim();
	  String LPO_SUPPLIER_COY_ID =request.getParameter("LPO_SUPPLIER_COY_ID");
	  
	  
	  String LPO_LINE_PRICE =request.getParameter("LPO_LINE_PRICE");
	  String INITIAL_INVESTMENT_BY_BORROWER =request.getParameter("INITIAL_INVESTMENT_BY_BORROWER");
	  
	  String LPO_ITEMS = request.getParameter("LPO_ITEMS").trim();
	  
	  int intROWSINSERTED =-1;
	  double dblPercentProfit = 0.00;
	  double dblPercentContribution = 0.00;

	  if (pool!= null)
	  {
		   try {
			con = pool.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  }

	  System.out.println(" ******* VALIDATE THE ACCEPTANCE OF THE LPO***********"); 
	///CREATE THE LPO SUMMARY	  
	  String LPO_DUE_DATE =request.getParameter("LPO_DUE_DATE");
	  String STATUS =request.getParameter("STATUS");
	  String LPO_BORROWER_ID =request.getParameter("LPO_BORROWER_ID");
	  String LPO_ISSUER_PAYTERMS_ID =request.getParameter("LPO_ISSUER_PAYTERMS_ID");
	  String CHANNEL =request.getParameter("CHANNEL");
	  String NKEY =request.getParameter("NKEY").trim();
	  
	  
	  
	  	
////////////////////////////////////////SECURITY CHECK///////////////////////////////////////////////////////////////////////////////
JSONObject resultsVAlidate = new JSONObject();
String [] nkeyValues  = NKEY.split(" ");
if (nkeyValues.length == 5)
{
//EMAIL TYPEOFACTOR HQTECH IPADDRESS NKEY

String EMAIL = nkeyValues[0];
String TYPEOFACTOR = nkeyValues[1];
String MACHINE_NAME_VALUE = nkeyValues[2];
String MACHINE_IPADDRESS_VALUE = nkeyValues[3];
String NKEY_VALUE = nkeyValues[4];
JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
String res = gg.ValidateToken(NKEY_VALUE);
System.out.println("**********************SECURITY CHECK WITH OUATH2 & WEB TOKEN******************************* ");
System.out.println(" EMAIL :"+EMAIL);
System.out.println(" TYPEOFACTOR :"+TYPEOFACTOR);
System.out.println(" MACHINE_NAME_VALUE :"+MACHINE_NAME_VALUE);
System.out.println(" MACHINE_IPADDRESS_VALUE :"+MACHINE_IPADDRESS_VALUE);
System.out.println(" NKEY_VALUE :"+NKEY_VALUE);
System.out.println("************************************************************************************* ");
////GET CONNECTION
String fraudError=	"X"; //Y for posssible man in the middle attack!!!!, N NO ERROR(SUCCESS), Y INVALID token

if (pool!= null)
{
try {
con = pool.getConnection();
} catch (SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}

System.out.println(" ValidateToken :"+res);

if (!res.equalsIgnoreCase("Y"))
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}
if (res.equalsIgnoreCase("Y"))
{

try {
fraudError=	gg.ValidateTokenToReturnClaims(NKEY_VALUE,Integer.parseInt(LPO_BORROWER_ID),con);
} catch (NumberFormatException | SQLException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}

if(fraudError=="Y") 
{
resultsVAlidate.put("errorcode", "-5000");
resultsVAlidate.put("errordescription",  "MAN IN THE MIDDLE ATTACK");
response.getWriter().println(resultsVAlidate);
return;
}

if(fraudError=="X") 
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}



}


}else
{
resultsVAlidate.put("errorcode", "-3000");
resultsVAlidate.put("errordescription",  "Incomplete paramets passed...");
response.getWriter().println(resultsVAlidate);
return;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

System.out.println("****************************************************************************");
System.out.println(" LPO_ISSUER_ID:"+LPO_ISSUER_ID);
System.out.println(" VAL_OF_PO :"+VAL_OF_PO);
System.out.println(" BORROWER_COST:"+BORROWER_COST);
System.out.println(" DATE_INV_NEEDED :"+DATE_INV_NEEDED);
System.out.println(" MATERIAL_SOURCE_COUNTRY_ID :"+MATERIAL_SOURCE_COUNTRY_ID);
System.out.println(" ISSUER_PAY_ONTIME :"+ISSUER_PAY_ONTIME);
System.out.println(" INITIAL_INVESTMENT_BY_BORROWER :"+ INITIAL_INVESTMENT_BY_BORROWER); 
String LPO_TOTAL_PRICE = "";
try 
{

System.out.println(" LPO_NUMBER :"+LPO_NUMBER);
System.out.println(" LPO_SUPPLIER_COY_ID :"+LPO_SUPPLIER_COY_ID);
String strVALIDATE_LPO_TRANSACTION="N";
//convert the TOTAL_SUM_OF_LPO_ITEMS to  string..

System.out.println(" LPO_DUE_DATE :"+LPO_DUE_DATE);

System.out.println(" STATUS :"+STATUS);
System.out.println(" LPO_BORROWER_ID :"+LPO_BORROWER_ID);
System.out.println(" LPO_ISSUER_PAYTERMS_ID :"+LPO_ISSUER_PAYTERMS_ID);
System.out.println(" CHANNEL :"+CHANNEL);
System.out.println(" NKEY :"+NKEY);
System.out.println("****************************************************************************");

	  ResultSet data= null;
	  
	  

JSONArray array = new JSONArray(LPO_ITEMS); 
System.out.println("==================================================================");
   for(int i=0; i < array.length(); i++)   
   {  
   JSONObject object = array.getJSONObject(i); 
   System.out.println(TOTAL_LPO_ITEMs); 
   System.out.println(LPO_NUMBER); 
   System.out.println(object.getString("LPO_ITEM_MEASUREMENT_TYPE_ID"));  
   System.out.println(object.getString("LPO_ITEM_DESCRIPTION")); 
   System.out.println(object.getString("LPO_QUANTITY"));  
   System.out.println(object.getString("LPO_UNIT_PRICE"));  
   System.out.println(object.getString("LPO_TOTAL_PRICE"));  
   
   
   String LPO_ITEM_MEASUREMENT_TYPE_ID =object.getString("LPO_ITEM_MEASUREMENT_TYPE_ID");
   String LPO_ITEM_DESCRIPTION =object.getString("LPO_ITEM_DESCRIPTION");
   String LPO_QUANTITY =object.getString("LPO_QUANTITY");
   String LPO_UNIT_PRICE =object.getString("LPO_UNIT_PRICE");
   LPO_TOTAL_PRICE =object.getString("LPO_TOTAL_PRICE");
   
   TOTAL_LPO_ITEMs = TOTAL_LPO_ITEMs + Double.parseDouble(LPO_TOTAL_PRICE);

   }
   System.out.println("==================================================================");
   System.out.println("Check wether the total items  sum is the same as the Borrower cost");    
   System.out.println("TOTAL_LPO_ITEMs::::"+TOTAL_LPO_ITEMs); 
   System.out.println("BORROWER_COST::::::"+BORROWER_COST); 
   System.out.println("==================================================================");

double diff = Math.abs( TOTAL_LPO_ITEMs - Double.parseDouble(BORROWER_COST) );

// tolerance level must less than  ten raise to power minus 3  0.001

double tolerancevalue = 0.001;



	  
System.out.println("<<<<<<<< CREATE CONNECTION  SUCCESSFULLY>>>>>>>>>>>>>");	
  String StoredProcedure = "{ call SP_VALIDATE_LPO_ORDER_v4(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }";
 cs = con.prepareCall(StoredProcedure);
	cs.setInt(1, Integer.parseInt(LPO_ISSUER_ID));
	/// this is now the value of PO;
	cs.setDouble(2, Double.parseDouble(VAL_OF_PO));
	cs.setDouble(3, Double.parseDouble(BORROWER_COST));
	cs.setString(4,   DATE_INV_NEEDED);
	  cs.setInt(5, Integer.parseInt(MATERIAL_SOURCE_COUNTRY_ID));
	  cs.setString(6, ISSUER_PAY_ONTIME);
	  cs.setString(7, LPO_NUMBER);
	  cs.setInt(8,Integer.parseInt(LPO_SUPPLIER_COY_ID));
	  cs.setString(9,  LPO_DUE_DATE);
	  cs.setString(10, STATUS);
	  cs.setInt(11, Integer.parseInt(LPO_BORROWER_ID));
	  cs.setInt(12, Integer.parseInt(LPO_ISSUER_PAYTERMS_ID));
	  cs.setDouble(13, Double.parseDouble(INITIAL_INVESTMENT_BY_BORROWER));

	  cs.registerOutParameter(14,Types.INTEGER);
	  //create the items affter successful LPO creation of the LPO_NUMBER
	  cs.registerOutParameter(15,Types.DOUBLE);
	 
	  data = cs.executeQuery();

	  intROWSINSERTED=cs.getInt(14);
	  
	  System.out.println("intVALIDATE_LPO_TRANSACTIOM:::"+intROWSINSERTED);
	  
	  dblPercentProfit = cs.getDouble(15);
	  dblPercentContribution = cs.getDouble(16);
	  System.out.println("dblPercentProfit:::"+dblPercentProfit);
	  System.out.println("dblPercentContribution:::"+dblPercentContribution);
	  
	  String mremedymsg = "";
	  
	 
	  int intAllowbasedOnProfiatbility= -10;
	  
	  int intAllow= -10;
	  
	  if (dblPercentContribution >= 30.0 && dblPercentContribution <= 50.0) intAllow=0;//allowed
	  if (dblPercentContribution > 50.0 && dblPercentContribution <= 70.0) intAllow=0;// allowed
	  if (dblPercentContribution > 70.0) intAllow=1; // percent contribution by borrower is above 70% NOT ALLOWED!
	  if (dblPercentContribution < 30.0) intAllow=2;// percent contribution by borrower is Less than 30% NOT ALLOWED!
	  if (dblPercentProfit >= 5.0) intAllowbasedOnProfiatbility=3;// the profit is greater than or equal to  5% .   ALLOWED
	  
	  if (intAllowbasedOnProfiatbility ==3)
	  {
		  switch (intAllow) {

		  case 0:
			  mremedymsg = mremedymsg+"Borrower Contributed ::::"+dblPercentContribution +"%  and it is allowed"
			  		+ "\n"
			  		+ "with Profitability of ["+dblPercentProfit+"%]";
		      break;
		  case 1:
			  mremedymsg = mremedymsg+"Borrower Contributed ::::"+dblPercentContribution +"%  percent contribution "
		+ "by borrower is above 70% NOT ALLOWED"
		+ "\n"
		
  		+ "although Profitability is ["+dblPercentProfit+"%]"
  		+ "\n"
		+ "Kindly reduce  your INITIAL DEPOSIT When ReCreating the  LPO Funding Request";
		      break;
		  case 2:
		    
		      mremedymsg = mremedymsg+"Borrower Contributed ::::"+dblPercentContribution +"%  percent contribution "
		+ "by borrower is less than  30% NOT ALLOWED"
		+ "\n"
		+ "although Profitability is ["+dblPercentProfit+"%]"
  		+ "\n"
		+ "Kindly increase  your INITIAL DEPOSIT When ReCreating the  LPO Funding Request";
		          
		          break;
		  }
		  
	  }else
	  {
		  
		  mremedymsg = mremedymsg+"This kind of LPO is NOT Allowed because the Profitability of ["+dblPercentProfit+"%] is less than 5%.";  
	  }
	  
	  
	  
	  
 
	  
	  
	  
	  
	  dbresult = new JSONObject();
      dbresult.put("errorcode", "0");
      // check for totalitems that make up the borower cost 
      System.out.println("diff::::"+diff);	
      System.out.println("tolerancevalue::::"+tolerancevalue);	
      
      if (diff <= tolerancevalue)
      {
       System.out.println("The total ITEMs number matches the Borrower Cost");	  
      

      if (intROWSINSERTED == 0)
      {
      dbresult.put("errordescription", "THE LPO["+LPO_NUMBER+"] TRANSACTION IS ELIGIBLE , PROCEED TO FUND WITH THE INITIAL INVESTMENT AMOUNT");
      dbresult.put("ELIGIBILITY", "Y");
  
      }else if (intROWSINSERTED == -1)
      {
    	  
    	//  cs.setDouble(2, Double.parseDouble(VAL_OF_PO));
    	//	cs.setDouble(3, Double.parseDouble(BORROWER_COST));
    	  dbresult.put("errordescription", "THE LPO["+LPO_NUMBER+"] TRANSACTION IS NOT ELIGIBLE ,"
      	  		+ " the profit margins is less than "+ String.valueOf(dblPercentProfit) +"%   "
      	  		+ " INITIAL DEPOSIT: " + INITIAL_INVESTMENT_BY_BORROWER +"\n"
      	  		+ " TOTAL_LPO_ITEMs:" + TOTAL_LPO_ITEMs +"\n"
      	  		+ " BORROWER_COST:" + BORROWER_COST +"\n"
      	  		+ " PERCENT_PROFIT:"+  String.valueOf(dblPercentProfit) +"%   " +"\n"
      	  		+ " PERCENT_CONTRIBUTION:"+  String.valueOf(dblPercentContribution) +"%   " +"\n"
      	  		+ " ");
           
      dbresult.put("ELIGIBILITY", "N");  

      }else if (intROWSINSERTED == -2)
   
      {
    	   System.out.println("TOTAL_LPO_ITEMs::::"+TOTAL_LPO_ITEMs); 
    	   System.out.println("BORROWER_COST::::::"+BORROWER_COST); 
    	  
    	  dbresult.put("errordescription", "THE LPO["+LPO_NUMBER+"] TRANSACTION IS NOT ELIGIBLE ,"
    	  		+ " the Borrower Contribution is greater than "+ String.valueOf(dblPercentProfit) +"%  it must be  less or equal to"
    	  				+ " 50%  "
    	  		+ " INITIAL DEPOSIT: " + INITIAL_INVESTMENT_BY_BORROWER
    	  		+ " TOTAL_LPO_ITEMs:" + TOTAL_LPO_ITEMs
    	  		+ " BORROWER_COST:" + BORROWER_COST
    	  		+ " PERCENT_PROFIT:"+  String.valueOf(dblPercentProfit) +"%   "
    	  		+ " PERCENT_CONTRIBUTION:"+  String.valueOf(dblPercentContribution) +"%   "
    	  		+ "");
    	
      }
      }else
      {
    	  System.out.println("TOTAL_LPO_ITEMs::::"+TOTAL_LPO_ITEMs); 
   	   System.out.println("BORROWER_COST::::::"+BORROWER_COST); 
   	mremedymsg = "Please verfy that the BORROWER COST IS THE SAME AS THE  SUM OF THE  LPO ITEMs and resubmit the LPO Request For Funding.";
   	  
   	  dbresult.put("errordescription", "THE LPO["+LPO_NUMBER+"] TRANSACTION IS NOT ELIGIBLE ,"
   	  		+ " The LPO ITEMS does not match the BORROWER COST !!!"
   	  		+ " INITIAL DEPOSIT: " + INITIAL_INVESTMENT_BY_BORROWER
   	  		+ " TOTAL_LPO_ITEMs:" + TOTAL_LPO_ITEMs
   	  		+ " BORROWER_COST:" + BORROWER_COST
  		+ " PERCENT_PROFIT:"+  String.valueOf(dblPercentProfit) 
  		+ " PERCENT_CONTRIBUTION:"+  String.valueOf(dblPercentContribution) 
   	  		+ "");
         dbresult.put("ELIGIBILITY", "F");    

      
      }
      dbresult.put("errordescription_remedy", mremedymsg);
      
      
    	  
    	  
	if (data != null)  data.close();
	cs.close();
	con.close();  
	  
	  
	  
	  
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	   }catch(java.sql.SQLIntegrityConstraintViolationException sqlerror)
	  {
		 dbresult = new JSONObject();
	      dbresult.put("errorcode", "-2");
	      dbresult.put("ELIGIBILITY", "N");
	      dbresult.put("errordescription",  sqlerror.getMessage());
	      dbresult.put("errordescription_remedy", "Contact Administrator");
	      
 
				try {
					cs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				  try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
	  }
	  catch (Exception eee)
	  	{
		  dbresult = new JSONObject();
	      dbresult.put("errorcode", "-1");
	      dbresult.put("ELIGIBILITY", "N");
	      dbresult.put("errordescription",  eee.getMessage());
	      dbresult.put("errordescription_remedy", "Contact Administrator");
		  eee.printStackTrace();
		}
	

response.getWriter().println(dbresult);

}


}
  




	


