
package com.example.appengine;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONObject;
import com.example.util.JWTGenerateValidateHMAC;
import com.example.util.ResultSetToArrayList;
import com.example.util.SendEmail;
import com.example.util.SendSMS_New;

@WebServlet(name = "EthSol_ForgotPasswordWithEmail", value = "/EthSol_ForgotPasswordWithEmail")
public class EthSol_ForgotPasswordWithEmail extends HttpServlet {

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(EthSol_ForgotPasswordWithEmail.class.getName());

@SuppressWarnings("rawtypes")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  

  Statement stmt=null;
  ResultSet data=null;
  
  String EMAILADDRESS = request.getParameter("EMAILADDRESS");
  
  //FIRSTNAME
  String APPID = request.getParameter("APPID");
  String NKEY = request.getParameter("NKEY").trim();
  String TYPE_OF_ACTOR =request.getParameter("TYPE_OF_ACTOR");
  
  
	
////////////////////////////////////////SECURITY CHECK///////////////////////////////////////////////////////////////////////////////
JSONObject resultsVAlidate = new JSONObject();
String [] nkeyValues  = NKEY.split(" ");
if (nkeyValues.length == 5)
{
//EMAIL TYPEOFACTOR HQTECH IPADDRESS NKEY

String EMAIL = nkeyValues[0];
String TYPEOFACTOR = nkeyValues[1];
String MACHINE_NAME_VALUE = nkeyValues[2];
String MACHINE_IPADDRESS_VALUE = nkeyValues[3];
String NKEY_VALUE = nkeyValues[4];
JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
String res = gg.ValidateToken(NKEY_VALUE);
System.out.println("**********************SECURITY CHECK WITH OUATH2 & WEB TOKEN******************************* ");
System.out.println(" EMAIL :"+EMAIL);
System.out.println(" TYPEOFACTOR :"+TYPEOFACTOR);
System.out.println(" MACHINE_NAME_VALUE :"+MACHINE_NAME_VALUE);
System.out.println(" MACHINE_IPADDRESS_VALUE :"+MACHINE_IPADDRESS_VALUE);
System.out.println(" NKEY_VALUE :"+NKEY_VALUE);
System.out.println("************************************************************************************* ");


System.out.println(" ValidateToken :"+res);

if (!res.equalsIgnoreCase("Y"))
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}
}else
{
resultsVAlidate.put("errorcode", "-3000");
resultsVAlidate.put("errordescription",  "Incomplete paramets passed...");
response.getWriter().println(resultsVAlidate);
return;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  System.out.println(EMAILADDRESS);
 
  System.out.println(TYPE_OF_ACTOR);
  

  String loginSQL="   ";
  JSONObject result = null;

	
  try (Connection con = pool.getConnection()) {
  stmt = con.createStatement();
  loginSQL = "   SELECT "+TYPE_OF_ACTOR+"_ID,DATE_CREATED,TIME_CREATED,FIRSTNAME,MIDDLENAME"
  		+ ",SURNAME,BIRTHDATE,STREET1,STREET2,MARITAL_STATUS"
  		+ ",MOBILENUMBER,MACADDRESS,EMAILADDRESS,PASSWORD,CONFIRMPASSWORD"
  		+ ",CUSTOMER_CLASSIFICATION,TOKEN,LOGINCOUNT,STATUS  FROM  "+TYPE_OF_ACTOR+"  WHERE 1=1 ";
  loginSQL = loginSQL +"  "
		
				 + "  AND upper(trim(EMAILADDRESS))= '"+EMAILADDRESS.toUpperCase().trim()+"' "
  		+ "  ";
  System.out.println(loginSQL);

  
  result = new JSONObject();
  data = stmt.executeQuery(loginSQL);
  ResultSetToArrayList rrResultSetToArrayList = new ResultSetToArrayList();
  ArrayList kk = rrResultSetToArrayList.ResultSetToArrayList(data);
  if(kk.size() >= 1)
  {
   
  ArrayList rowAl = (ArrayList)kk.get(0);
  System.out.println("<<<<<<<<<PICKED THE PASSWORD>>>>>>>>>>>>>>>>>>");      

// Send the PASSWORD TO THE EMAIL ADDRES ATTACHED To THE PROFILE




String recipient_email=rowAl.get(12).toString();
String strLASTNAME = rowAl.get(5).toString();
String strFIRSTNAME=rowAl.get(3).toString();

String FULLNAME  = strLASTNAME +",  " + strFIRSTNAME;
String strPASSWORD = rowAl.get(13).toString();
String MOBILENUMBER= rowAl.get(10).toString();



String msg = "Dear "+strFIRSTNAME +"," +
"\n\n PASSWORD "+ strPASSWORD  + "\n\n   Regards";

String emailmsg=" <html>   "
+ "   <body>  "
+ "    <br> <br>  "
+ "   <p>Dear  <b> "+strFIRSTNAME +"</b>,  </p>  "

+ "    <br>  "
+ "   <p>Your Forgotten  PASSWORD is:  <b> "+ strPASSWORD  + "</b>  "
+ "   <p>Use the PASSWORD to log on to the EVF platform and change your Password afterward. </p>  "
+ "   <br>  "
+ "   <br>  "

+ "   <p>Yours Faithfully, </p>  "
+ "   <p>ETHICAL SOLUTION LIMITED </p>  "
+ "   <p>ICT Team </p>  "
+ "   </body>  "
+ "   </html>  ";


try{

//SendMail ss = new SendMail();
String strsubject = "PASSWORD RESET for "+ FULLNAME;
//com.mashape.unirest.http.JsonNode JJJ=ss.sendSimpleMessage(recipient_email, strsubject, msg);
SendSMS_New	sss= new SendSMS_New();
SendSMS_New.send(MOBILENUMBER, msg);

System.out.println("SMS messge sent:::::::" + msg); 
System.out.println("SMS messge to address:::::::" + MOBILENUMBER); 
 
System.out.println("<<<<<<<<<PREPARED THE mesage and marSHALL  SMS   >>>>>>>>>>>>>>>>>>"); 



//SendEmail_NEW	sssEMAIL= new SendEmail_NEW();
//SendEmail_NEW	sssEMAIL= new SendEmail_NEW();
SendEmail  sssEMAIL  = new SendEmail();
String from="";
//40THanniversary
//String from="anything@sixth-storm-312515.appspotmail.com";
//sssEMAIL.sendSimpleMail(from, recipient_email, emailmsg, strsubject);
sssEMAIL.sendMail1(from, recipient_email, emailmsg,strsubject);

System.out.println("EMAIL messge sent:::::::" + msg); 
System.out.println("EMAIL messge to address:::::::" + MOBILENUMBER); 
 
System.out.println("<<<<<<<<<PREPARED THE mesage and marSHALL  EMAIL   >>>>>>>>>>>>>>>>>>"); 

		
//////////////////////////////////////////////////////////////////////////////////



System.out.println("Done");

result.put("errorcode", "0");
//result.put("errordescription", "Successfully PASSWORD sent to the PROFILE +" + FULLNAME + " email "+msg);
result.put("errordescription", "Successfully sent PASSWORD to the PROFILE of " + FULLNAME + ", to your emailaddress: " +recipient_email + "   and  mobilenumber: "+MOBILENUMBER  );



} catch (Exception e) {
//throw new RuntimeException(e);
result.put("errorcode", "-1");
result.put("errordescription", "PASSWARD WAS NOT  sent" + e.getMessage());

}





  data.close();
  stmt.close();
  con.close();
  //return response;
  }else{
  	  

  data.close();
  stmt.close();
  con.close();
  //return response;
  }
  }catch(Exception exception)
 {
	  exception.printStackTrace();
	  System.out.println("error in method ::: EthSol_ForgotPasswordWithEmail:::" + exception.getMessage());
  
 

}
  System.out.println(""); 
  System.out.println(result);


  response.getWriter().println(result);
}
}

	  