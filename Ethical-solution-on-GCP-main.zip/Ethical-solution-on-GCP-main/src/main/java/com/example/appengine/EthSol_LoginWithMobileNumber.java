
package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;


import com.api.json.JSONArray;
import com.api.json.JSONObject;

import com.example.util.*;

//EthSol_LoginWithEmail
@WebServlet(name = "EthSol_LoginWithMobileNumber", value = "/EthSol_LoginWithMobileNumber")
public class EthSol_LoginWithMobileNumber extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Define logger (Standard java.util.Logger)
	static Logger logger = Logger.getLogger(EthSol_LoginWithMobileNumber.class.getName());
	


  @SuppressWarnings("rawtypes")
@Override
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");


	  JSONObject result =null;
	    JSONArray results = null;
	    
	  
	  
	    PreparedStatement getAllUsers =null;
	    Connection con=null;
	      Statement stmt=null;
	      ResultSet data=null;
	
	  	String MOBILENUMBER =request.getParameter("MOBILENUMBER")  ; 
	  	String xPASSWORD =request.getParameter("xPASSWORD")  ;
	    String TYPE_OF_ACTOR =request.getParameter("TYPE_OF_ACTOR");
	  	String NKEY = request.getParameter("NKEY").trim();
  	     String loginSQL="";
  	   ArrayList kk =null;
       
       ArrayList arrColumnNames = null;
	  try (Connection conn = pool.getConnection()) {
      stmt = conn.createStatement();
      
      switch (TYPE_OF_ACTOR) {
      case "LPO_BORROWER":  
    	  loginSQL= "   SELECT Curdate() as CurrentDate, curtime() as CurrentTime,B.STATE,B.COUNTRY,B.LGA, A.* ";
          loginSQL = loginSQL + "  from "+TYPE_OF_ACTOR+" A,  COUNTRY B ";

          loginSQL = loginSQL + "  WHERE ";
          loginSQL = loginSQL + "  A.COUNTRY_ID = B.COUNTRY_ID ";
          loginSQL = loginSQL + "  AND  A.STATE_ID = B.STATE_ID ";
          loginSQL = loginSQL + "  AND A.LGA_ID = B.LGA_ID ";
          loginSQL = loginSQL + "  AND   trim(A.MOBILENUMBER) = '"+MOBILENUMBER.trim()+"'    ";
		break;
      case "LPO_INVESTOR":   
    	  loginSQL= "  SELECT Curdate() as CurrentDate, curtime() as CurrentTime,B.STATE,B.COUNTRY,B.LGA, A.* ";
          loginSQL = loginSQL + "  from "+TYPE_OF_ACTOR+" A,  COUNTRY B ";

          loginSQL = loginSQL + "  WHERE ";
          loginSQL = loginSQL + "  A.COUNTRY_ID = B.COUNTRY_ID ";
          loginSQL = loginSQL + "  AND  A.STATE_ID = B.STATE_ID ";
          loginSQL = loginSQL + "  AND A.LGA_ID = B.LGA_ID ";
          loginSQL = loginSQL + "  AND   trim(A.MOBILENUMBER) = '"+MOBILENUMBER.trim()+"'    ";
		break;
               
      case "LPO_INVESTOR_COY":   
    	  loginSQL= "  SELECT Curdate() as CurrentDate, curtime() as CurrentTime,B.STATE,B.COUNTRY,B.LGA, A.* ";
          loginSQL = loginSQL + "  from "+TYPE_OF_ACTOR+" A,  COUNTRY B ";
          loginSQL = loginSQL + "  WHERE ";
          loginSQL = loginSQL + "  A.COUNTRY_ID = B.COUNTRY_ID ";
          loginSQL = loginSQL + "  AND  A.STATE_ID = B.STATE_ID ";
          loginSQL = loginSQL + "  AND A.LGA_ID = B.LGA_ID ";
          loginSQL = loginSQL + "  AND   trim(A.MOBILENUMBER) = '"+MOBILENUMBER.trim()+"'    ";
		break;
		
      case "LPO_SUPPLIER_COY":   
    	  loginSQL= "   SELECT Curdate() as CurrentDate, curtime() as CurrentTime,B.STATE,B.COUNTRY,B.LGA, A.* ";
          loginSQL = loginSQL + "  from "+TYPE_OF_ACTOR+" A,  COUNTRY B ";

          loginSQL = loginSQL + "  WHERE ";
          loginSQL = loginSQL + "  A.COUNTRY_ID = B.COUNTRY_ID ";
          loginSQL = loginSQL + "  AND  A.STATE_ID = B.STATE_ID ";
          loginSQL = loginSQL + "  AND A.LGA_ID = B.LGA_ID ";
          loginSQL = loginSQL + "  AND   trim(A.MOBILENUMBER) = '"+MOBILENUMBER.trim()+"'    ";
		break;
      
    
  }
	 

      
      
      System.out.println(loginSQL);
    
      
      result = new JSONObject();
      data = stmt.executeQuery(loginSQL);
      ResultSetToArrayList rrResultSetToArrayList = new ResultSetToArrayList();
       kk = (ArrayList)rrResultSetToArrayList.ResultSetToArrayList(data);
      
       arrColumnNames = (ArrayList) rrResultSetToArrayList.ColumnNames(data);
      if(kk.size() >= 1)
      {
      ArrayList rowAl = (ArrayList)kk.get(0);
  
      //populate the record into the json objects
      for (int int_Column =0;int_Column<arrColumnNames.size(); int_Column++  )
      {
    
    	  String strColumnName = arrColumnNames.get(int_Column).toString().toUpperCase();
    	  result.put(strColumnName, rowAl.get(int_Column).toString());
      }

      System.out.println(result.get("LOGINCOUNT").toString());
      
      if (Integer.parseInt(result.get("LOGINCOUNT").toString())<10)
      {
    	 
    	     System.out.println("<<<<LoGINCOUNT IS LESS 10>>>>>>");
    	  String vpass=  result.get("PASSWORD").toString().trim();
    	  String vstatus=  result.get("STATUS").toString().trim().toUpperCase();
    	  System.out.println("PASSWORD VALUE++++++++===========" + vpass);
    	  if (vpass.equalsIgnoreCase(xPASSWORD.trim()))
    	  {
    		  
    		// switch statement 
    		  switch(vstatus)
    		  {
    		  
    		     case "A" :
    		      result.put("errorcode", "0");
       		      result.put("errordescription", "Successfully Logon !!!");
    		        break; 
    		     
    		     case "I"  :
    		    	//romove the  record from the result JSON object whe the authentication fails
       		      
       			  result.put("errorcode", "1");
       		      result.put("errordescription", "Successfully Logon But You are Yet to Validate  your Profile!!!");
       	
    		        break; 
    		    
    		     default : 
    		    	//romove the  record from the result JSON object whe the authentication fails
       		      for (int int_Column =0;int_Column<arrColumnNames.size(); int_Column++  )
       		      {
       		    	  String strColumnName = arrColumnNames.get(int_Column).toString().toUpperCase();
       		    	  result.remove(strColumnName);
       		      }
       			  result.put("errorcode", "-9");
       		      result.put("errordescription", "UNKNOWN STATUS!!!");
    		  }
    		  
    		  
    		  
    		  
      System.out.println("Pasword compare successful");

    //remove the password from the payload
      result.remove("PASSWORD");
      result.remove("CONFIRMPASSWORD");
      boolean bb = stmt.execute((new StringBuilder()).append("UPDATE "+TYPE_OF_ACTOR+" set LOGINCOUNT = 0  where  MOBILENUMBER='").append(MOBILENUMBER.trim()).append("'  ").toString());
    	  }else
    	  {
    		  //romove the  record from the result JSON object whe the authentication fails
    	      for (int int_Column =0;int_Column<arrColumnNames.size(); int_Column++  )
    	      {
    	    	  String strColumnName = arrColumnNames.get(int_Column).toString().toUpperCase();
    	    	  result.remove(strColumnName);
    	      }
    	
    	      result.put("errorcode", "-1");
    	      result.put("errordescription", " login failed WRONG PASSWORD!!!!");
    	      boolean bb = stmt.execute((new StringBuilder()).append("UPDATE "+TYPE_OF_ACTOR+"  set LOGINCOUNT = LOGINCOUNT +1   where  MOBILENUMBER='").append(MOBILENUMBER.trim()).append("'  ").toString());
    	    	  
    	  }
      }else
      {
    	//romove the  record from the result JSON object whe the authentication fails
	      for (int int_Column =0;int_Column<arrColumnNames.size(); int_Column++  )
	      {
	    	  String strColumnName = arrColumnNames.get(int_Column).toString().toUpperCase();
	    	  result.remove(strColumnName);
	      }
    	  result.put("errorcode", "-4");
          result.put("errordescription", "10 unsuccessful login count. Account is blocked!!!! Contact the administrator!!!!"); 
          boolean bb = stmt.execute((new StringBuilder()).append("UPDATE "+TYPE_OF_ACTOR+"  set LOGINCOUNT = LOGINCOUNT +1  where  MOBILENUMBER='").append(MOBILENUMBER.trim()).append("'  ").toString());
          
      }
      
       

    
      data.close();
      stmt.close();
      conn.close();
      //return response;
      }else{
      
      result.put("errordescription", "Login Failed");
      boolean bb = stmt.execute((new StringBuilder()).append("UPDATE "+TYPE_OF_ACTOR+"  set LOGINCOUNT = LOGINCOUNT +1  where  trim(MOBILENUMBER)='").append(MOBILENUMBER.trim()).append("'  ").toString());
 
      data.close();
      stmt.close();
      conn.close();
      //return response;
      }
      }catch(Exception exception)
     {

    System.out.println("Table  "+TYPE_OF_ACTOR+"   error in method :::EthSol_LoginWithMobileNumber:::" + exception.getMessage());
      try {
		if (data!= null) data.close();
		if (stmt!= null) stmt.close();
	
	   
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
  }
	


      response.getWriter().println(result);
	    }
}