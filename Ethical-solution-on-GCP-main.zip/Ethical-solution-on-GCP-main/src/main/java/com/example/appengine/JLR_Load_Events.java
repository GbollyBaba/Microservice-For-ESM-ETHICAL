
package com.example.appengine;


//https://towardsdatascience.com/6-lesser-known-sql-techniques-to-save-you-100-hours-a-month-10ceed47d3fe
//07404851234 TNT
//https://cprosenjit.medium.com/10-time-series-forecasting-methods-we-should-know-291037d2e285


//gbolade@sallysoftinternational.com
//fe7z(QPQ3eY.c4g

//GCP password  ethicalsoft10*
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;


import com.api.json.JSONArray;
import com.api.json.JSONObject;

import com.example.util.*;


@WebServlet(name = "JLR_Load_Events", value = "/JLR_Load_Events")
public class JLR_Load_Events extends HttpServlet {
	
	/**
	 * 
	 Ise Aje La Nwalo 
	 * 
	NKEY=AAS%$^BD4645~~HDXadsssa
	 */
	private static final long serialVersionUID = 1L;
	// Define logger (Standard java.util.Logger)
	static Logger logger = Logger.getLogger(JLR_Load_Events.class.getName());
	


  @SuppressWarnings("rawtypes")
@Override
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");


	  JSONObject result =null;
	    JSONArray results = null;
	    
	  
	  
	    PreparedStatement getAllUsers =null;
	    Connection con=null;
	      Statement stmt=null;
	      ResultSet data=null;
	
	
	    String TYPE_OF_EVENT =request.getParameter("TYPE_OF_EVENT");
	  	String NKEY = request.getParameter("NKEY").trim();
	  	String CHANNEL = request.getParameter("CHANNEL");
	  	
	  	if ( NKEY.toUpperCase().equalsIgnoreCase("AAS%$^BD4645~~HDXaADAAAAA".toUpperCase()))
	  	{
	  	 
	  	  
	  	
	  	
  	     String loginSQL="";
  	   ArrayList kk =null;
       
       ArrayList arrColumnNames = null;
	  try (Connection conn = pool.getConnection()) {
      stmt = conn.createStatement();
      
      switch (TYPE_OF_EVENT) {
      
      case "ALL":   
    	  
         

		break;
		
      case "AUTO":   
    	  loginSQL= " select  * from  AUTO   ";
    	  break;   
		
    	  
    
      
    
  }
	 

      
      
      System.out.println(loginSQL);
    
      
     
      results = new JSONArray();
   
      data = stmt.executeQuery(loginSQL);
      ResultSetToArrayList rrResultSetToArrayList = new ResultSetToArrayList();
       kk = (ArrayList) rrResultSetToArrayList.ResultSetToArrayList(data);
       int sizeoftable =kk.size();
      
       arrColumnNames = (ArrayList) rrResultSetToArrayList.ColumnNames(data);
       int sizeofcolumnslist =arrColumnNames.size();
       if (sizeoftable>0)
       {
       for (int k=0 ; k <sizeoftable ; k++)
       {
      
    	   result = new JSONObject();
  System.out.println(kk.get(k).toString());
      ArrayList rowAl = (ArrayList) kk.get(k);
      //populate the record into the json objects
      for (int int_Column =0;int_Column<sizeofcolumnslist; int_Column++  )
      {
    
    	  String strColumnName = arrColumnNames.get(int_Column).toString().toUpperCase();
    	  result.put(strColumnName, rowAl.get(int_Column).toString());
      }
      //System.out.println(result.toString());
      results.add(result);

      }
       }
      data.close();
      stmt.close();
      conn.close();
      //return response;
           }catch(Exception exception)
     {

    System.out.println("Table  "+TYPE_OF_EVENT+"   error in method :::JLR_Load_Events:::" + exception.getMessage());
      try {
    	  
    	  exception.printStackTrace();
		if (data!= null) data.close();
		if (stmt!= null) stmt.close();
	
	   
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
     
  }
	
   response.getWriter().println(results);
	  	}else
	  	  {
	  		  JSONObject result1 =new JSONObject();
	  		    JSONArray results1 = new JSONArray();
	  		  result1.put("Error", "INVALID KEY");
	  		  results1.add(result);
	  		  response.getWriter().println(results1);
	  		  return;
	  	  }
  
	    }
}