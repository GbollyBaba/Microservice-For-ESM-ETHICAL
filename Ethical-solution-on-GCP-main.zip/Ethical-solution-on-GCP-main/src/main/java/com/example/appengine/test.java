package com.example.appengine;

import com.api.json.JSONObject;
import com.example.util.JWTGenerateValidateHMAC;

public class test {

	public test() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String NKEY = "HQ-TECH-L472 192.168.100.7 ReyJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiTFBPX0JPUlJPV0VSIiwiZW1haWwiOiJnYm9sYWRlc2hhZGFAZ21haWwuY29tIiwic3ViIjoiRVRISUNBTF9TT0xVVElPTl9MVEQiLCJqdGkiOiJhNmJlZmQ1NS04MzIyLTRhYzEtYjQ5ZS00MDM4OWNjZTE1NGEiLCJpYXQiOjE2NjM0NDMyNjgsImV4cCI6MTY2MzQ0Mzg2OH0.BBcX3Kl5HYhenXzVcesxEg5f9j1T-k-7frssxkKpQpI";
		JSONObject resultsVAlidate = new JSONObject();
		String [] nkeyValues  = NKEY.split(" ");
		
		System.out.println(nkeyValues.length);
		if (nkeyValues.length == 3)
		{
		String NACHINE_NAME_VALUE = nkeyValues[0];
		String NACHINE_IPADDRESS_VALUE = nkeyValues[1];
		String NKEY_VALUE = nkeyValues[2];
		JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
		String res = gg.ValidateToken(NKEY_VALUE);
		System.out.println(" ValidateToken :"+res);

		if (!res.equalsIgnoreCase("Y"))
		{
			System.out.println("22222"+nkeyValues.length);
		return;
		}
		}else
		{
			System.out.println("AAAAAAA"+nkeyValues.length);
		return;
		}
		
	}

}
