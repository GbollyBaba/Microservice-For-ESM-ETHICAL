
package com.example.appengine;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.logging.Logger;
/*
 * 
  account name - oa_adelaja@hotmail.com

	  password - ethicalsoft10*
  
 * 
 */
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringEscapeUtils;

import com.api.json.JSONObject;
import com.example.util.*;
import com.example.util.JWTGenerateValidateHMAC;
import com.mysql.cj.jdbc.CallableStatement;
@SuppressWarnings("deprecation")

@WebServlet(
	    name = "ESM_Payment_Type",
	    urlPatterns = {"/ESM_Payment_Type"}
	)

public class ESM_Payment_Type extends HttpServlet {

/**
 *
 * 
  mvn clean package appengine:deploy
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(ESM_Payment_Type.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");

	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");


	  String ESM_COMPANY_ID= request.getParameter("ESM_COMPANY_ID");
	  String ESM_PAYMENTS_TYPE_CODE =request.getParameter("ESM_PAYMENTS_TYPE_CODE");
	  String ESM_PAYMENTS_TYPE_NAME=  request.getParameter("ESM_PAYMENTS_TYPE_NAME");
	 
	  String ESM_PAYMENTS_TYPE_DESC= request.getParameter("ESM_PAYMENTS_TYPE_DESC");
	  String ESM_PAYMENT_FREQUENCY =request.getParameter("ESM_PAYMENT_FREQUENCY");
	  String ESM_PAYMENTS_TYPE_DESTINATION =  request.getParameter("ESM_PAYMENTS_TYPE_DESTINATION");
	  String ESM_PAYMENTS_TYPE_COST =  request.getParameter("ESM_PAYMENTS_COST");
	  String STATUS =  request.getParameter("STATUS");
	  String ESM_PAYMENTS_COST =  request.getParameter("ESM_PAYMENTS_COST");
		
	  
	  
	  String NKEY=	request.getParameter("NKEY").trim()  ;
	  String CHANNEL=	request.getParameter("CHANNEL")  ;
	  
	  String ACTION=	request.getParameter("ACTION")  ;//CREATE/ UPDATE
	  
	
	  	
////////////////////////////////////////SECURITY CHECK///////////////////////////////////////////////////////////////////////////////
JSONObject resultsVAlidate = new JSONObject();
String [] nkeyValues  = NKEY.split(" ");
if (nkeyValues.length == 5)
{
//EMAIL TYPEOFACTOR HQTECH IPADDRESS NKEY

String EMAIL = nkeyValues[0];
String TYPEOFACTOR = nkeyValues[1];
String MACHINE_NAME_VALUE = nkeyValues[2];
String MACHINE_IPADDRESS_VALUE = nkeyValues[3];
String NKEY_VALUE = nkeyValues[4];
JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
String res = gg.ValidateToken(NKEY_VALUE);
System.out.println("**********************SECURITY CHECK WITH OUATH2 & WEB TOKEN******************************* ");
System.out.println(" EMAIL :"+EMAIL);
System.out.println(" TYPEOFACTOR :"+TYPEOFACTOR);
System.out.println(" MACHINE_NAME_VALUE :"+MACHINE_NAME_VALUE);
System.out.println(" MACHINE_IPADDRESS_VALUE :"+MACHINE_IPADDRESS_VALUE);
System.out.println(" NKEY_VALUE :"+NKEY_VALUE);
System.out.println("************************************************************************************* ");


System.out.println(" ValidateToken :"+res);

if (!res.equalsIgnoreCase("Y"))
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}
}else
{
resultsVAlidate.put("errorcode", "-3000");
resultsVAlidate.put("errordescription",  "Incomplete paramets passed...");
response.getWriter().println(resultsVAlidate);
return;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	  String ROWSUPDATED="-1";
	  

	 
System.out.println("****************************************************************************");
System.out.println(" ESM_COMPANY_ID:"+ESM_COMPANY_ID);
System.out.println(" ESM_PAYMENTS_TYPE_CODE :"+ESM_PAYMENTS_TYPE_CODE);
System.out.println(" WHO_MOVED_RECORD:"+ESM_PAYMENTS_TYPE_NAME);

System.out.println(" ESM_PAYMENTS_TYPE_DESC :"+ESM_PAYMENTS_TYPE_DESC);
System.out.println(" ESM_PAYMENT_FREQUENCY:"+ESM_PAYMENT_FREQUENCY);
System.out.println(" ESM_PAYMENTS_TYPE_DESTINATION :"+ESM_PAYMENTS_TYPE_DESTINATION);
System.out.println(" ESM_PAYMENTS_COST :"+ESM_PAYMENTS_COST);
System.out.println(" STATUS:"+STATUS);
System.out.println(" ACTION:"+ACTION);//

System.out.println("****************************************************************************");
	  Statement stmt=null;
	  java.sql.CallableStatement cs = null;
	  JSONObject results = new JSONObject();
	  int numROWUPDATED =-1;
	  
	   
	  ArrayList kk =null;
	  String Token;
	 
	  if (pool!= null)
	  {
	  try (Connection con = pool.getConnection()) 
	  {
		   
		   System.out.println("<<<<<<<< CREATE CONNECTION  SUCCESSFULLY>>>>>>>>>>>>>");	
	  stmt = null;	 
	  
	
		  try{
  String StoredProcedure = "{ call ESM_SP_PAYMENT_TYPE(?,?,?,?,?,?,?,?,?,?) }";
	 
 cs = con.prepareCall(StoredProcedure);
 
 /*
  * 
IN vESM_COMPANY_ID int  ,
IN vESM_PAYMENTS_TYPE_CODE VARCHAR(25),
IN vESM_PAYMENTS_TYPE_NAME VARCHAR(25),
IN vESM_PAYMENTS_TYPE_DESC VARCHAR(50),
IN vESM_PAYMENT_FREQUENCY VARCHAR(25),
IN vESM_PAYMENTS_TYPE_DESTINATION VARCHAR(25),
IN vSTATUS char(1) ,
OUT vROWSINSERTED int
  * 
  */
 
 System.out.println(" ESM_COMPANY_ID:"+ESM_COMPANY_ID);
 System.out.println(" ESM_PAYMENTS_TYPE_CODE :"+ESM_PAYMENTS_TYPE_CODE);
 System.out.println(" ESM_PAYMENTS_TYPE_NAME:"+ESM_PAYMENTS_TYPE_NAME);
	
	cs.setInt(1, Integer.parseInt(ESM_COMPANY_ID));
	cs.setString(2, ESM_PAYMENTS_TYPE_CODE);
	cs.setString(3, ESM_PAYMENTS_TYPE_NAME);
	cs.setString(4, ESM_PAYMENTS_TYPE_DESC);
	cs.setString(5, ESM_PAYMENT_FREQUENCY);
	cs.setString(6, ESM_PAYMENTS_TYPE_DESTINATION);
	cs.setString(7, STATUS);
	cs.setString(8, ACTION);
	cs.setDouble(9, Double.parseDouble(ESM_PAYMENTS_COST));
	
	
	
	
	cs.registerOutParameter(10, Integer.parseInt(ROWSUPDATED));
	
	cs.execute();

	numROWUPDATED=cs.getInt(10);

	          if (numROWUPDATED==1)
	          {
    		  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "0");
		      dbresult.put("errordescription",  "  ESM_PAYMENTS_TYPE  SUCCESSFULLY CREATED FOR this ESM_COMPANY:::"+ ESM_COMPANY_ID);
		      results.put("ERROR", dbresult);
		      results.put("ROWSINSERTED", String.valueOf(numROWUPDATED));
		      results.put("ESM_COMPANY_ID", ESM_COMPANY_ID);
		      results.put("ESM_PAYMENTS_TYPE_CODE", ESM_PAYMENTS_TYPE_CODE);
		      results.put("ESM_PAYMENTS_TYPE_NAME", ESM_PAYMENTS_TYPE_NAME);
		      results.put("ESM_PAYMENTS_TYPE_DESC", ESM_PAYMENTS_TYPE_DESC);
		      results.put("ESM_PAYMENT_FREQUENCY", ESM_PAYMENT_FREQUENCY);
		      results.put("ESM_PAYMENTS_TYPE_DESTINATION", ESM_PAYMENTS_TYPE_DESTINATION);
		      results.put("STATUS", STATUS);
		      results.put("ACTION", ACTION);
		      results.put("ESM_PAYMENTS_COST",ESM_PAYMENTS_COST);
			     
		      
	          }
	          if (numROWUPDATED != 1)
	          {
    		  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "1");
		      dbresult.put("errordescription",  "  ESM_PAYMENTS_TYPE COULD NOT  CREATED FOR this ESM_COMPANY:::"+ESM_COMPANY_ID+"! ");
		      results.put("ERROR", dbresult);
		      results.put("ROWSINSERTED", String.valueOf(numROWUPDATED));
		      results.put("ESM_COMPANY_ID", ESM_COMPANY_ID);
		      results.put("ESM_PAYMENTS_TYPE_CODE", ESM_PAYMENTS_TYPE_CODE);
		      results.put("ESM_PAYMENTS_TYPE_NAME", ESM_PAYMENTS_TYPE_NAME);
		      results.put("ESM_PAYMENTS_TYPE_DESC", ESM_PAYMENTS_TYPE_DESC);
		      results.put("ESM_PAYMENT_FREQUENCY", ESM_PAYMENT_FREQUENCY);
		      results.put("ESM_PAYMENTS_TYPE_DESTINATION", ESM_PAYMENTS_TYPE_DESTINATION);
		      results.put("STATUS", STATUS);
		      results.put("ACTION", ACTION);
		      results.put("ESM_PAYMENTS_COST",ESM_PAYMENTS_COST);
	          }
		      
		      cs.close();
			  con.close();
	
		  } 
		  
		  catch(java.sql.SQLIntegrityConstraintViolationException sqlerror)
		  {
			  
			  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "-2");
		      dbresult.put("errordescription",  sqlerror.getMessage());
		      results.put("ERROR", dbresult);
		      results.put("ROWSINSERTED", String.valueOf(numROWUPDATED));
		      results.put("ESM_COMPANY_ID", ESM_COMPANY_ID);
		      results.put("ESM_PAYMENTS_TYPE_CODE", ESM_PAYMENTS_TYPE_CODE);
		      results.put("ESM_PAYMENTS_TYPE_NAME", ESM_PAYMENTS_TYPE_NAME);
		      results.put("ESM_PAYMENTS_TYPE_DESC", ESM_PAYMENTS_TYPE_DESC);
		      results.put("ESM_PAYMENT_FREQUENCY", ESM_PAYMENT_FREQUENCY);
		      results.put("ESM_PAYMENTS_TYPE_DESTINATION", ESM_PAYMENTS_TYPE_DESTINATION);
		      results.put("STATUS", STATUS);
		      results.put("ACTION", ACTION);
		      results.put("ESM_PAYMENTS_COST",ESM_PAYMENTS_COST);
			  cs.close();
			  con.close();
			  sqlerror.printStackTrace();  
			  
		  }
		  catch (Exception eee)
		  	{
			  
			  
			  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "-2");
		      dbresult.put("errordescription",  eee.getMessage());
		      results.put("ERROR", dbresult);
		      results.put("ROWSINSERTED", String.valueOf(numROWUPDATED));
		      results.put("ESM_COMPANY_ID", ESM_COMPANY_ID);
		      results.put("ESM_PAYMENTS_TYPE_CODE", ESM_PAYMENTS_TYPE_CODE);
		      results.put("ESM_PAYMENTS_TYPE_NAME", ESM_PAYMENTS_TYPE_NAME);
		      results.put("ESM_PAYMENTS_TYPE_DESC", ESM_PAYMENTS_TYPE_DESC);
		      results.put("ESM_PAYMENT_FREQUENCY", ESM_PAYMENT_FREQUENCY);
		      results.put("ESM_PAYMENTS_TYPE_DESTINATION", ESM_PAYMENTS_TYPE_DESTINATION);
		      results.put("STATUS", STATUS);
		      results.put("ACTION", ACTION);
		      results.put("ESM_PAYMENTS_COST",ESM_PAYMENTS_COST);
		
		    		  cs.close();
					  con.close();
			  eee.printStackTrace();
			
		  }
		  
		  
		  finally
		  {
		  
		
		}
	  
	

	  } catch (Exception ee)
{
		  JSONObject dbresult = new JSONObject();
	      dbresult.put("errorcode", "-2");
	      dbresult.put("errordescription",  ee.getMessage());
	      results.put("ERROR", dbresult);
	      results.put("ROWSINSERTED", String.valueOf(numROWUPDATED));
	      results.put("ESM_COMPANY_ID", ESM_COMPANY_ID);
	      results.put("ESM_PAYMENTS_TYPE_CODE", ESM_PAYMENTS_TYPE_CODE);
	      results.put("ESM_PAYMENTS_TYPE_NAME", ESM_PAYMENTS_TYPE_NAME);
	      results.put("ESM_PAYMENTS_TYPE_DESC", ESM_PAYMENTS_TYPE_DESC);
	      results.put("ESM_PAYMENT_FREQUENCY", ESM_PAYMENT_FREQUENCY);
	      results.put("ESM_PAYMENTS_TYPE_DESTINATION", ESM_PAYMENTS_TYPE_DESTINATION);
	      results.put("STATUS", STATUS);
	      results.put("ACTION", ACTION);
	      results.put("ESM_PAYMENTS_COST",ESM_PAYMENTS_COST);
	  ee.printStackTrace();
}
	  
	  
}

response.getWriter().println(results);
}

  




	  




}




