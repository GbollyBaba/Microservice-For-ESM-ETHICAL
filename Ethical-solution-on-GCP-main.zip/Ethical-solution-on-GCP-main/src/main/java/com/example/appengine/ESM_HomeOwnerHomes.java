
package com.example.appengine;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Logger;
/*
 * 
  account name - oa_adelaja@hotmail.com

	  password - ethicalsoft10*
  
 * 
 */
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringEscapeUtils;
import org.json.JSONArray;

import org.json.JSONObject;
import com.example.util.JWTGenerateValidateHMAC_esm;
import com.example.util.*;
@SuppressWarnings("deprecation")

@WebServlet(
	    name = "ESM_HomeOwnerHomes",
	    urlPatterns = {"/ESM_HomeOwnerHomes"}
	)

public class ESM_HomeOwnerHomes extends HttpServlet {

/**
 * 
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(ESM_HomeOwnerHomes.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");

	  String ESM_HOMEOWNER_ID=request.getParameter("ESM_HOMEOWNER_ID") ;
	  String HOME_NUMBER=request.getParameter("HOME_NUMBER") ;
	  String STREET1=request.getParameter("STREET1") ;  
	  String STREET2=request.getParameter("STREET2")  ;
	  String LGA_ID=request.getParameter("LGA_ID") ;
	  String STATE_ID=request.getParameter("STATE_ID") ;
	  String COUNTRY_ID=request.getParameter("COUNTRY_ID") ;
	  String STATUS=request.getParameter("STATUS") ;
	  String NKEY=	request.getParameter("NKEY").trim()  ;
	  String CHANNEL=	request.getParameter("CHANNEL")  ;
	  String APARTMENTS=	request.getParameter("APARTMENTS")  ;
	  
/*	  
	  	
////////////////////////////////////////SECURITY CHECK///////////////////////////////////////////////////////////////////////////////
JSONObject resultsVAlidate = new JSONObject();
String [] nkeyValues  = NKEY.split(" ");
if (nkeyValues.length == 5)
{
//EMAIL TYPEOFACTOR HQTECH IPADDRESS NKEY

String EMAIL = nkeyValues[0];
String TYPEOFACTOR = nkeyValues[1];
String MACHINE_NAME_VALUE = nkeyValues[2];
String MACHINE_IPADDRESS_VALUE = nkeyValues[3];
String NKEY_VALUE = nkeyValues[4];
JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
String res = gg.ValidateToken(NKEY_VALUE);
System.out.println("**********************SECURITY CHECK WITH OUATH2 & WEB TOKEN******************************* ");
System.out.println(" EMAIL :"+EMAIL);
System.out.println(" TYPEOFACTOR :"+TYPEOFACTOR);
System.out.println(" MACHINE_NAME_VALUE :"+MACHINE_NAME_VALUE);
System.out.println(" MACHINE_IPADDRESS_VALUE :"+MACHINE_IPADDRESS_VALUE);
System.out.println(" NKEY_VALUE :"+NKEY_VALUE);
System.out.println("************************************************************************************* ");


System.out.println(" ValidateToken :"+res);

if (!res.equalsIgnoreCase("Y"))
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}
}else
{
resultsVAlidate.put("errorcode", "-3000");
resultsVAlidate.put("errordescription",  "Incomplete paramets passed...");
response.getWriter().println(resultsVAlidate);
return;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

*/

JSONObject result =null;
System.out.println("****************************************************************************");
System.out.println(" STREET1  :" +STREET1) ;  
System.out.println(" STREET2  :" +STREET2) ;  
System.out.println(" LGA_ID  :" +LGA_ID) ;  
System.out.println(" STATE_ID  :" +STATE_ID) ;  
System.out.println(" COUNTRY_ID  :" +COUNTRY_ID) ;  
System.out.println(" STATUS  :" +STATUS) ;  
System.out.println(" CHANNEL  :" +CHANNEL) ;  
System.out.println(" NKEY  :" +NKEY) ;  
System.out.println("****************************************************************************");
	  Statement stmt=null;
	  String insertSQL="";
	  ResultSet data= null;
	  String Token;
	  String insertvALUESSQL;
	  
	  if (pool!= null)
	  {
	  try (Connection con = pool.getConnection()) 
	  {
	/*
	  ESM_HOME_ID mediumint NOT NULL AUTO_INCREMENT,
  ESM_HOMEOWNER_ID mediumint NOT NULL,
  TIME_CREATED timestamp NULL DEFAULT NULL,
  HOME_NUMBER char(20) NOT NULL,
  STREET1 char(50) DEFAULT NULL,
  STREET2 char(50) DEFAULT NULL,
  LGA_ID int DEFAULT NULL,
  STATE_ID int DEFAULT NULL,
  COUNTRY_ID int DEFAULT NULL,
  STATUS char(1) NOT NULL,
	 * 
	 ESM_HOME_APARTMENTS (
 ESM_HOME_APARTMENTS_ID mediumint NOT NULL AUTO_INCREMENT,
 ESM_HOME_ID mediumint NOT NULL,
 ESM_HOMEOWNER_ID mediumint NOT NULL,
 ESM_APARTMENT_ID mediumint NOT NULL,
 ESM_RENT_COST  DECIMAL(16,2) NOT NULL,
 TIME_CREATED timestamp NULL DEFAULT NULL,
 STATUS char(1) NOT NULL,
 PRIMARY KEY (ESM_HOME_APARTMENTS_ID)
) ;
	 * 	   
	 */
		   System.out.println("<<<<<<<< CREATE CONNECTION  SUCCESSFULLY>>>>>>>>>>>>>");	
	  stmt = null;	
	  java.sql.CallableStatement cs = null;	 

		  insertvALUESSQL = " VALUES (  CURTIME(), ";
		  insertSQL =  insertSQL + "INSERT INTO ESM_HOME (TIME_CREATED,ESM_HOMEOWNER_ID,HOME_NUMBER,STREET1,STREET2 ";
		  insertSQL =  insertSQL + "  	,LGA_ID,STATE_ID ,COUNTRY_ID, STATUS ) ";
		
		  
		
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(ESM_HOMEOWNER_ID.toUpperCase()).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(HOME_NUMBER.toUpperCase()).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(STREET1.toUpperCase().trim()).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(STREET2.toUpperCase().trim()).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(LGA_ID).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(STATE_ID).append("',").toString();
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(COUNTRY_ID).append("',").toString();
		  
		  
		  insertvALUESSQL = (new StringBuilder()).append(insertvALUESSQL).append("'").append(STATUS.toUpperCase()).append("'").toString();
		   insertvALUESSQL =insertvALUESSQL +    "   ) ";
		  
		
		  Boolean bbb = Boolean.valueOf(false);
		  System.out.println("********************************************************************************" +
				  	"***"
				  	);
		  System.out.println((new StringBuilder()).append(insertSQL).append(insertvALUESSQL).toString());
		
	
		  try{
			  stmt = con.createStatement();
			   bbb = Boolean.valueOf(stmt.execute(insertSQL+insertvALUESSQL));
			  System.out.println("HOMEOWNER SUCCESSFULLY  INSERTED*****");
			  
			  
			  ///get the ID of the user
			  String getID_SQL= "   SELECT A.ESM_HOME_ID ";
			  getID_SQL = getID_SQL + "  from ESM_HOME A";
			  getID_SQL = getID_SQL + "  WHERE ";
			  getID_SQL = getID_SQL + "  A.ESM_HOMEOWNER_ID = " +ESM_HOMEOWNER_ID+"    ";
			  getID_SQL = getID_SQL + "  AND A.HOME_NUMBER = '" +HOME_NUMBER.trim()+"'    ";
			  getID_SQL = getID_SQL + "  AND A.STREET1 = '" +STREET1.trim().toUpperCase()+"'    ";
			  getID_SQL = getID_SQL + "  AND A.STREET2 = '" +STREET2.trim().toUpperCase()+"'    ";
			  getID_SQL = getID_SQL + "  AND A.LGA_ID = '" +LGA_ID.trim()+"'    ";
			  getID_SQL = getID_SQL + "  AND A.STATE_ID = '" +STATE_ID.trim()+"'    ";
			  getID_SQL = getID_SQL + "  AND A.COUNTRY_ID = '" +COUNTRY_ID.trim()+"'    ";
			   data = stmt.executeQuery(getID_SQL);
		      ResultSetToArrayList rrResultSetToArrayList = new ResultSetToArrayList();
		      ArrayList  kk = (ArrayList )rrResultSetToArrayList.ResultSetToArrayList(data);
		      String ESM_HOME_ID  = "";
		      if(kk.size() >= 1)
		      {

		    
		      ArrayList rowAl = (ArrayList) kk.get(0);
		      ESM_HOME_ID=rowAl.get(0).toString();
		      rowAl=null;
		      }
		      kk=null;
			  
		      
		      
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		      JSONArray array = new JSONArray(APARTMENTS); 
		      for(int i=0; i < array.length(); i++)   
			  {  
			  JSONObject object = array.getJSONObject(i); 
		 
			
			  System.out.println(ESM_HOME_ID);  
			  System.out.println(object.get("ESM_HOMEOWNER_ID").toString()); 
			  System.out.println(object.get("ESM_APARTMENT_ID").toString());  
			  System.out.println(object.get("ESM_RENT_COST").toString());  
			  System.out.println(object.get("STATUS").toString());  

			  
			  
			  
			   ESM_HOMEOWNER_ID =object.get("ESM_HOMEOWNER_ID").toString(); 
			  String ESM_APARTMENT_ID =object.get("ESM_APARTMENT_ID").toString(); 
			  String ESM_RENT_COST =object.get("ESM_RENT_COST").toString(); 
			  String ESM_PAYMENT_FREQUENCY =object.get("ESM_PAYMENT_FREQUENCY").toString(); 
			  STATUS =object.get("STATUS").toString(); 
			  
			 
			  
			  
			  
			int ROWSUPDATED=0;
				  
			  try 
			  {
				//insert into lpo_items table
				String StoredProcedure_items = "{ call ESM_SP_HOMEOWNER_APARTMENTS(?,?,?,?,?,?,?) }";
				System.out.println(StoredProcedure_items); 
				//									   SP_CREATE_LPO_ORDER_v2_ITEMS
				cs = con.prepareCall(StoredProcedure_items); 
				cs.setInt(1, Integer.parseInt(ESM_HOME_ID));
				cs.setInt(2, Integer.parseInt(ESM_HOMEOWNER_ID));
				cs.setInt(3, Integer.parseInt(ESM_APARTMENT_ID));
				cs.setDouble(4, Double.parseDouble(ESM_RENT_COST));
				cs.setString(5, ESM_PAYMENT_FREQUENCY);
				cs.setString(6, STATUS);
				cs.registerOutParameter(7, ROWSUPDATED);
				cs.execute();
				 System.out.println("**********************************************************************");
				 System.out.println("Successfully Attached this Apartment Details");
				  System.out.println("**********************************************************************");
				 System.out.println("ESM_HOME_ID:"+ESM_HOME_ID);
				 System.out.println("ESM_HOMEOWNER_ID:"+ESM_HOMEOWNER_ID);
				 System.out.println("ESM_APARTMENT_ID:"+ESM_APARTMENT_ID);
				 System.out.println("ESM_RENT_COST:"+ESM_RENT_COST);
				 System.out.println("ESM_PAYMENT_FREQUENCY:"+ESM_PAYMENT_FREQUENCY);
				 System.out.println("STATUS:"+STATUS);
				  System.out.println("**********************************************************************");
				 
				 
				 
				  }catch(Exception eee)
				  {
					  System.out.println(object.toString());
					  System.out.println(eee.getMessage());				  
					  
				  }
			
			  } //end the FOR
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		      
		      
			  
			  
			  
			  
			  
			 
			   result = new JSONObject();
			  result.put("errorcode", "0");
			  result.put("ID", ESM_HOME_ID);
			  result.put("errordescription",  "[ESM_HOME  ]  Successful CREATION ");
			  stmt.close();
			  con.close();
	
		  } catch (Exception eee)
		  	{
			  eee.printStackTrace();
			  System.out.println("**********************************************************************");
			  System.out.println((new StringBuilder()).append(insertSQL).append(insertvALUESSQL).toString());
			  System.out.println("**********************************************************************");
			   result = new JSONObject();
			  result.put("errorcode", "-1");
			  result.put("errordescription", eee.getMessage() + "    " + insertSQL + insertvALUESSQL);
			  stmt.close();
			  con.close();
			
		  }finally
		  {
		  
		
		}
	  
	

	  } catch (Exception ee)
{
	   result = new JSONObject();
	  result.put("errorcode", "-9");
	  result.put("errordescription", ee.getMessage() + "    " + "COULD NOT ESTABLISH CONNECTION");	
	  ee.printStackTrace();
}
	  
	  
}

System.out.println(result); 

response.getWriter().println(result);
}

  




	  




}




