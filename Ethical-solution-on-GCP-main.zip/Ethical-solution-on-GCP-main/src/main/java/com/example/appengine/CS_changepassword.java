
package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONObject;
import com.example.util.RandomNumberGen;


@WebServlet(name = "CS_changepassword", value = "/CS_changepassword")
public class CS_changepassword extends HttpServlet {


/**
	 * 
	 */
	private static final long serialVersionUID = -2382897224111806963L;
static Logger logger = Logger.getLogger(CS_changepassword.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	 response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  
	  String EVWID =request.getParameter("EVWID");
	  String PASSWORD=request.getParameter("PASSWORD") ;
	  String CONFIRMPASSWORD = request.getParameter("CONFIRMPASSWORD") ;
	  String APPID=request.getParameter("APPID") ;
	  String NKEY=request.getParameter("NKEY").trim() ;  

	  
	  JSONObject result =null;
 

Connection con=null;
Statement stmt=null;
String updateSQL="";
String Token;
try { con = pool.getConnection();
stmt = null;
updateSQL = "";

RandomNumberGen rGen = new RandomNumberGen();
Token = String.valueOf(rGen.getRandomNumber());
updateSQL = (new StringBuilder()).append(updateSQL).append(" UPDATE TBL_USERS   SET   ").toString();
updateSQL = (new StringBuilder()).append(updateSQL).append("   PASSWORD = '").append(PASSWORD).append("',").toString();
updateSQL = (new StringBuilder()).append(updateSQL).append("   CONFIRMPASSWORD = '").append(CONFIRMPASSWORD).append("'").toString();
updateSQL = (new StringBuilder()).append(updateSQL).append("   WHERE  EVW_ID  = '").append(EVWID).append("' ").toString();
updateSQL = (new StringBuilder()).append(updateSQL).append("   AND  APP_ID  = '").append(APPID).append("' ").toString();


Boolean bbb = Boolean.valueOf(false);
System.out.println("********************************************************************************" +
"***"
);
System.out.println(updateSQL);
System.out.println("********************************************************************************" +
"***"
);

stmt = con.createStatement();
bbb = Boolean.valueOf(stmt.execute(updateSQL));
System.out.println("SUCCESSFULLULLY CHANGED PASSWORD*****");

 result = new JSONObject();
result.put("errorcode", "0");
result.put("errordescription", "Successful PASSWORD CHANGE ");
stmt.close();
con.close();

}catch(Exception eee)
{
	 result = new JSONObject();
	result.put("errorcode", "-1");
	result.put("errordescription", (new StringBuilder()).append("NOT CHANGE PASSWORD ").append(eee.getLocalizedMessage() + updateSQL).toString());
    eee.printStackTrace();
    
}finally{

try {
	stmt.close();
	con.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}
response.getWriter().println(result);

}
}

