

package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;
import com.example.util.*;

import org.apache.commons.lang3.*;

@WebServlet(name = "CS_modifyusers", value = "/CS_modifyusers")
public class CS_modifyusers extends HttpServlet {

/**
 * 
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(CS_modifyusers.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  

 Connection con=null;
  Statement stmt=null;
  String EVWID = request.getParameter("EVWID");
  String FIRSTNAME = request.getParameter("FIRSTNAME");
  String SURNAME = request.getParameter("SURNAME");
  String MOBILENUMBER = request.getParameter("MOBILENUMBER");
  String MACADDRESS = request.getParameter("MACADDRESS");
  String EMAILADDRESS = request.getParameter("EMAILADDRESS");
  String PASSWORD = request.getParameter("PASSWORD");
  String CONFIRMPASSWORD = request.getParameter("CONFIRMPASSWORD");
  String STATUS = request.getParameter("STATUS");
  String GRADUATION_YEAR = request.getParameter("CUSTOMER_CLASSIFICATION");
  String APPID = request.getParameter("APPID");
  String NKEY = request.getParameter("NKEY").trim();
  JSONObject result = null;

  String updateSQL;
  String Token;
  try { 
	  con = pool.getConnection();
  stmt = null;
  updateSQL = "";
  EMAILADDRESS = EMAILADDRESS.toLowerCase().trim();
  RandomNumberGen rGen = new RandomNumberGen();
  Token = String.valueOf(rGen.getRandomNumber());
  updateSQL = (new StringBuilder()).append(updateSQL).append(" UPDATE TBL_USERS   SET   ").toString();
  updateSQL = (new StringBuilder()).append(updateSQL).append("   FIRSTNAME = '").append(FIRSTNAME).append("',").toString();
  updateSQL = (new StringBuilder()).append(updateSQL).append("   SURNAME = '").append(SURNAME).append("',").toString();
  updateSQL = (new StringBuilder()).append(updateSQL).append("  MACADDRESS = '").append(MACADDRESS).append("',").toString();
  updateSQL = (new StringBuilder()).append(updateSQL).append("  EMAILADDRESS = '").append(EMAILADDRESS).append("',").toString();

  updateSQL = (new StringBuilder()).append(updateSQL).append("   STATUS = '"+STATUS+"' , ").toString();
  updateSQL = (new StringBuilder()).append(updateSQL).append("  CUSTOMER_CLASSIFICATION = '"+GRADUATION_YEAR+"' ").toString();
  updateSQL = (new StringBuilder()).append(updateSQL).append("   WHERE  EVW_ID  = '").append(EVWID).append("' ").toString();
  updateSQL = (new StringBuilder()).append(updateSQL).append("   AND  APP_ID  = '").append(APPID).append("' ").toString();
  
  
  Boolean bbb = Boolean.valueOf(false);
  System.out.println("********************************************************************************" +
"***"
);
  System.out.println(updateSQL);
  System.out.println("********************************************************************************" +
"***"
);

  try{
  stmt = con.createStatement();
   bbb = Boolean.valueOf(stmt.execute(updateSQL));
  System.out.println("SUCCESSFULLULLY UPDATED*****");
  //SendSMS ss = new SendSMS();
  //String ToMobileNo = MOBILENUMBER;
  //String FromMobileNo = "+2348120796782";
  //String strMessage = (new StringBuilder()).append(" PLEASE ENTER THE TOKEN NUMBER :  ").append(Token).append(" TO VALIDATE YOUR PROFILE.").toString();
  //String mesgID = ss.send(ToMobileNo, FromMobileNo, strMessage);
   result = new JSONObject();
  result.put("errorcode", "0");
  result.put("errordescription", "Successful PROFILE UPDATE ");
 

  }catch(Exception eee)
  {
 

  eee.printStackTrace();
   result = new JSONObject();
  result.put("errorcode", "-1");
  result.put("errordescription", (new StringBuilder()).append("NOT CREATED ").append(eee.getLocalizedMessage() + updateSQL).toString());
 
  if (stmt != null) stmt.close();
  if (con != null) con.close();
  }finally{
 if (stmt != null) stmt.close();
 if (con != null) con.close();

  }
}catch(Exception eee1)
  {
	eee1.printStackTrace();
	
  }
  ///output

  System.out.println(result);


  response.getWriter().println(result);

}

}

  

