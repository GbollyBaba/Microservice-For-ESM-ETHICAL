


package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;
import com.example.util.*;

import org.apache.commons.lang3.*;


@WebServlet(name = "ESM_ValidateProfile", value = "/ESM_ValidateProfile")

public class ESM_ValidateProfile extends HttpServlet {

private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(ESM_ValidateProfile.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  

 Connection con=null;
  Statement stmt=null;
  String TYPE_OF_ACTOR =request.getParameter("TYPE_OF_ACTOR");
  String ID=request.getParameter("ID") ;
  String TOKEN=request.getParameter("TOKEN") ;
  String CHANNEL=request.getParameter("CHANNEL") ;
  String NKEY=request.getParameter("NKEY").trim() ;  
  
  
	
////////////////////////////////////////SECURITY CHECK///////////////////////////////////////////////////////////////////////////////
JSONObject resultsVAlidate = new JSONObject();
String [] nkeyValues  = NKEY.split(" ");
if (nkeyValues.length == 5)
{
//EMAIL TYPEOFACTOR HQTECH IPADDRESS NKEY

String EMAIL = nkeyValues[0];
String TYPEOFACTOR = nkeyValues[1];
String MACHINE_NAME_VALUE = nkeyValues[2];
String MACHINE_IPADDRESS_VALUE = nkeyValues[3];
String NKEY_VALUE = nkeyValues[4];
JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
String res = gg.ValidateToken(NKEY_VALUE);
System.out.println("**********************SECURITY CHECK WITH OUATH2 & WEB TOKEN******************************* ");
System.out.println(" EMAIL :"+EMAIL);
System.out.println(" TYPEOFACTOR :"+TYPEOFACTOR);
System.out.println(" MACHINE_NAME_VALUE :"+MACHINE_NAME_VALUE);
System.out.println(" MACHINE_IPADDRESS_VALUE :"+MACHINE_IPADDRESS_VALUE);
System.out.println(" NKEY_VALUE :"+NKEY_VALUE);
System.out.println("************************************************************************************* ");


System.out.println(" ValidateToken :"+res);

if (!res.equalsIgnoreCase("Y"))
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}
}else
{
resultsVAlidate.put("errorcode", "-3000");
resultsVAlidate.put("errordescription",  "Incomplete paramets passed...");
response.getWriter().println(resultsVAlidate);
return;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  JSONObject result =null;
  String SQL = "";
  
 
  try { 
	  con = pool.getConnection();
	  stmt = con.createStatement();
	   SQL = "";
	  switch (TYPE_OF_ACTOR) {
      case "ESM_TENANT":  
    	  SQL = "UPDATE ESM_TENANT  SET STATUS ='A'  WHERE ESM_TENANT_ID  ="+ID+" AND TOKEN ='"+TOKEN.trim()+"'" ;
            break;
      case "ESM_COMPANY":   
    	  SQL = "UPDATE ESM_COMPANY  SET STATUS ='A'  WHERE ESM_COMPANY_ID  ="+ID+" AND TOKEN ='"+TOKEN.trim()+"'" ;
          break; 
         
               
      case "ESM_HOMEOWNER":   
    	  SQL = "UPDATE ESM_HOMEOWNER  SET STATUS ='A'  WHERE ESM_HOMEOWNER_ID  ="+ID+" AND TOKEN ='"+TOKEN.trim()+"'" ;
          break ;
          
      case "ESM_ESTATEOFFICER":   
    	  SQL = "UPDATE ESM_ESTATEOFFICER  SET STATUS ='A'  WHERE ESM_ESTATEOFFICER_ID  ="+ID+" AND TOKEN ='"+TOKEN.trim()+"'" ;
          break ;
     
      
      default: 
    	  SQL = "Invalid month";
               break;
  }
	 



 int intaffectedrows=0;

  stmt = con.createStatement();
 intaffectedrows = stmt.executeUpdate(SQL);
  System.out.println("SUCCESSFULLY VALIDATED THE PROFILE :::"+TYPE_OF_ACTOR+" *****  WITH ID :::" +ID);
  

   result = new JSONObject();
   if (intaffectedrows==1) {
  result.put("errorcode", "0");
  result.put("errordescription", "SUCCESSFULLY VALIDATED THE PROFILE :::"+TYPE_OF_ACTOR+" *****  WITH ID :::" +ID);
   }else
   {
	   result.put("errorcode", "1");
	   result.put("errordescription", "UPDATED MULTIPLE ROWS :::"+TYPE_OF_ACTOR+" *****  WITH ID :::" +ID); 
   }
  stmt.close();
  con.close();

  

  }
  catch (Exception eee)
  {

  eee.printStackTrace();
  System.out.println("**********************************************************************");
  System.out.println(SQL);
  System.out.println("**********************************************************************");
  

   result = new JSONObject();
  result.put("errorcode", "-1");
  result.put("errordescription", eee.getLocalizedMessage());

  try {
	  con.close();
	stmt.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


  }finally
  {
  try {
	stmt.close();
	  con.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


}
  System.out.println(""); 
  System.out.println(result);


  response.getWriter().println(result);
}



}