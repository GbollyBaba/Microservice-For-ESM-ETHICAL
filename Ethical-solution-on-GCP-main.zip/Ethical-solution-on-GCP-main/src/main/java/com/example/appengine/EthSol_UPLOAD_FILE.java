

package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;
import com.example.util.*;

import org.apache.commons.lang3.*;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;


@WebServlet(name = "EthSol_UPLOAD_FILE", value = "/EthSol_UPLOAD_FILE")

public class EthSol_UPLOAD_FILE extends HttpServlet {


private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(EthSol_Validate_Profile.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException{

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");

  //String projectId, String bucketName, String objectName, String filePath
  String PROJECTID =request.getParameter("PROJECTID");
  String BUCKETNAME=request.getParameter("BUCKETNAME") ;
  String OBJECTNAME=request.getParameter("OBJECTNAME") ;
  String FILEPATH=request.getParameter("FILEPATH") ;
  String CHANNEL=request.getParameter("CHANNEL") ;
  String NKEY=request.getParameter("NKEY").trim() ;  
  
  JSONObject result =null;

  //http://BUCKET_NAME.storage.googleapis.com/OBJECT_NAME
	//  You can also use:
  //http://BUCKET_NAME.storage.googleapis.com/OBJECT_NAME
	//  http://storage.googleapis.com/BUCKET_NAME/OBJECT_NAME
 

	    // The ID of your GCP project
	  // PROJECTID = "ethicalservices";

	    // The ID of your GCS bucket
	  //  BUCKETNAME = "ethicalservices.appspot.com";

	    // The ID of your GCS object
	  // OBJECTNAME = "LPO";

	    // The path to your file to upload
	 //  FILEPATH = "/Users/akingboladeshada/Downloads/DigitalJewels-DISEP_Training_04.pdf";

	    Storage storage = StorageOptions.newBuilder().setProjectId(PROJECTID).build().getService();
	    BlobId blobId = BlobId.of(BUCKETNAME, OBJECTNAME);
	    BlobInfo blobInfo = BlobInfo.newBuilder(blobId).build();
	    storage.create(blobInfo, Files.readAllBytes(Paths.get(FILEPATH)));

	    System.out.println(
	        "File " + FILEPATH + " uploaded to bucket " + BUCKETNAME + " as " + OBJECTNAME);

  response.getWriter().println(result);
}



}