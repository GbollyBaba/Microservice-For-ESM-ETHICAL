
package com.example.appengine;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.api.json.JSONArray;
import com.api.json.JSONObject;


@WebServlet(name = "GetCSMemberSearch_with_ChaptersName", value = "/getCSMemberSearch_with_ChaptersName")
public class GetCSMemberSearch_with_ChaptersName extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Define logger (Standard java.util.Logger)
	static Logger logger = Logger.getLogger(GetCSMemberSearch_with_ChaptersName.class.getName());


  @Override
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");


	  JSONObject result =null;
	    JSONArray results = null;
	  
String CHAPTER_NAME = request.getParameter("CHAPTER_NAME");
String NKEY = request.getParameter("NKEY").trim();
Connection con;
Statement stmt;
	    
try { 
	  con = pool.getConnection();
	        
	    
	      
	         String  sql = " ";
		 sql=sql +"      select A.EVW_ID,  A.MIDDLENAME  CHAPTER  ";
		 sql=sql +"      ,A.FIRSTNAME,A.SURNAME,A.MOBILENUMBER  ";
		 sql=sql +"      ,A.CUSTOMER_CLASSIFICATION GRADUATION_YEAR ";

		 sql=sql +"      from TBL_USERS  A ";
		 sql=sql +"      WHERE APP_ID='20' ";
	     sql=sql +"      AND A.MIDDLENAME like '%"+CHAPTER_NAME+"%' ";
		       
		       
		        System.out.println(sql);
	            PreparedStatement getAllUsers = con.prepareStatement(sql);
	            ResultSet data = getAllUsers.executeQuery();
	            results = new JSONArray();
	            JSONObject item;
	            for(; data.next(); results.add(item))
	            {
	                item = new JSONObject();
	                item.put("EVW_ID", data.getString("EVW_ID"));
	                item.put("CHAPTER", data.getString("CHAPTER"));
	                item.put("FIRSTNAME", data.getString("FIRSTNAME"));
	item.put("SURNAME", data.getString("SURNAME"));
	item.put("MOBILENUMBER", data.getString("MOBILENUMBER"));
	item.put("GRADUATION_YEAR", data.getString("GRADUATION_YEAR"));

	          }

	            getAllUsers.close();
	            con.close();
	        }
	        catch(SQLException e)
	        {
	            results = new JSONArray();
	            JSONObject item = new JSONObject();
	             item = new JSONObject();
	                item.put("EVW_ID", "");
	                item.put("CHAPTER", "");
	                item.put("FIRSTNAME", "");
	item.put("SURNAME", "");
	item.put("MOBILENUMBER", "");
	item.put("GRADUATION_YEAR", "");
	            results.add(item);
	            e.printStackTrace();
	        }
	        JSONObject resultsObj = new JSONObject(); 
	        resultsObj.put("MEMBERS_SEARCH_RESULT", results);

	        System.out.println(resultsObj);


	        response.getWriter().println(resultsObj);
	    
	    }
  }

 
