

package com.example.appengine;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
/*
 * 
  account name - oa_adelaja@hotmail.com

	  password - ethicalsoft10*
  
 * 
 */
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringEscapeUtils;

import com.api.json.JSONObject;
import com.example.util.*;
import com.mysql.cj.jdbc.CallableStatement;
import com.example.util.AccessCipher;
import com.example.util.JWTGenerateValidateHMAC;
@SuppressWarnings("deprecation")

@WebServlet(
	    name = "EthSol_GENERATETOKEN",
	    urlPatterns = {"/EthSol_GENERATETOKEN"}
	)

public class EthSol_GENERATETOKEN extends HttpServlet {

/**
 *
 * 
  mvn clean package appengine:deploy
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(EthSol_Create_LPO_ORDER.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");
	  
	  
	  Map<String, String> map = new HashMap<String, String>();

		Enumeration headerNames = request.getHeaderNames();
		logger.info(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");

		while (headerNames.hasMoreElements()) {
			String key = (String) headerNames.nextElement();
			String value = request.getHeader(key);
			map.put(key, value);
			System.out.println(key+" : "+ value);

		}
		logger.info(":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
		
		////logger.info("HHEADER INFORMANTION::::::::"+ map.toString());

	  
	  
		JWTGenerateValidateHMAC zz = new JWTGenerateValidateHMAC();
	  


	  String ACTOR= request.getParameter("ACTOR");
	  String EMAIL= request.getParameter("EMAIL");
	  String NKEY=	request.getParameter("NKEY").trim()  ;
	  String CHANNEL=	request.getParameter("CHANNEL")  ;
	  
////////////////////////////////////////SECURITY CHECK///////////////////////////////////////////////////////////////////////////////
JSONObject resultsVAlidate = new JSONObject();
String [] nkeyValues  = NKEY.split(" ");
if (nkeyValues.length == 3)
{
String NACHINE_NAME_VALUE = nkeyValues[0];
String NACHINE_IPADDRESS_VALUE = nkeyValues[1];
String NKEY_VALUE = nkeyValues[2];
JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
String res = gg.ValidateToken(NKEY_VALUE);
System.out.println(" ValidateToken :"+res);

if (!res.equalsIgnoreCase("Y"))
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}
}else
{
resultsVAlidate.put("errorcode", "-3000");
resultsVAlidate.put("errordescription",  "Incomplete paramets passed...");
response.getWriter().println(resultsVAlidate);
return;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	  String jtoken  = zz.createJwtSignedHMAC(ACTOR, EMAIL,ACTOR+"~~"+EMAIL );
	  

	 JSONObject Result = new JSONObject();
	 Result.put("XXX",jtoken);

	 

	
	 
	  

	  response.getWriter().println(Result);

}
}




