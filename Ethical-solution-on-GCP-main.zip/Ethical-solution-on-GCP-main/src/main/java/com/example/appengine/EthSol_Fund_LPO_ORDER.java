

package com.example.appengine;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.logging.Logger;
/*
 * 
  account name - oa_adelaja@hotmail.com

	  password - ethicalsoft10*
  
 * 
 */
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringEscapeUtils;

import com.api.json.JSONObject;
import com.example.util.*;
import com.mysql.cj.jdbc.CallableStatement;
@SuppressWarnings("deprecation")

@WebServlet(
	    name = "EthSol_Fund_LPO_ORDER",
	    urlPatterns = {"/EthSol_Fund_LPO_ORDER"}
	)

public class EthSol_Fund_LPO_ORDER extends HttpServlet {

/**
 *
 * 
  mvn clean package appengine:deploy
 */
private static final long serialVersionUID = 1L;
// Define logger (Standard java.util.Logger)
static Logger logger = Logger.getLogger(EthSol_Create_LPO_ORDER.class.getName());


@SuppressWarnings("deprecation")
@Override
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {

	  response.setContentType("application/json");
	  response.setCharacterEncoding("UTF-8");

	  DataSource pool = (DataSource) request.getServletContext().getAttribute("my-pool");
	  
	  
	  /*
	   * 
	   * 

	   * 
	   * 
	   */

	  String LPO_INVESTOR_ID= request.getParameter("LPO_INVESTOR_ID");
	  String LPO_NUMBER =request.getParameter("LPO_NUMBER");
	  String AMOUNT=  request.getParameter("AMOUNT");
	  String STATUS =request.getParameter("STATUS");
	  String REMARKS=  request.getParameter("REMARKS");
	
	  
	  
	  String NKEY=	request.getParameter("NKEY").trim()  ;
	  String CHANNEL=	request.getParameter("CHANNEL")  ;
	  
	  
	  	
////////////////////////////////////////SECURITY CHECK///////////////////////////////////////////////////////////////////////////////
JSONObject resultsVAlidate = new JSONObject();
String [] nkeyValues  = NKEY.split(" ");
if (nkeyValues.length == 5)
{
//EMAIL TYPEOFACTOR HQTECH IPADDRESS NKEY

String EMAIL = nkeyValues[0];
String TYPEOFACTOR = nkeyValues[1];
String MACHINE_NAME_VALUE = nkeyValues[2];
String MACHINE_IPADDRESS_VALUE = nkeyValues[3];
String NKEY_VALUE = nkeyValues[4];
JWTGenerateValidateHMAC gg = new JWTGenerateValidateHMAC();
String res = gg.ValidateToken(NKEY_VALUE);
System.out.println("**********************SECURITY CHECK WITH OUATH2 & WEB TOKEN******************************* ");
System.out.println(" EMAIL :"+EMAIL);
System.out.println(" TYPEOFACTOR :"+TYPEOFACTOR);
System.out.println(" MACHINE_NAME_VALUE :"+MACHINE_NAME_VALUE);
System.out.println(" MACHINE_IPADDRESS_VALUE :"+MACHINE_IPADDRESS_VALUE);
System.out.println(" NKEY_VALUE :"+NKEY_VALUE);
System.out.println("************************************************************************************* ");


System.out.println(" ValidateToken :"+res);

if (!res.equalsIgnoreCase("Y"))
{
resultsVAlidate.put("errorcode", "-2000");
resultsVAlidate.put("errordescription",  "Invalid Token please login again");
response.getWriter().println(resultsVAlidate);
return;
}
}else
{
resultsVAlidate.put("errorcode", "-3000");
resultsVAlidate.put("errordescription",  "Incomplete paramets passed...");
response.getWriter().println(resultsVAlidate);
return;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	  String ROWSUPDATED="-1";
	  
	  
		String vELIGIBLE ="N";  
		double  vINVESTMENT_NEEDED=0.00;
		double vINVESTED_FUND_SOFAR=0.00;
	 
	 
System.out.println("****************************************************************************");
System.out.println(" LPO_INVESTOR_ID:"+LPO_INVESTOR_ID);
System.out.println(" LPO_NUMBER :"+LPO_NUMBER);
System.out.println(" AMOUNT:"+AMOUNT);
System.out.println(" STATUS :"+STATUS);
System.out.println(" REMARKS :"+REMARKS);
System.out.println("****************************************************************************");
	  Statement stmt=null;
	  java.sql.CallableStatement cs = null;
	  JSONObject results = new JSONObject();
	  int numInvestor =-1;
	  
	   
	  ArrayList kk =null;
	  String Token;
	 
	  if (pool!= null)
	  {
	  try (Connection con = pool.getConnection()) 
	  {
		   
		   System.out.println("<<<<<<<< CREATE CONNECTION  SUCCESSFULLY>>>>>>>>>>>>>");	
	  stmt = null;	 
	  
	
		  try{
  String StoredProcedure = "{ call SP_FUND_LPO_ORDER(?,?,?,?,?,?,?,?,?) }";
	 
 cs = con.prepareCall(StoredProcedure);
 
 /*
  * 
  OUT vROWSINSERTED int,
OUT vELIGIBLE  CHAR(1) ,
OUT vINVESTMENT_NEEDED  DECIMAL(16,6),
OUT vINVESTED_FUND  DECIMAL(16,6) 
  * 
  */
 

	
	cs.setInt(1, Integer.parseInt(LPO_INVESTOR_ID));
	cs.setString(2, LPO_NUMBER.trim());
	cs.setDouble(3, Double.parseDouble(AMOUNT));
	cs.setString(4, STATUS.trim().replaceAll("'", " "));
	cs.setString(5, REMARKS.trim().replaceAll("'", " "));
	cs.registerOutParameter(6, Integer.parseInt(ROWSUPDATED));
	cs.registerOutParameter(7,Types.CHAR);
	cs.registerOutParameter(8,Types.DECIMAL);
	cs.registerOutParameter(9,Types.DECIMAL);
	  
	cs.execute();

	numInvestor=cs.getInt(6);
	vELIGIBLE =cs.getString(7);
	 vINVESTMENT_NEEDED = cs.getBigDecimal(8).doubleValue(); 
	 vINVESTED_FUND_SOFAR = cs.getBigDecimal(9).doubleValue();
	          
	          if (numInvestor==1)
	          {
    		  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "0");
		      dbresult.put("errordescription",  " INVESTOR  ACCEPTED FOR LPO NUMBER ["+LPO_NUMBER+"]  !!!!!");
		      results.put("ERROR", dbresult);
		      results.put("ROWSINSERTED", String.valueOf(numInvestor));
		      results.put("LPO_NUMBER", LPO_NUMBER);
		      results.put("AMOUNT_INVESTED", AMOUNT);
		      results.put("INVESTOR_ID", LPO_INVESTOR_ID);
		      results.put("ELIGIBLE", vELIGIBLE);
		      results.put("INVESTMENT_NEEDED", vINVESTMENT_NEEDED);
		      results.put("INVESTED_FUND_SOFAR", vINVESTED_FUND_SOFAR);
		      
	          }
	          if (numInvestor != 1)
	          {
    		  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "1");
		      dbresult.put("errordescription",  " INVESTOR NOT ACCEPTED!!!! FOR LPO NUMBER ["+LPO_NUMBER+"]  !!!!!");
		      results.put("ERROR", dbresult);
		      results.put("ROWSINSERTED", String.valueOf(numInvestor));
		      results.put("LPO_NUMBER", LPO_NUMBER);
		      results.put("AMOUNT_INVESTED", AMOUNT);
		      results.put("INVESTOR_ID", LPO_INVESTOR_ID);
		      results.put("ELIGIBLE", vELIGIBLE);
		      results.put("INVESTMENT_NEEDED", vINVESTMENT_NEEDED);
		      results.put("INVESTED_FUND_SOFAR", vINVESTED_FUND_SOFAR);
	          }
		      
		      cs.close();
			  con.close();
	
		  } 
		  
		  catch(java.sql.SQLIntegrityConstraintViolationException sqlerror)
		  {
			  
			  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "-2");
		      dbresult.put("errordescription",  sqlerror.getMessage());
		      results.put("ERROR", dbresult);
		      results.put("ROWSINSERTED", String.valueOf(numInvestor));
		      results.put("LPO_NUMBER", LPO_NUMBER);
		      results.put("AMOUNT_INVESTED", AMOUNT);
		      results.put("INVESTOR_ID", LPO_INVESTOR_ID);
		      results.put("ELIGIBLE", vELIGIBLE);
		      results.put("INVESTMENT_NEEDED", vINVESTMENT_NEEDED);
		      results.put("INVESTED_FUND_SOFAR", vINVESTED_FUND_SOFAR);
			  cs.close();
			  con.close();
			  sqlerror.printStackTrace();  
			  
		  }
		  catch (Exception eee)
		  	{
			  
			  
			  JSONObject dbresult = new JSONObject();
		      dbresult.put("errorcode", "-1");
		      dbresult.put("errordescription",  eee.getMessage());
		      results.put("ERROR", dbresult);
		      results.put("ROWSINSERTED", String.valueOf(numInvestor));
		      results.put("LPO_NUMBER", LPO_NUMBER);
		      results.put("AMOUNT_INVESTED", AMOUNT);
		      results.put("INVESTOR_ID", LPO_INVESTOR_ID);
		      results.put("ELIGIBLE", vELIGIBLE);
		      results.put("INVESTMENT_NEEDED", vINVESTMENT_NEEDED);
		      results.put("INVESTED_FUND_SOFAR", vINVESTED_FUND_SOFAR);
		    
		
		    		  cs.close();
					  con.close();
			  eee.printStackTrace();
			
		  }
		  
		  
		  finally
		  {
		  
		
		}
	  
	

	  } catch (Exception ee)
{
		  JSONObject dbresult = new JSONObject();
	      dbresult.put("errorcode", "-2");
	      dbresult.put("errordescription",  ee.getMessage());
	      results.put("ERROR", dbresult);
	      results.put("ROWSINSERTED", String.valueOf(numInvestor));
	      results.put("LPO_NUMBER", LPO_NUMBER);
	      results.put("AMOUNT_INVESTED", AMOUNT);
	      results.put("INVESTOR_ID", LPO_INVESTOR_ID);

	  ee.printStackTrace();
}
	  
	  
}

response.getWriter().println(results);
}

  




	  




}




